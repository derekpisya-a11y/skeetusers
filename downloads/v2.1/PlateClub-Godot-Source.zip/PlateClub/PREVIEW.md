# Предпросмотр «Номерного клуба»

ZIP-архивы проекта исправны. Сообщение «Предпросмотр архивов пока не поддерживается» означает, что интерфейс чата не показывает содержимое ZIP. Настройки игры не могут включить эту функцию чата.

Ниже — настоящие снимки запущенной игры, которые можно посмотреть без распаковки. Сама игра запускается как приложение на Godot.

## Массовая продажа

![Коллекция](docs/screenshots/collection.png)

![Подтверждение продажи на телефоне](docs/screenshots/bulk-sale-android.png)

## Вертикальная версия Android

![Android](docs/screenshots/android.png)

## Темы

![Белая тема](docs/screenshots/white.png)

![Розовая тема](docs/screenshots/pink.png)

## Генератор номеров

![Генератор номеров](docs/screenshots/generator.png)

## Обмен номеров на сундуки

![Контракты](docs/screenshots/contracts.png)

## Гараж автомобилей

![Гараж](docs/screenshots/garage.png)

## Запустить игру

**Windows:** скачайте отдельный файл [PlateClub.exe](dist/windows/PlateClub.exe) и запустите его на компьютере. Ресурсы встроены в EXE, распаковывать архив для запуска не требуется.

**Android:** скачайте [PlateClub-debug.apk](dist/android/PlateClub-debug.apk), перенесите на телефон и установите. Требуется Android 7.0+ / arm64. Это тестовая подписанная APK для непосредственной установки.

**Редактирование:** скачайте [исходники](dist/PlateClub-Godot-Source.zip), распакуйте архив обычным архиватором, затем в Godot 4.6.3 выберите **Import → project.godot → Import & Edit → F5**. Просмотр ZIP внутри чата для этого не нужен.

Подробная инструкция: [docs/EXPORT_RU.md](docs/EXPORT_RU.md).
