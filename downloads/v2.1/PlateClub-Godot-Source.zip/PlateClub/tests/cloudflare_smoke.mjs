import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = readFileSync(resolve(root, 'server/cloudflare/worker.js'), 'utf8');
const { default: worker } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const sqlite = new DatabaseSync(':memory:');
const env = {
  DB: {
    async exec(sql) { sqlite.exec(sql); },
    prepare(sql) {
      const statement = sqlite.prepare(sql);
      let params = [];
      const prepared = {
        bind(...values) { params = values; return prepared; },
        async run() { return statement.run(...params); },
        async first() { return statement.get(...params) || null; },
        async all() { return { results: statement.all(...params) }; },
      };
      return prepared;
    },
  },
};

function make(path, method = 'GET', payload = null, token = '') {
  const headers = { 'CF-Connecting-IP': '127.0.0.1' };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (method === 'POST') headers['Content-Type'] = 'application/json';
  return new Request(`https://plate-club-test.workers.dev${path}`, {
    method, headers, body: method === 'POST' ? (typeof payload === 'string' ? payload : JSON.stringify(payload)) : undefined,
  });
}

async function call(path, method, payload, token) {
  const response = await worker.fetch(make(path, method, payload, token), env);
  return { status: response.status, body: await response.json() };
}

if (process.argv.includes('--serve')) {
  const port = Number(process.env.PLATE_CLUB_WORKER_TEST_PORT || 18766);
  const server = createServer(async (incoming, outgoing) => {
    try {
      const chunks = [];
      for await (const chunk of incoming) chunks.push(chunk);
      const url = `http://127.0.0.1:${port}${incoming.url}`;
      const response = await worker.fetch(new Request(url, {
        method: incoming.method,
        headers: incoming.headers,
        body: incoming.method === 'POST' ? Buffer.concat(chunks) : undefined,
      }), env);
      outgoing.writeHead(response.status, Object.fromEntries(response.headers));
      outgoing.end(Buffer.from(await response.arrayBuffer()));
    } catch (error) {
      outgoing.writeHead(500, { 'Content-Type': 'application/json' });
      outgoing.end(JSON.stringify({ error: String(error) }));
    }
  });
  server.listen(port, '127.0.0.1', () => console.log(`Cloudflare Worker test server listening on 127.0.0.1:${port}`));
} else {
  let checks = 0;
  async function check(actual, expected, description) {
    assert.deepEqual(actual, expected, description);
    checks++;
  }
  await check((await call('/health')).body, { ok: true, version: '2.1.0', storage: 'D1' }, 'D1 initializes on first request');
  await check(sqlite.prepare('SELECT COUNT(*) AS total FROM players').get().total, 0, 'table was created');
  await check((await call('/v1/leaderboard')).body.players, [], 'no fabricated players');
  const alice = await call('/v1/register', 'POST', { name: 'Алиса' });
  const bob = await call('/v1/register', 'POST', { name: 'Борис' });
  await check([alice.status, bob.status], [201, 201], 'register two profiles');
  await check(alice.body.id.length, 32, 'profile id shape matches Python server');
  await check(alice.body.token.length, 43, 'bearer token shape matches Python server');
  assert.notEqual(alice.body.token, bob.body.token);
  checks++;
  const stored = sqlite.prepare('SELECT token_hash FROM players WHERE id=?').get(alice.body.id);
  await check(stored.token_hash.length, 64, 'only token hash stored');
  assert.notEqual(stored.token_hash, alice.body.token);
  checks++;
  const aliceStats = { generated: 10, exchanged: 1, cars: 1, legendary_generated: 1 };
  const bobStats = { generated: 100, exchanged: 2, cars: 2, legendary_generated: 0 };
  await check((await call('/v1/score', 'POST', { id: alice.body.id, name: 'Алиса', stats: aliceStats }, alice.body.token)).body.score, 1800, 'server calculates score');
  await check((await call('/v1/score', 'POST', { id: bob.body.id, name: 'Борис', stats: bobStats }, bob.body.token)).body.score, 2000, 'second score is independent');
  await check((await call('/v1/leaderboard')).body.players.map(p => [p.rank, p.name, p.score]), [[1, 'Борис', 2000], [2, 'Алиса', 1800]], 'global table ranks real profiles');
  await check((await call('/v1/score', 'POST', { id: alice.body.id, name: 'Алиса_2', stats: { generated: 1, exchanged: 0, cars: 0, legendary_generated: 0 } }, alice.body.token)).body.score, 1800, 'worse score does not replace best');
  await check((await call('/v1/leaderboard')).body.players[1].name, 'Алиса_2', 'name update persists');
  await check((await call('/v1/score', 'POST', { id: alice.body.id, name: 'Алиса', stats: aliceStats }, 'invalidBearerTokenString00000')).status, 401, 'invalid token rejected');
  await check((await call('/v1/register', 'POST', { name: 'A' })).status, 400, 'invalid name rejected');
  await check((await call('/v1/register', 'POST', { name: 'X); DROP TABLE players' })).status, 400, 'unsafe name rejected');
  await check((await call('/v1/register', 'POST', 'invalid JSON')).status, 400, 'bad JSON rejected');
  await check((await call('/v1/register', 'POST', { name: 'X'.repeat(9000) })).status, 413, 'large request rejected');
  await check((await call('/v1/score', 'POST', { id: alice.body.id, name: 'Алиса', stats: { ...aliceStats, cars: 37 } }, alice.body.token)).status, 400, 'out-of-range stats rejected');
  await check((await call('/v1/score', 'POST', { id: alice.body.id, name: 'Алиса', stats: { ...aliceStats, legendary_generated: 11 } }, alice.body.token)).status, 400, 'impossible legend count rejected');
  await check((await call('/not-found')).status, 404, 'unknown endpoint rejected');
  const boundDb = env.DB;
  env.MY_DB = boundDb;
  delete env.DB;
  await check((await call('/health')).body.ok, true, 'Cloudflare sample MY_DB binding also works');
  env.DB = boundDb;
  delete env.MY_DB;
  await check((await worker.fetch(make('/health'), {})).status, 503, 'missing DB binding explained');
  const copy = new DatabaseSync(':memory:');
  copy.exec(readFileSync(resolve(root, 'server/cloudflare/schema.sql'), 'utf8'));
  await check(copy.prepare('SELECT COUNT(*) AS total FROM players').get().total, 0, 'optional schema file runs in SQLite');
  copy.close();
  sqlite.close();
  console.log(`Cloudflare Worker smoke: ${checks} checks, 0 failures`);
}
