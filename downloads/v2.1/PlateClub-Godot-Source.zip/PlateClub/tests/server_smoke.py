from pathlib import Path
import json, socket, subprocess, sys, tempfile, time, urllib.request, urllib.error
root = Path(__file__).resolve().parents[1]
checks = 0

def check(ok, message):
 global checks
 checks += 1
 assert ok, message

with tempfile.TemporaryDirectory(prefix='plate-club-server-') as scratch:
 with socket.socket() as sock:
  sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
 base = f'http://127.0.0.1:{port}'
 db = str(Path(scratch) / 'scores.sqlite3')
 def start():
  process = subprocess.Popen([sys.executable, str(root/'server/leaderboard.py'), '--port', str(port), '--database', db], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
  for _ in range(80):
   try:
    urllib.request.urlopen(base+'/health',timeout=1).close(); return process
   except OSError: time.sleep(.05)
  process.terminate(); raise AssertionError('server did not start')
 def request(path, data=None, token=''):
  headers = {'Content-Type':'application/json'}
  if token: headers['Authorization'] = 'Bearer ' + token
  req = urllib.request.Request(base+path, data=None if data is None else json.dumps(data).encode(), headers=headers)
  try:
   with urllib.request.urlopen(req, timeout=3) as r: return r.status, json.load(r)
  except urllib.error.HTTPError as e: return e.code, json.load(e)
 p=start()
 try:
  check(request('/health')[0]==200,'health')
  _, alice=request('/v1/register',{'name':'Коллекционер А'})
  _, bob=request('/v1/register',{'name':'Коллекционер Б'})
  check(alice['id']!=bob['id'] and alice['token']!=bob['token'],'separate real profiles')
  stats={'generated':100,'exchanged':2,'cars':3,'legendary_generated':1}
  code,answer=request('/v1/score',{'id':alice['id'],'name':'Коллекционер А','stats':stats},alice['token'])
  check(code==200 and answer['score']==3500,'server calculates score')
  stats['generated']=200
  check(request('/v1/score',{'id':bob['id'],'name':'Коллекционер Б','stats':stats},bob['token'])[0]==200,'second score')
  code,board=request('/v1/leaderboard')
  check(code==200 and len(board['players'])==2 and board['players'][0]['id']==bob['id'],'shared ranking')
  check(request('/v1/score',{'id':alice['id'],'name':'Коллекционер А','stats':stats},bob['token'])[0]==401,'cross-profile modification rejected')
  check(request('/v1/register',{'name':'<script>'})[0]==400,'invalid display name rejected')
  stats['cars']=37
  check(request('/v1/score',{'id':alice['id'],'name':'Коллекционер А','stats':stats},alice['token'])[0]==400,'invalid car count rejected')
  stats={'generated':0,'exchanged':0,'cars':0,'legendary_generated':0}
  check(request('/v1/score',{'id':alice['id'],'name':'Коллекционер А','stats':stats},alice['token'])[1]['score']==3500,'best score cannot decrease')
  stats['generated']=-1
  check(request('/v1/score',{'id':alice['id'],'name':'Коллекционер А','stats':stats},alice['token'])[0]==400,'negative progress rejected')
 finally: p.terminate(); p.wait(timeout=5)
 p=start()
 try:
  _,board=request('/v1/leaderboard')
  check(len(board['players'])==2 and board['players'][0]['score']==4000,'database persists restart')
 finally: p.terminate(); p.wait(timeout=5)
print(f'Server smoke: {checks} checks, 0 failures')
