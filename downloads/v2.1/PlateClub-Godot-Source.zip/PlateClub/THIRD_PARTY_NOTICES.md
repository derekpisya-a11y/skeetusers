# Third-party notices

Номерной клуб / Plate Club uses Godot Engine and bundled open fonts. Original game logic, procedural art and synthesized sound are part of this project. Vehicle model names identify real cars; illustrations are original and stylized. No assets from another game are included.

## Godot Engine 4.6.3 — MIT

https://godotengine.org/license/

Copyright (c) 2014-present Godot Engine contributors.
Copyright (c) 2007-2014 Juan Linietsky, Ariel Manzur.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

The exact upstream license and bundled dependency notices are in
`docs/GODOT-LICENSE.txt` and `docs/GODOT-THIRD-PARTY.txt`.

## Open Sans

`assets/fonts/ClubSans.ttf`, `ClubSans-Semibold.ttf`, `ClubSans-Bold.ttf`.
Copyright Google Corporation. Apache License 2.0.
Full notices: `assets/fonts/OPEN-SANS-LICENSE.txt` and
`assets/fonts/OPEN-SANS-APACHE-LICENSE.txt`.

## DejaVu Sans Condensed Bold

`assets/fonts/PlateCondensed-Bold.ttf`.
Derived from Bitstream Vera; DejaVu changes are in the public domain.
Full notices: `assets/fonts/PlateCondensed-LICENSE.txt`.

## Noto Sans CJK JP subset

`assets/fonts/PlateJapanese-Bold.otf` is a small subset for Japanese plate
regions and kana. SIL Open Font License 1.1.
Full notices: `assets/fonts/PlateJapanese-LICENSE.txt`.

All license text files are included with the source distribution and native builds.
