class_name GameCatalog
extends RefCounted
## Vehicle model names and the public game balance; art is stylized.

const COUNTRIES: Array[Dictionary] = [
	{"id":"ru", "name":"Россия", "code":"RUS", "flag":["#FFFFFF", "#2868CE", "#EA4A55"]},
	{"id":"by", "name":"Беларусь", "code":"BY", "flag":["#DA3442", "#DA3442", "#3F9B64"]},
	{"id":"ua", "name":"Украина", "code":"UA", "flag":["#3978E5", "#F7CE45"]},
	{"id":"kz", "name":"Казахстан", "code":"KZ", "flag":["#32BED0", "#F4D061"]},
	{"id":"jp", "name":"Япония", "code":"JPN", "flag":["#FFFFFF", "#DA3442", "#FFFFFF"]},
	{"id":"de", "name":"Германия", "code":"D", "flag":["#171B25", "#D64248", "#F1C755"]},
	{"id":"fr", "name":"Франция", "code":"F", "flag":["#3978DB", "#FFFFFF", "#DF4650"]},
	{"id":"gb", "name":"Великобритания", "code":"UK", "flag":["#293E79", "#FFFFFF", "#DD4355"]},
]

const REGIONS: Array[Dictionary] = [
	{"id":"jp", "name":"Япония", "subtitle":"Ночные улицы · JDM"},
	{"id":"cn", "name":"Китай", "subtitle":"Электрическая эра"},
	{"id":"ru", "name":"Россия", "subtitle":"Классика и характер"},
	{"id":"eu", "name":"Европа", "subtitle":"Точность и скорость"},
	{"id":"us", "name":"Америка", "subtitle":"Мощность без границ"},
	{"id":"kr", "name":"Корея", "subtitle":"Смелость и технологии"},
]

const RARITIES: Array[Dictionary] = [
	{"name":"Обычный", "color":"#97A5BA", "sell_value":35},
	{"name":"Необычный", "color":"#57DBA0", "sell_value":100},
	{"name":"Редкий", "color":"#6AA9FF", "sell_value":280},
	{"name":"Эпический", "color":"#C78CFF", "sell_value":750},
	{"name":"Легендарный", "color":"#FFC66B", "sell_value":2200},
]

const CRATE_TIERS: Array[Dictionary] = [
	{"id":"street", "name":"Street", "min_rarity":2, "count":5, "fee":5000, "odds":[35,32,23,9,1]},
	{"id":"sport", "name":"Sport", "min_rarity":3, "count":4, "fee":20000, "odds":[0,22,46,27,5]},
	{"id":"elite", "name":"Elite", "min_rarity":4, "count":3, "fee":75000, "odds":[0,0,35,50,15]},
]

const CARS: Array[Dictionary] = [
	{"id":"jp_mizu", "name":"Honda Civic EK9", "region":"jp", "rarity":0, "body":"hatch", "color":"#7EB5C9", "power":185, "year":1998, "description":"Лёгкий японский хот-хэтч. VTEC и культовый кузов EK9."},
	{"id":"jp_hikari", "name":"Toyota Mark II JZX100", "region":"jp", "rarity":1, "body":"sedan", "color":"#D6DDE7", "power":280, "year":1998, "description":"Легенда японских седанов с турбомотором 1JZ."},
	{"id":"jp_akari", "name":"Subaru Impreza WRX STI", "region":"jp", "rarity":2, "body":"sedan", "color":"#EF6B68", "power":280, "year":2006, "description":"Полный привод, оппозитный мотор и раллийный характер."},
	{"id":"jp_ryujin", "name":"Nissan Skyline GT-R R34", "region":"jp", "rarity":2, "body":"coupe", "color":"#6D90F0", "power":280, "year":1999, "description":"Культовое купе с RB26 и системой полного привода ATTESA."},
	{"id":"jp_kitsune", "name":"Toyota Supra A80", "region":"jp", "rarity":3, "body":"sport", "color":"#C68AF1", "power":330, "year":1997, "description":"Японская икона с мотором 2JZ. Любимая основа для тюнинга."},
	{"id":"jp_raiden", "name":"Nissan GT-R Nismo", "region":"jp", "rarity":4, "body":"sport", "color":"#F7C76A", "power":600, "year":2020, "description":"Флагман Nismo с аэродинамикой и подготовкой для трека."},
	{"id":"cn_lian", "name":"Chery Tiggo 4", "region":"cn", "rarity":0, "body":"suv", "color":"#90CFBE", "power":147, "year":2023, "description":"Компактный городской кроссовер."},
	{"id":"cn_yun", "name":"Geely Coolray", "region":"cn", "rarity":1, "body":"suv", "color":"#BBCADD", "power":150, "year":2023, "description":"Современный турбокроссовер для города."},
	{"id":"cn_shan", "name":"Li Auto L9", "region":"cn", "rarity":2, "body":"suv", "color":"#7DAA95", "power":449, "year":2024, "description":"Большой последовательный гибрид с просторным салоном."},
	{"id":"cn_lumen", "name":"BYD Han EV", "region":"cn", "rarity":2, "body":"sedan", "color":"#A090E3", "power":517, "year":2023, "description":"Электрический седан с двумя моторами."},
	{"id":"cn_feng", "name":"Xiaomi SU7 Ultra", "region":"cn", "rarity":3, "body":"sedan", "color":"#5ABFCB", "power":1548, "year":2025, "description":"Трёхмоторный электрический спортивный седан."},
	{"id":"cn_long", "name":"Yangwang U9", "region":"cn", "rarity":4, "body":"sport", "color":"#EF796F", "power":1306, "year":2024, "description":"Электрический суперкар с четырьмя моторами."},
	{"id":"ru_volna", "name":"ВАЗ-2107", "region":"ru", "rarity":0, "body":"sedan", "color":"#D3B08A", "power":75, "year":2005, "description":"Знакомая классика с квадратным кузовом."},
	{"id":"ru_iskra", "name":"ВАЗ-2114", "region":"ru", "rarity":1, "body":"hatch", "color":"#68AD9D", "power":81, "year":2010, "description":"Хэтчбек семейства Самара: простой и узнаваемый."},
	{"id":"ru_taiga", "name":"Lada Niva Legend", "region":"ru", "rarity":2, "body":"suv", "color":"#96A376", "power":83, "year":2023, "description":"Компактный внедорожник с постоянным полным приводом."},
	{"id":"ru_sokol", "name":"ГАЗ-24 Волга", "region":"ru", "rarity":2, "body":"sedan", "color":"#60758F", "power":95, "year":1985, "description":"Классический советский седан."},
	{"id":"ru_buran", "name":"Lada Vesta Sport", "region":"ru", "rarity":3, "body":"sedan", "color":"#D9E1EB", "power":145, "year":2021, "description":"Спортивная версия Весты с доработанной подвеской."},
	{"id":"ru_zarya", "name":"Aurus Senat", "region":"ru", "rarity":4, "body":"sedan", "color":"#EE685E", "power":598, "year":2022, "description":"Российский представительский седан."},
	{"id":"eu_vigo", "name":"Volkswagen Golf VII", "region":"eu", "rarity":0, "body":"hatch", "color":"#E2BC6C", "power":150, "year":2017, "description":"Европейский хэтчбек для повседневных поездок."},
	{"id":"eu_nord", "name":"BMW 320i", "region":"eu", "rarity":1, "body":"sedan", "color":"#7C9DAE", "power":184, "year":2019, "description":"Заднеприводный седан третьей серии."},
	{"id":"eu_falken", "name":"Mercedes-Benz E 63 AMG", "region":"eu", "rarity":2, "body":"sedan", "color":"#708BE0", "power":612, "year":2019, "description":"Мощный седан подразделения AMG."},
	{"id":"eu_alto", "name":"Porsche 911 Carrera S", "region":"eu", "rarity":2, "body":"sport", "color":"#E6B564", "power":450, "year":2020, "description":"Классическое спортивное купе серии 992."},
	{"id":"eu_valore", "name":"Lamborghini Huracan EVO", "region":"eu", "rarity":3, "body":"sport", "color":"#DF6E62", "power":640, "year":2020, "description":"Суперкар с атмосферным двигателем V10."},
	{"id":"eu_aurelia", "name":"Bugatti Chiron", "region":"eu", "rarity":4, "body":"sport", "color":"#C4A6EA", "power":1500, "year":2019, "description":"Гиперкар с двигателем W16 и четырьмя турбинами."},
	{"id":"us_harbor", "name":"Ford Crown Victoria", "region":"us", "rarity":0, "body":"sedan", "color":"#A3B1C2", "power":224, "year":2011, "description":"Американский седан на рамной платформе."},
	{"id":"us_trail", "name":"Jeep Grand Cherokee", "region":"us", "rarity":1, "body":"suv", "color":"#889679", "power":286, "year":2015, "description":"Большой внедорожник для дальних маршрутов."},
	{"id":"us_iron", "name":"Ford Mustang GT", "region":"us", "rarity":2, "body":"coupe", "color":"#E29459", "power":450, "year":2020, "description":"Американское купе с атмосферным V8."},
	{"id":"us_dust", "name":"Dodge Challenger R/T", "region":"us", "rarity":2, "body":"coupe", "color":"#9A80C1", "power":375, "year":2016, "description":"Классический характер американского маслкара."},
	{"id":"us_vortex", "name":"Chevrolet Corvette Z06", "region":"us", "rarity":3, "body":"sport", "color":"#5CAABF", "power":670, "year":2023, "description":"Среднемоторный спорткар с высокооборотным V8."},
	{"id":"us_thunder", "name":"Dodge Challenger Demon 170", "region":"us", "rarity":4, "body":"sport", "color":"#F0C45F", "power":1025, "year":2023, "description":"Редкая заводская версия для дрэг-рейсинга."},
	{"id":"kr_nuri", "name":"Kia Picanto", "region":"kr", "rarity":0, "body":"hatch", "color":"#82C4BC", "power":84, "year":2019, "description":"Компактный городской хэтчбек."},
	{"id":"kr_seon", "name":"Hyundai Solaris", "region":"kr", "rarity":1, "body":"sedan", "color":"#BDC9DB", "power":123, "year":2020, "description":"Знакомый корейский городской седан."},
	{"id":"kr_haneul", "name":"Kia Stinger GT", "region":"kr", "rarity":2, "body":"sedan", "color":"#759DB0", "power":370, "year":2021, "description":"Спортивный лифтбек с турбомотором V6."},
	{"id":"kr_mirae", "name":"Genesis G80", "region":"kr", "rarity":2, "body":"sedan", "color":"#DF7B73", "power":249, "year":2022, "description":"Представительский седан марки Genesis."},
	{"id":"kr_bora", "name":"Hyundai IONIQ 5 N", "region":"kr", "rarity":3, "body":"hatch", "color":"#94ABED", "power":650, "year":2024, "description":"Электрический хот-хэтч подразделения N."},
	{"id":"kr_haetae", "name":"Hyundai N Vision 74", "region":"kr", "rarity":4, "body":"sport", "color":"#DDCF9D", "power":680, "year":2022, "description":"Реальный демонстрационный концепт: ретродизайн и водородная гибридная система."},
]

static func country(id: String) -> Dictionary:
	return _find(COUNTRIES, id)

static func region(id: String) -> Dictionary:
	return _find(REGIONS, id)

static func car(id: String) -> Dictionary:
	return _find(CARS, id)

static func rarity(index: int) -> Dictionary:
	return RARITIES[clampi(index, 0, RARITIES.size() - 1)].duplicate(true)

static func tier(id: String) -> Dictionary:
	return _find(CRATE_TIERS, id)

static func _find(items: Array[Dictionary], id: String) -> Dictionary:
	for item: Dictionary in items:
		if item.id == id:
			return item.duplicate(true)
	return {}
