class_name StudioView
extends Control

var accent = Color("c0f777")
var mode: String = "plate"

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)

func _draw() -> void:
	var w = size.x
	var h = size.y
	for i in range(9, 0, -1):
		var r = minf(w * 0.53, h * 0.97) * float(i) / 9.0
		draw_circle(Vector2(w * 0.52, h * 0.5), r, Color(accent, 0.008 + 0.002 * (9 - i)))
	for x in range(0, int(w), 36):
		draw_line(Vector2(x, 0), Vector2(x, h), Color(ClubTheme.shade(ClubTheme.LINE), 0.35), 1)
	for y in range(0, int(h), 36):
		draw_line(Vector2(0, y), Vector2(w, y), Color(ClubTheme.shade(ClubTheme.LINE), 0.35), 1)
	draw_line(Vector2(w * 0.12, h * 0.80), Vector2(w * 0.88, h * 0.80), Color(accent, 0.16), 1)
	for p in [Vector2(18, 18), Vector2(w - 18, 18), Vector2(18, h - 18), Vector2(w - 18, h - 18)]:
		draw_line(p - Vector2(4, 0), p + Vector2(4, 0), Color("536065"), 1)
		draw_line(p - Vector2(0, 4), p + Vector2(0, 4), Color("536065"), 1)
	var f = ClubTheme.font()
	draw_string(f, Vector2(25, h - 21), "PLATE CLUB  /  COLLECTION STUDIO", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("62767c"))
	draw_string(f, Vector2(w - 158, 29), "EST. 2026   /   001", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("62767c"))
