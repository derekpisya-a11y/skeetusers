class_name PlateView
extends Control
## Self-contained vector number plate. The backing remains transparent.

const NUMBER_FONT = preload("res://assets/fonts/PlateCondensed-Bold.ttf")
const JAPANESE_FONT = preload("res://assets/fonts/PlateJapanese-Bold.otf")
const INK := Color("182023")
const ENAMEL := Color("f2f2e9")

var plate: Dictionary = {}:
	set(value):
		plate = value
		queue_redraw()
var compact: bool = false:
	set(value):
		compact = value
		queue_redraw()
var highlight: String = "":
	set(value):
		highlight = value
		queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	if size.x < 2.0 or size.y < 2.0:
		return
	var country := str(plate.get("country", "RU")).to_upper()
	var japanese := country == "JP"
	var base := Vector2(560, 124) if not japanese else Vector2(400, 194)
	var factor := minf(size.x / (base.x + 12.0), size.y / (base.y + 12.0))
	draw_set_transform((size - base * factor) * 0.5, 0.0, Vector2.ONE * factor)
	_rounded(Rect2(-3, 3, base.x + 6, base.y + 4), Color(0, 0, 0, 0.20), 13)
	_rounded(Rect2(Vector2.ZERO, base), Color("b7bdb5"), 10)
	var surface := Color("efcf44") if country == "GB" else ENAMEL
	_rounded(Rect2(2, 2, base.x - 4, base.y - 4), surface, 9)
	_rounded(Rect2(6, 6, base.x - 12, base.y - 12), Color.TRANSPARENT, 7, INK, 2)
	draw_line(Vector2(15, 10), Vector2(base.x - 15, 10), Color(1, 1, 1, 0.66), 2, true)
	if japanese:
		_draw_japan()
	else:
		_draw_standard(country)
	_screw(Vector2(18, base.y * 0.5))
	_screw(Vector2(base.x - 18, base.y * 0.5))
	if not highlight.is_empty():
		var rect = Rect2(28, 17, base.x - 60, base.y - 34)
		if country == "RU":
			match highlight:
				"letters":
					_rounded(Rect2(36, 21, 61, 84), Color("baffa2"), 7, Color("3a9559"), 3)
					_rounded(Rect2(269, 21, 139, 84), Color("baffa2"), 7, Color("3a9559"), 3)
					_draw_standard(country)
				"digits": rect = Rect2(100, 19, 165, 88)
				"region": rect = Rect2(433, 10, 106, 100)
		if highlight != "letters" or country != "RU":
			_rounded(rect, Color.TRANSPARENT, 7, Color("eeaa33"), 4)
	draw_set_transform(Vector2.ZERO)


func _draw_standard(country: String) -> void:
	var content := Rect2(33, 20, 485, 85)
	var ink := INK
	var code := "RUS"
	match country:
		"RU":
			draw_line(Vector2(424, 7), Vector2(424, 117), INK, 2, true)
			content.size.x = 378
			_fit_text(str(plate.get("region", "777")), Rect2(438, 11, 99, 65), 55, INK)
			_fit_text("RUS", Rect2(438, 79, 56, 25), 22, INK)
			_flag(Rect2(501, 83, 31, 19), "RU")
		"BY":
			_flag(Rect2(28, 23, 42, 25), "BY")
			_fit_text("BY", Rect2(25, 69, 49, 30), 27, INK)
			content = Rect2(87, 18, 440, 90)
		"UA":
			_rounded(Rect2(8, 8, 59, 108), Color("1463ae"), 4)
			_flag(Rect2(18, 23, 38, 26), "UA")
			_fit_text("UA", Rect2(14, 71, 47, 27), 25, Color.WHITE)
			content = Rect2(82, 19, 447, 88)
		"KZ":
			_flag(Rect2(26, 24, 42, 25), "KZ")
			_fit_text("KZ", Rect2(25, 71, 49, 28), 26, INK)
			draw_line(Vector2(452, 7), Vector2(452, 117), INK, 2, true)
			_fit_text(str(plate.get("region", "02")), Rect2(462, 27, 75, 69), 55, INK)
			content = Rect2(87, 19, 353, 88)
		"DE", "FR":
			_rounded(Rect2(8, 8, 53, 108), Color("184394"), 4)
			_eu_stars(Vector2(34, 37), 15)
			code = "D" if country == "DE" else "F"
			_fit_text(code, Rect2(16, 69, 36, 31), 29, Color.WHITE)
			content = Rect2(75, 18, 452, 89)
			if country == "FR":
				_rounded(Rect2(506, 8, 46, 108), Color("184394"), 4)
				_fit_text(str(plate.get("region", "75")), Rect2(514, 67, 29, 30), 24, Color.WHITE)
				content.size.x = 416
		"GB":
			_rounded(Rect2(8, 8, 53, 108), Color("17314a"), 4)
			_flag(Rect2(17, 25, 35, 22), "GB")
			_fit_text("UK", Rect2(14, 71, 42, 28), 25, Color.WHITE)
			content = Rect2(77, 20, 451, 86)
		_:
			_fit_text(country, Rect2(23, 55, 48, 36), 23, INK)
			content = Rect2(83, 19, 443, 88)
	_fit_text(str(plate.get("text", "А777АА")), content, 79, ink)


func _draw_japan() -> void:
	var green := Color("174937")
	_fit_text(str(plate.get("region", "品川 300")), Rect2(52, 13, 302, 54), 37, green, JAPANESE_FONT)
	var components := str(plate.get("text", "あ 77-77")).split(" ", false)
	var number := str(components[-1]) if not components.is_empty() else "77-77"
	var kana := str(components[0]) if components.size() > 1 else "あ"
	_fit_text(kana, Rect2(25, 91, 51, 54), 39, green, JAPANESE_FONT)
	_fit_text(number, Rect2(80, 70, 287, 99), 91, green)


func _fit_text(value: String, rect: Rect2, font_size: int, color: Color, font: Font = NUMBER_FONT) -> void:
	var actual_size := font_size
	while actual_size > 10 and font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, actual_size).x > rect.size.x:
		actual_size -= 1
	var width := font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, actual_size).x
	var baseline := rect.position.y + (rect.size.y - font.get_height(actual_size)) * 0.5 + font.get_ascent(actual_size)
	draw_string(font, Vector2(rect.position.x + (rect.size.x - width) * 0.5, baseline), value, HORIZONTAL_ALIGNMENT_LEFT, -1, actual_size, color)


func _rounded(rect: Rect2, color: Color, radius: int, border: Color = Color.TRANSPARENT, border_width: int = 0) -> void:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(radius)
	box.border_color = border
	box.set_border_width_all(border_width)
	draw_style_box(box, rect)


func _screw(at: Vector2) -> void:
	draw_circle(at + Vector2(0, 1), 4, Color("93998f"))
	draw_circle(at, 3, Color("c5cac0"))
	draw_line(at + Vector2(-2, -1), at + Vector2(2, 1), Color("696e66"), 1, true)


func _flag(rect: Rect2, country: String) -> void:
	var x := rect.position.x
	var y := rect.position.y
	var w := rect.size.x
	var h := rect.size.y
	match country:
		"RU":
			draw_rect(Rect2(x, y, w, h / 3.0), Color.WHITE)
			draw_rect(Rect2(x, y + h / 3.0, w, h / 3.0), Color("2350a0"))
			draw_rect(Rect2(x, y + h * 2.0 / 3.0, w, h / 3.0), Color("d04742"))
		"BY":
			draw_rect(rect, Color("c94146"))
			draw_rect(Rect2(x, y + h * 0.65, w, h * 0.35), Color("36865b"))
			draw_rect(Rect2(x, y, w * 0.17, h), Color("fff1e3"))
			for i in range(4):
				draw_circle(Vector2(x + w * 0.085, y + 3 + i * h / 4.0), 1.4, Color("c94146"))
		"UA":
			draw_rect(rect, Color("f3cb49"))
			draw_rect(Rect2(x, y, w, h * 0.5), Color("3b85c8"))
		"KZ":
			draw_rect(rect, Color("41b7c9"))
			draw_circle(Vector2(x + w * 0.55, y + h * 0.42), h * 0.19, Color("f0d16c"))
			draw_arc(Vector2(x + w * 0.55, y + h * 0.46), h * 0.31, 0.3, PI - 0.3, 12, Color("f0d16c"), 2, true)
		"GB":
			draw_rect(rect, Color("23386b"))
			draw_line(Vector2(x, y), Vector2(x + w, y + h), Color.WHITE, 5, true)
			draw_line(Vector2(x + w, y), Vector2(x, y + h), Color.WHITE, 5, true)
			draw_rect(Rect2(x, y + h * 0.34, w, h * 0.32), Color.WHITE)
			draw_rect(Rect2(x + w * 0.4, y, w * 0.2, h), Color.WHITE)
			draw_rect(Rect2(x, y + h * 0.41, w, h * 0.18), Color("d64b54"))
			draw_rect(Rect2(x + w * 0.445, y, w * 0.11, h), Color("d64b54"))
	draw_rect(rect, Color(0, 0, 0, 0.13), false, 1)


func _eu_stars(center: Vector2, radius: float) -> void:
	for index in range(12):
		var angle := TAU * float(index) / 12.0 - PI * 0.5
		draw_circle(center + Vector2(cos(angle), sin(angle)) * radius, 1.6, Color("f1cf54"))
