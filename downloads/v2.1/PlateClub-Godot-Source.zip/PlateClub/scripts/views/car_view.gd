class_name CarView
extends Control
## Original procedural vehicle illustrations. All dimensions use a 760×310 artboard.

var car: Dictionary = {}:
	set(value):
		car = value
		queue_redraw()
var showcase: bool = true:
	set(value):
		showcase = value
		queue_redraw()
var kit_id: String = "":
	set(value):
		kit_id = value
		queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	if size.x < 2 or size.y < 2:
		return
	var factor := minf(size.x / 760.0, size.y / 310.0)
	draw_set_transform((size - Vector2(760, 310) * factor) * 0.5, 0.0, Vector2.ONE * factor)
	var paint := Color(str(car.get("color", "9bb7c1")))
	var body := str(car.get("body", "sport"))
	var region := str(car.get("region", "jp"))
	var tall := body == "suv"
	var fast := body == "sport" or body == "coupe"
	var compact_body := body == "hatch"
	var rear_wheel := Vector2(199, 222)
	var front_wheel := Vector2(566, 222)
	if compact_body:
		rear_wheel.x = 222
	if tall:
		rear_wheel.y = 222
		front_wheel.y = 222
	_ellipse(Vector2(386, 265), Vector2(285, 17), Color(0, 0, 0, 0.26))
	_ellipse(Vector2(390, 257), Vector2(246, 8), Color(0, 0, 0, 0.25))
	if showcase:
		_ellipse(Vector2(395, 273), Vector2(230, 2), Color(paint, 0.16))
	var silhouette: PackedVector2Array
	if tall:
		silhouette = _points([85,158, 102,145, 165,136, 199,78, 219,66, 440,66, 466,82, 518,134, 609,142, 656,164, 667,209, 651,231, 99,232, 79,211])
	elif compact_body:
		silhouette = _points([83,176, 95,151, 145,103, 184,82, 400,81, 434,98, 487,143, 611,153, 660,177, 674,209, 656,229, 95,230, 79,208])
	elif fast:
		silhouette = _points([78,175, 90,159, 178,153, 259,113, 285,102, 417,98, 454,112, 508,146, 603,154, 669,179, 683,208, 668,227, 90,228, 76,209])
	else:
		silhouette = _points([83,176, 95,158, 197,147, 266,95, 287,86, 430,86, 453,98, 514,143, 611,153, 660,177, 674,209, 656,229, 95,230, 79,208])
	_gradient_polygon(silhouette, paint.lightened(0.28), paint.darkened(0.42), 66, 230)
	draw_polyline(silhouette, paint.lightened(0.11), 1.6, true)
	# Sill and subtle lower reflection define the stamped bodywork.
	_polygon([88,206, 184,211, 231,212, 533,211, 615,204, 676,202, 665,222, 96,224], paint.darkened(0.37))
	_polygon([245,194, 501,190, 531,203, 503,212, 240,213], Color(paint.lightened(0.32), 0.24))
	draw_line(Vector2(254, 216), Vector2(517, 214), paint.lightened(0.26), 2, true)
	if tall:
		_polygon([94,213, 654,213, 647,233, 100,233], Color("263033"))
		draw_line(Vector2(254, 226), Vector2(511, 226), Color("707b7c"), 3, true)
		_glass([212,86, 235,78, 309,78, 309,132, 181,132], paint)
		_glass([323,78, 431,78, 450,91, 493,132, 323,132], paint)
		draw_line(Vector2(215, 61), Vector2(427, 61), Color("6f7e7f"), 4, true)
		draw_line(Vector2(242, 61), Vector2(245, 69), Color("202729"), 4, true)
		draw_line(Vector2(404, 61), Vector2(407, 69), Color("202729"), 4, true)
		_door([315,140, 316,201, 291,211], paint)
		_door([489,141, 510,162, 513,201], paint)
		_handle(Vector2(350, 153), paint)
		_handle(Vector2(231, 153), paint)
	elif compact_body:
		_glass([218,92, 297,92, 297,140, 165,140, 184,110], paint)
		_glass([310,92, 394,92, 427,107, 465,140, 310,140], paint)
		_door([305,147, 307,204, 285,214], paint)
		_door([464,149, 490,173, 489,211], paint)
		_handle(Vector2(342, 160), paint)
		_handle(Vector2(237, 160), paint)
	elif fast:
		_glass([289,113, 328,111, 328,146, 229,146], paint)
		_glass([341,111, 416,110, 449,123, 482,146, 341,146], paint)
		_door([331,151, 339,207, 485,207, 497,177, 483,153], paint)
		_handle(Vector2(360, 165), paint)
		# Coupe fender vent and spoiler; original geometry, no manufacturer logos.
		_polygon([501,169, 529,166, 518,183, 497,183], Color("182426"))
		for j in range(3):
			draw_line(Vector2(505 + j * 5, 171), Vector2(502 + j * 5, 181), paint.darkened(0.1), 1.5, true)
		if body == "sport":
			draw_line(Vector2(109, 157), Vector2(110, 143), Color("283234"), 4, true)
			draw_line(Vector2(142, 154), Vector2(142, 142), Color("283234"), 4, true)
			_polygon([79,140, 160,138, 160,146, 80,148], paint.darkened(0.45))
	else:
		_glass([283,98, 326,98, 326,141, 224,141], paint)
		_glass([339,98, 425,98, 449,110, 491,141, 339,141], paint)
		_door([331,149, 335,203, 309,213], paint)
		_door([487,150, 508,173, 504,209], paint)
		_handle(Vector2(366, 160), paint)
		_handle(Vector2(273, 160), paint)
	# Beltline, bonnet and bumper highlights.
	draw_polyline(_points([100,169, 195,158, 310,155, 490,155, 605,165, 652,184]), Color(paint.lightened(0.66), 0.54), 2, true)
	draw_line(Vector2(521, 148 if not tall else 137), Vector2(613, 158 if not tall else 146), Color(paint.lightened(0.65), 0.65), 2, true)
	_polygon([643,184, 671,187, 675,207, 649,212], Color("202a2c"))
	for i in range(4):
		draw_line(Vector2(650, 190 + i * 4), Vector2(668, 191 + i * 4), Color("3d494b"), 1.3, true)
	_polygon([613,171, 649,178, 654,185, 615,180], Color("f1f8d5"))
	draw_line(Vector2(616, 173), Vector2(647, 180), Color("ffffff"), 2.2, true)
	_polygon([85,178, 115,173, 115,183, 82,190], Color("c85452"))
	draw_line(Vector2(87, 181), Vector2(109, 177), Color("ff9690"), 2, true)
	# Mirror above the leading door.
	_polygon([476,145, 492,144, 501,151, 500,158, 480,156], paint.darkened(0.2))
	draw_line(Vector2(479, 146), Vector2(492, 146), paint.lightened(0.55), 2, true)
	var radius := 39.0 if tall else 37.0
	_wheel(rear_wheel, radius, paint, region, fast)
	_wheel(front_wheel, radius, paint, region, fast)
	# Fender trim sits above wheel edges and follows their contour.
	draw_arc(rear_wheel, radius + 5, PI * 1.05, TAU - 0.05 * PI, 30, paint.lightened(0.12), 3, true)
	draw_arc(front_wheel, radius + 5, PI * 1.05, TAU - 0.05 * PI, 30, paint.lightened(0.12), 3, true)
	if tall:
		draw_arc(rear_wheel, radius + 7, PI, TAU, 30, Color("293335"), 6, true)
		draw_arc(front_wheel, radius + 7, PI, TAU, 30, Color("293335"), 6, true)
	# Little reflective license plate inset at the front.
	draw_line(Vector2(670, 213), Vector2(679, 209), Color("dce3c7"), 3, true)
	if not kit_id.is_empty():
		var trim = Color("d9ac55") if kit_id == "elite" else Color("242b30")
		_polygon([84,224, 677,224, 687,234, 78,234], trim)
		_polygon([660,217, 701,218, 709,228, 671,229], trim.lightened(0.2))
		draw_line(Vector2(93,158), Vector2(87,117 if kit_id != "aero" else 139), trim, 7, true)
		_polygon([65,108 if kit_id != "aero" else 130, 175,106 if kit_id != "aero" else 128, 174,116 if kit_id != "aero" else 138, 64,118 if kit_id != "aero" else 140], trim)
		for wheel in [rear_wheel, front_wheel]:
			draw_arc(wheel, radius + 8, PI, TAU, 30, trim, 9, true)
		if kit_id == "track" or kit_id == "elite":
			for wheel in [rear_wheel, front_wheel]:
				draw_arc(wheel, radius - 8, 0, TAU, 30, Color("d9ac55") if kit_id == "elite" else Color("c6d1db"), 4, true)
		draw_line(Vector2(251,229), Vector2(515,229), trim.lightened(0.3), 3, true)
	draw_set_transform(Vector2.ZERO)


func _wheel(at: Vector2, radius: float, paint: Color, region: String, sporty: bool) -> void:
	draw_circle(at + Vector2(0, -1), radius + 5, Color("11181b"))
	draw_circle(at, radius, Color("090e11"))
	draw_arc(at, radius - 3, 0, TAU, 64, Color("2b3236"), 3, true)
	var rim := radius * (0.71 if sporty else 0.65)
	draw_circle(at, rim, Color("77848b"))
	draw_circle(at, rim - 2.2, Color("202a31"))
	draw_circle(at, rim - 5, Color("49535b"))
	draw_circle(at, rim - 7, Color("20282e"))
	if sporty:
		draw_arc(at, rim - 8, -0.5, 0.85, 12, Color("bc604f"), 5, true)
	var spokes := 5 if region == "jp" or region == "us" else 6
	for i in range(spokes):
		var angle := TAU * float(i) / float(spokes) - 0.35
		var direction := Vector2(cos(angle), sin(angle))
		var perpendicular := Vector2(-direction.y, direction.x)
		var verts := PackedVector2Array([at + direction * 5 + perpendicular * 2.5, at + direction * (rim - 3) + perpendicular * 3, at + direction * (rim - 2) - perpendicular * 2, at + direction * 4 - perpendicular * 2.5])
		draw_colored_polygon(verts, Color("b2bec3"))
		draw_line(at + direction * 8, at + direction * (rim - 4), Color("e0e5e4"), 1, true)
	draw_circle(at, 7, Color("8c9c9f"))
	draw_circle(at, 4.4, Color("303d42"))
	draw_circle(at, 1.8, paint.lightened(0.4))
	draw_arc(at, radius - 1, PI * 1.2, PI * 1.8, 14, Color("4d585c"), 1.3, true)


func _glass(values: Array, paint: Color) -> void:
	var points := _points(values)
	_gradient_polygon(points, Color("283e4a"), Color("101e26"), 76, 151)
	draw_polyline(points, paint.darkened(0.54), 3, true)
	# Reflection is clipped to a narrow band on the pane, using its top points.
	if points.size() >= 4:
		var top_left := points[0]
		var top_right := points[1]
		draw_line(top_left + Vector2(3, 3), top_right - Vector2(2, -3), Color("8aa9b1"), 1.5, true)
	var center := Vector2.ZERO
	for point in points:
		center += point
	center /= float(points.size())
	draw_line(center + Vector2(-13, -11), center + Vector2(-25, 11), Color("405b66"), 4, true)
	draw_line(center + Vector2(-5, -11), center + Vector2(-17, 11), Color("405b66"), 1.5, true)


func _door(values: Array, paint: Color) -> void:
	draw_polyline(_points(values), Color(paint.darkened(0.7), 0.61), 1.4, true)


func _handle(at: Vector2, paint: Color) -> void:
	draw_line(at + Vector2(0, 2), at + Vector2(19, 2), paint.darkened(0.46), 3, true)
	draw_line(at, at + Vector2(17, 0), paint.lightened(0.52), 2, true)


func _polygon(values: Array, color: Color) -> void:
	draw_colored_polygon(_points(values), color)


func _points(values: Array) -> PackedVector2Array:
	var result := PackedVector2Array()
	for i in range(0, values.size(), 2):
		result.append(Vector2(float(values[i]), float(values[i + 1])))
	return result


func _gradient_polygon(points: PackedVector2Array, top: Color, bottom: Color, y_min: float, y_max: float) -> void:
	var colors := PackedColorArray()
	for point in points:
		colors.append(top.lerp(bottom, clampf((point.y - y_min) / (y_max - y_min), 0.0, 1.0)))
	draw_polygon(points, colors)


func _ellipse(at: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for index in range(64):
		var angle := TAU * float(index) / 64.0
		points.append(at + Vector2(cos(angle), sin(angle)) * radii)
	draw_colored_polygon(points, color)
