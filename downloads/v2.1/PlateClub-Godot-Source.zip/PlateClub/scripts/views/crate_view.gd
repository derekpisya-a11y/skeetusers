class_name CrateView
extends Control
## Metallic automotive case with region-specific original geometric emblems.

var region_id: String = "jp":
	set(value):
		region_id = value
		queue_redraw()
var tier_id: String = "street":
	set(value):
		tier_id = value
		queue_redraw()
var accent: Color = Color("b4f56a"):
	set(value):
		accent = value
		queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	if size.x < 2 or size.y < 2:
		return
	var factor := minf(size.x / 340.0, size.y / 250.0)
	draw_set_transform((size - Vector2(340, 250) * factor) * 0.5, 0.0, Vector2.ONE * factor)
	var glow := accent
	if tier_id == "elite" or tier_id == "legendary":
		glow = Color("eeb665")
	for index in range(6, 0, -1):
		var expand := float(index) * 4.5
		_round(Rect2(58 - expand, 67 - expand, 225 + expand * 2, 130 + expand * 2), Color(glow, 0.009 * float(7 - index)), 24)
	_polygon([46,217, 110,232, 306,213, 231,194], Color(0, 0, 0, 0.25))
	# Lid, front and side are separate planes in a consistent perspective.
	_polygon([49,79, 108,47, 295,67, 239,103], Color("485552"))
	_polygon([49,79, 239,103, 239,215, 49,187], Color("283534"))
	_polygon([239,103, 295,67, 295,178, 239,215], Color("172321"))
	_polygon([55,86, 235,109, 235,126, 55,103], Color("182523"))
	_polygon([241,110, 289,79, 289,95, 241,126], Color("101b19"))
	# Machined front panel and inset faceplate.
	_polygon([67,113, 222,133, 222,193, 67,171], Color("111c1b"))
	_polygon([72,118, 217,136, 217,187, 72,168], Color("23312d"))
	_polygon([76,122, 215,139, 215,143, 76,126], Color("35463b"))
	# Top ribs.
	for index in range(4):
		var x := 90.0 + index * 39.0
		_polygon([x,77 + index * 4.5, x + 35,58 + index * 4.4, x + 47,59 + index * 4.4, x + 12,78 + index * 4.5], Color("263732"))
		draw_line(Vector2(x + 2, 76 + index * 4.5), Vector2(x + 35, 58 + index * 4.4), Color("6b7870"), 1.3, true)
	# Fine coloured status light, with restrained bloom.
	draw_line(Vector2(55, 104), Vector2(235, 127), Color(glow, 0.14), 7, true)
	draw_line(Vector2(55, 104), Vector2(235, 127), glow, 2, true)
	draw_line(Vector2(242, 127), Vector2(289, 97), Color(glow, 0.65), 1.5, true)
	# Reinforced corners.
	_polygon([49,80, 64,82, 64,111, 49,109], Color("879083"))
	_polygon([224,101, 239,103, 239,133, 224,131], Color("69786a"))
	_polygon([49,170, 65,172, 65,189, 49,187], Color("606f62"))
	_polygon([224,195, 239,197, 239,215, 224,212], Color("606f62"))
	_polygon([281,76, 295,67, 295,91, 281,100], Color("5b6b5f"))
	_polygon([281,172, 295,163, 295,178, 281,188], Color("4e5e50"))
	# Stainless latches.
	_latch(Vector2(84, 104), glow)
	_latch(Vector2(195, 118), glow)
	# Side recessed carrying handle and industrial grooves.
	_polygon([255,132, 281,116, 281,144, 255,161], Color("090f0e"))
	_polygon([260,135, 277,124, 277,131, 260,142], Color("718174"))
	for index in range(3):
		draw_line(Vector2(253, 174 + index * 6), Vector2(281, 156 + index * 6), Color("34473a"), 2, true)
	_emblem(Vector2(145, 158), glow)
	for screw in [Vector2(57, 91), Vector2(232, 115), Vector2(57, 179), Vector2(230, 205)]:
		draw_circle(screw, 2.2, Color("25352b"))
		draw_line(screw - Vector2(1, 0), screw + Vector2(1, 0), Color("899889"), 0.7, true)
	draw_polyline(_points([49,79, 108,47, 295,67]), Color("91a18c"), 1.4, true)
	draw_line(Vector2(49, 80), Vector2(239, 104), Color("a4b298"), 1.4, true)
	draw_line(Vector2(239, 104), Vector2(295, 68), Color("5c755d"), 1.5, true)
	draw_set_transform(Vector2.ZERO)


func _emblem(at: Vector2, glow: Color) -> void:
	var border := PackedVector2Array([at + Vector2(0, -24), at + Vector2(28, -11), at + Vector2(28, 17), at + Vector2(0, 25), at + Vector2(-28, 11), at + Vector2(-28, -16), at + Vector2(0, -24)])
	draw_polyline(border, Color(glow, 0.4), 1.2, true)
	match region_id:
		"jp":
			draw_circle(at, 11, glow)
			draw_line(at + Vector2(-20, 12), at + Vector2(17, 17), Color(glow, 0.8), 2, true)
		"cn":
			var star := PackedVector2Array()
			for index in range(10):
				var angle := -PI * 0.5 + index * PI / 5.0
				var radius := 17.0 if index % 2 == 0 else 7.0
				star.append(at + Vector2(cos(angle), sin(angle)) * radius)
			draw_colored_polygon(star, glow)
		"ru":
			for index in range(3):
				var y := -10.0 + index * 9.0
				draw_line(at + Vector2(-17, y - 2), at + Vector2(16, y + 3), glow, 4, true)
		"us":
			for index in range(3):
				var x := -13.0 + index * 13.0
				draw_polyline(PackedVector2Array([at + Vector2(x - 6, -12), at + Vector2(x + 3, 1), at + Vector2(x - 6, 13)]), glow, 3, true)
		"kr":
			draw_arc(at, 14, -PI * 0.1, PI * 0.9, 24, glow, 6, true)
			draw_arc(at, 14, PI * 0.9, PI * 1.9, 24, Color(glow, 0.45), 6, true)
		_:
			for index in range(8):
				var angle := float(index) * TAU / 8.0
				draw_circle(at + Vector2(cos(angle), sin(angle)) * 16, 2.5, glow)


func _latch(at: Vector2, glow: Color) -> void:
	_polygon([at.x - 7,at.y - 10, at.x + 7,at.y - 8, at.x + 7,at.y + 18, at.x - 7,at.y + 16], Color("0d1712"))
	_polygon([at.x - 5,at.y - 9, at.x + 5,at.y - 7, at.x + 5,at.y + 12, at.x - 5,at.y + 11], Color("7f8d7b"))
	draw_line(at + Vector2(-3, -1), at + Vector2(3, 0), Color("c7d0b9"), 2, true)
	draw_circle(at + Vector2(0, 7), 1.7, glow)


func _polygon(values: Array, color: Color) -> void:
	draw_colored_polygon(_points(values), color)


func _points(values: Array) -> PackedVector2Array:
	var result := PackedVector2Array()
	for index in range(0, values.size(), 2):
		result.append(Vector2(float(values[index]), float(values[index + 1])))
	return result


func _round(rect: Rect2, color: Color, radius: int) -> void:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(radius)
	draw_style_box(box, rect)
