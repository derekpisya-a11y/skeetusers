class_name ClubTheme
extends RefCounted

const BG = Color("0b1013")
const PANEL = Color("121b20")
const PANEL_LIGHT = Color("19242a")
const LINE = Color("2b383f")
const TEXT = Color("edf2ed")
const MUTED = Color("899ba2")
const LIME = Color("c0f777")
const GOLD = Color("f7c86a")
const RED = Color("ff8b82")

const PALETTES = {
	"classic": {"name":"Клубная", "bg":"0b1013", "panel":"121b20", "light":"19242a", "line":"2b383f", "text":"edf2ed", "muted":"899ba2", "accent":"c0f777"},
	"white": {"name":"Белая", "bg":"f1f4f7", "panel":"ffffff", "light":"e7edf2", "line":"c8d2da", "text":"15232c", "muted":"526675", "accent":"277d59"},
	"pink": {"name":"Розовая", "bg":"26151f", "panel":"392333", "light":"4a3042", "line":"6a465c", "text":"ffeaf5", "muted":"d3a6be", "accent":"ff95c7"},
	"gray": {"name":"Чёрно-серая", "bg":"111111", "panel":"202020", "light":"2c2c2c", "line":"484848", "text":"f2f2f2", "muted":"aaaaaa", "accent":"d5d5d5"},
}
static var selected: String = "classic"
static var touch: bool = false

static func choose(id: String) -> void:
	selected = id if PALETTES.has(id) else "classic"

static func shade(color: Color) -> Color:
	if selected == "classic" or color.a <= 0.001:
		return color
	var palette: Dictionary = PALETTES[selected]
	var tokens = {BG:"bg", PANEL:"panel", PANEL_LIGHT:"light", LINE:"line", TEXT:"text", MUTED:"muted", LIME:"accent"}
	var opaque = Color(color, 1.0)
	if tokens.has(opaque):
		return Color(Color(str(palette[tokens[opaque]])), color.a)
	if selected == "white":
		var readable = {GOLD:Color("9b6812"), Color("97a5ba"):Color("47596b"), Color("57dba0"):Color("19734a"), Color("6aa9ff"):Color("205fb0"), Color("c78cff"):Color("7532b2"), Color("ffc66b"):Color("966400")}
		if readable.has(opaque):
			return Color(readable[opaque], color.a)
	if color.a >= 0.95 and color.get_luminance() < 0.20:
		return Color(str(palette.panel))
	return color

static func font(bold: bool = false) -> Font:
	return load("res://assets/fonts/ClubSans-Bold.ttf" if bold else "res://assets/fonts/ClubSans.ttf")

static func box(color: Color = PANEL, radius: int = 18, border: Color = Color.TRANSPARENT, padding: int = 22) -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = shade(color)
	style.set_corner_radius_all(radius)
	style.set_border_width_all(1 if border.a > 0.0 else 0)
	style.border_color = shade(border)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = padding
	style.content_margin_bottom = padding
	return style

static func make_theme() -> Theme:
	var theme = Theme.new()
	theme.default_font = font()
	theme.default_font_size = 20 if touch else 17
	theme.set_color("font_color", "Label", shade(TEXT))
	theme.set_color("font_color", "Button", shade(TEXT))
	theme.set_color("font_hover_color", "Button", shade(TEXT))
	theme.set_color("font_pressed_color", "Button", shade(TEXT))
	theme.set_color("font_disabled_color", "Button", shade(MUTED).darkened(0.1))
	theme.set_stylebox("normal", "Button", box(PANEL_LIGHT, 12, LINE, 14))
	theme.set_stylebox("hover", "Button", box(Color("243239"), 12, Color("61715c"), 14))
	theme.set_stylebox("pressed", "Button", box(Color("314536"), 12, LIME, 14))
	theme.set_stylebox("disabled", "Button", box(Color("141d21"), 12, Color("223035"), 14))
	theme.set_stylebox("focus", "Button", box(Color.TRANSPARENT, 12, LIME, 0))
	theme.set_stylebox("normal", "LineEdit", box(PANEL, 12, LINE, 14))
	theme.set_stylebox("focus", "LineEdit", box(PANEL_LIGHT, 12, LIME, 14))
	theme.set_color("font_color", "LineEdit", shade(TEXT))
	theme.set_color("font_placeholder_color", "LineEdit", shade(MUTED))
	theme.set_color("caret_color", "LineEdit", LIME)
	theme.set_stylebox("background", "ProgressBar", box(Color("283238"), 4, Color.TRANSPARENT, 0))
	theme.set_stylebox("fill", "ProgressBar", box(LIME, 4, Color.TRANSPARENT, 0))
	theme.set_stylebox("panel", "PopupMenu", box(PANEL_LIGHT, 12, LINE, 10))
	theme.set_color("font_color", "PopupMenu", shade(TEXT))
	theme.set_constant("v_separation", "PopupMenu", 12)
	for key in ["scroll", "grabber", "grabber_highlight", "grabber_pressed"]:
		var color = Color("182228") if key == "scroll" else (Color("3d5059") if key == "grabber" else Color("657d71"))
		var scrollbar = box(color, 5, Color.TRANSPARENT, 0)
		scrollbar.content_margin_left = 6
		scrollbar.content_margin_right = 6
		theme.set_stylebox(key, "VScrollBar", scrollbar)
	theme.set_constant("separation", "VBoxContainer", 14)
	theme.set_constant("separation", "HBoxContainer", 14)
	return theme

static func label(text: String, font_size: int = 17, color: Color = TEXT, bold: bool = false) -> Label:
	var result = Label.new()
	result.text = text
	result.add_theme_font_size_override("font_size", font_size)
	if touch:
		result.add_theme_font_size_override("font_size", maxi(17, font_size))
	result.add_theme_color_override("font_color", shade(color))
	if bold:
		result.add_theme_font_override("font", font(true))
	return result

static func button(text: String, callback: Callable, primary: bool = false, height: float = 52) -> Button:
	var result = Button.new()
	result.text = text
	result.custom_minimum_size.y = maxf(68, height) if touch else height
	result.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	result.add_theme_font_size_override("font_size", 20 if touch else 16)
	if primary:
		result.add_theme_stylebox_override("normal", box(LIME, 12, Color.TRANSPARENT, 16))
		result.add_theme_stylebox_override("hover", box(shade(LIME).lightened(0.10), 12, Color.TRANSPARENT, 16))
		result.add_theme_stylebox_override("pressed", box(shade(LIME).darkened(0.12), 12, Color.TRANSPARENT, 16))
		var foreground = Color.WHITE if selected == "white" else BG
		result.add_theme_color_override("font_color", foreground)
		result.add_theme_color_override("font_hover_color", foreground)
		result.add_theme_color_override("font_pressed_color", foreground)
		result.add_theme_font_override("font", font(true))
	if callback.is_valid():
		result.pressed.connect(callback)
	return result

static func tag(text: String, color: Color = LIME) -> PanelContainer:
	var result = PanelContainer.new()
	result.add_theme_stylebox_override("panel", box(Color(color, 0.10), 7, Color(color, 0.20), 8))
	var caption = label(text, 12, color, true)
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	result.add_child(caption)
	return result

static func panel(color: Color = PANEL, padding: int = 22, border: Color = LINE) -> PanelContainer:
	var result = PanelContainer.new()
	result.add_theme_stylebox_override("panel", box(color, 18, border, padding))
	return result

static func paragraph(text: String, font_size: int = 16, color: Color = MUTED) -> Label:
	var result = label(text, font_size, color)
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return result

static func spacer() -> Control:
	var result = Control.new()
	result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	result.size_flags_vertical = Control.SIZE_EXPAND_FILL
	result.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return result
