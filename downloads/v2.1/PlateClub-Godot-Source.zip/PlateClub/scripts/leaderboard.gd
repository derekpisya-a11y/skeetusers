class_name ClubLeaderboard
extends Node

var active: bool = false

func sync(state: ClubState) -> Dictionary:
	if active:
		return {"ok":false, "error":"Обновление уже выполняется."}
	var base = str(state.data.settings.online_url).strip_edges().trim_suffix("/")
	if not _valid_url(base):
		return {"ok":false, "error":"Укажите HTTPS-адрес сервера таблицы лидеров. Инструкция по размещению включена в проект."}
	active = true
	if str(state.data.settings.player_id).is_empty() or str(state.data.settings.player_token).is_empty():
		var registration = await _request(base + "/v1/register", HTTPClient.METHOD_POST, {"name":state.data.settings.player_name})
		if not registration.get("ok", false):
			active = false
			return registration
		state.data.settings.player_id = str(registration.get("id", ""))
		state.data.settings.player_token = str(registration.get("token", ""))
		state.save_game()
	var stats = {"generated":int(state.data.stats.generated), "exchanged":int(state.data.stats.exchanged), "cars":state.data.cars.size(), "legendary_generated":int(state.data.stats.legendary_generated)}
	var submitted = await _request(base + "/v1/score", HTTPClient.METHOD_POST, {"id":state.data.settings.player_id, "name":state.data.settings.player_name, "stats":stats}, str(state.data.settings.player_token))
	if not submitted.get("ok", false):
		active = false
		return submitted
	var result = await _request(base + "/v1/leaderboard", HTTPClient.METHOD_GET)
	active = false
	return result

func _request(url: String, method: HTTPClient.Method, payload: Dictionary = {}, token: String = "") -> Dictionary:
	var request = HTTPRequest.new()
	request.timeout = 12.0
	request.body_size_limit = 262144
	add_child(request)
	var headers = PackedStringArray(["Content-Type: application/json"])
	if not token.is_empty():
		headers.append("Authorization: Bearer " + token)
	var error = request.request(url, headers, method, "" if method == HTTPClient.METHOD_GET else JSON.stringify(payload))
	if error != OK:
		request.queue_free()
		return {"ok":false, "error":"Не удалось начать запрос к серверу."}
	var reply: Array = await request.request_completed
	request.queue_free()
	if int(reply[0]) != HTTPRequest.RESULT_SUCCESS:
		return {"ok":false, "error":"Сервер недоступен. Проверьте адрес и подключение."}
	var decoded: Variant = JSON.parse_string((reply[3] as PackedByteArray).get_string_from_utf8())
	if not decoded is Dictionary:
		return {"ok":false, "error":"Сервер вернул неподходящий ответ."}
	if int(reply[1]) < 200 or int(reply[1]) >= 300:
		return {"ok":false, "error":str(decoded.get("error", "Ошибка сервера"))}
	decoded.ok = true
	return decoded

func _valid_url(url: String) -> bool:
	return url.begins_with("https://") or url.begins_with("http://127.0.0.1:") or url.begins_with("http://localhost:")
