class_name PlateLore
extends RefCounted

const REGIONS = {"77":"Москва", "97":"Москва", "99":"Москва", "177":"Москва", "197":"Москва", "777":"Москва", "799":"Москва", "78":"Санкт-Петербург", "98":"Санкт-Петербург", "178":"Санкт-Петербург", "198":"Санкт-Петербург", "42":"Кемеровская область — Кузбасс", "142":"Кемеровская область — Кузбасс", "67":"Смоленская область", "23":"Краснодарский край", "123":"Краснодарский край", "16":"Татарстан", "116":"Татарстан", "54":"Новосибирская область", "154":"Новосибирская область", "66":"Свердловская область", "196":"Свердловская область"}
const REFERENCE_URL = "https://ru.wikipedia.org/wiki/Регистрационные_знаки_транспортных_средств_в_России"
# Historical associations are NOT ownership lookups. Never infer a person
# or office from a registration. These are collector lore awaiting web review.
const SERIES = [
	{"letters":"AMP", "label":"АМР", "regions":["97"], "title":"АМР 97 — известная спецсерия", "description":"В публичных справочниках серия исторически связывается с автопарками федеральных органов власти. Не определяет должность или владельца конкретной машины.", "status":"Историческая атрибуция; веб-проверка ожидается", "source":REFERENCE_URL},
	{"letters":"EKX", "label":"ЕКХ", "regions":["77","97","99"], "title":"ЕКХ — историческая спецсерия", "description":"В автомобильной среде серия связывается с федеральной охраной. Это не официальное подтверждение принадлежности конкретного номера.", "status":"Неофициальная атрибуция; веб-проверка ожидается", "source":REFERENCE_URL},
	{"letters":"AAA", "label":"ААА", "regions":["77"], "title":"ААА 77 — коллекционная московская серия", "description":"Известная буквенная комбинация старых московских выпусков. Исторический интерес и повтор букв; конкретный владелец неизвестен.", "status":"Коллекционная серия; веб-проверка ожидается", "source":REFERENCE_URL},
	{"letters":"AMO", "label":"АМО", "regions":["77"], "title":"АМО 77 — московская серия", "description":"В неофициальных справочниках связывается с московскими административными автопарками. Современная принадлежность по буквам не устанавливается.", "status":"Неофициальная атрибуция; веб-проверка ожидается", "source":REFERENCE_URL},
	{"letters":"OOO", "label":"ООО", "regions":["78","98"], "title":"ООО — петербургская коллекционная серия", "description":"Три одинаковые буквы и петербургский регион. В игре редкость коллекционная; сведения о конкретном ведомстве не утверждаются.", "status":"Красивое сочетание, без утверждения о владельце", "source":REFERENCE_URL},
]

static func parts(plate: Dictionary) -> Dictionary:
	var letters = ""
	var digits = str(plate.get("serial", ""))
	for character in str(plate.get("text", "")):
		if character >= "0" and character <= "9":
			if digits.is_empty():
				continue
		elif (character.to_upper() >= "A" and character.to_upper() <= "Z") or character.to_upper() in "АВЕКМНОРСТУХあさすせそたてと":
			letters += character.to_upper()
	if digits.is_empty():
		for character in str(plate.get("text", "")):
			if character >= "0" and character <= "9":
				digits += character
	return {"letters":letters, "digits":digits}

static func reasons(plate: Dictionary) -> Array[Dictionary]:
	var output: Array[Dictionary] = []
	var tokens = parts(plate)
	var letters: String = str(tokens.letters)
	var digits: String = str(tokens.digits)
	var special = series(plate)
	if not special.is_empty():
		output.append({"part":"letters", "title":special.title, "text":special.description + "\n" + special.status})
	elif letters.length() >= 3 and letters[0] == letters[1] and letters[1] == letters[2]:
		output.append({"part":"letters", "title":"Три одинаковые буквы: " + letters, "text":"Повтор всей буквенной серии — красивое коллекционное сочетание."})
	elif letters.length() >= 2 and letters[0] == letters[-1]:
		output.append({"part":"letters", "title":"Зеркальные буквы: " + letters, "text":"Одинаковые буквы на краях серии."})
	else:
		output.append({"part":"letters", "title":"Буквенная серия: " + letters, "text":"Обычная буквенная комбинация; особая ведомственная принадлежность не установлена."})
	if digits.length() >= 3 and digits == digits[0].repeat(digits.length()):
		output.append({"part":"digits", "title":"Все цифры одинаковые: " + digits, "text":"Заметная комбинация из повторяющихся цифр."})
	elif digits in ["001","0001","007","0007"]:
		output.append({"part":"digits", "title":"Малый порядковый номер: " + digits, "text":"Малые номера ценятся коллекционерами. Число само по себе не подтверждает высокий статус владельца."})
	elif digits in ["123","321","1234","4321"]:
		output.append({"part":"digits", "title":"Последовательность: " + digits, "text":"Цифры идут по порядку — вперёд или назад."})
	elif digits.length() >= 3 and digits == _reverse(digits):
		output.append({"part":"digits", "title":"Зеркальные цифры: " + digits, "text":"Комбинация читается одинаково в обе стороны."})
	else:
		output.append({"part":"digits", "title":"Цифровая часть: " + digits, "text":"Обычная цифровая комбинация. Редкость может быть связана с буквенной серией."})
	if str(plate.get("country", "")) == "ru":
		var region: String = str(plate.get("region", ""))
		output.append({"part":"region", "title":"Регион " + region, "text":str(REGIONS.get(region, "Регион отсутствует в текущем кратком справочнике")) + ". Код региона не определяет должность владельца."})
	return output

static func series(plate: Dictionary) -> Dictionary:
	if str(plate.get("country", "")) != "ru":
		return {}
	var letters: String = str(parts(plate).letters)
	for item in SERIES:
		if item.letters == letters and item.regions.has(str(plate.get("region", ""))):
			return item
	return {}

static func _reverse(text: String) -> String:
	var result = ""
	for i in range(text.length() - 1, -1, -1):
		result += text[i]
	return result
