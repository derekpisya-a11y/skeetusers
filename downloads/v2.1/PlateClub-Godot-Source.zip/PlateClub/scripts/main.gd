extends Control

const T = preload("res://scripts/club_theme.gd")
const PAGE_NAMES = {"generator":"Генератор", "collection":"Коллекция", "contracts":"Контракты", "garage":"Гараж", "vault":"Сейф", "quests":"Задания", "themes":"Темы", "leaderboard":"Лидеры", "progress":"Достижения"}

var mobile_ui: bool = false
var dollar_label: Label
var online: ClubLeaderboard
var lore_view: PlateView
var lore_caption: Label
var lore_token: int = 0
var state: ClubState
var sound: ClubSound
var current_page: String = "generator"
var selected_country: String = "ru"
var selected_region: String = "jp"
var selected_tier: String = "street"
var selected_plate_ids: Array = []
var collection_country: String = "all"
var collection_rarity: int = -1
var collection_favorites: bool = false
var collection_query: String = ""
var collection_sort: int = 0
var sale_selection: Array = []
var sale_visible_ids: Array = []
var sale_summary: Label
var sell_selected_button: Button
var sell_all_button: Button
var sale_select_visible_button: Button
var sale_clear_button: Button
var garage_region: String = "all"
var garage_owned: bool = false
var busy: bool = false
var nav_buttons: Dictionary = {}
var content: VBoxContainer
var page_host: VBoxContainer
var coin_label: Label
var rank_label: Label
var breadcrumb: Label
var daily_button: Button
var job_button: Button
var audio_button: Button
var save_status: Label
var collection_grid: GridContainer
var collection_counter: Label
var featured_plate: PlateView
var generate_button: Button
var modal_layer: CanvasLayer
var modal_root: Control
var toast_layer: CanvasLayer
var toast_control: PanelContainer
var toast_tween: Tween
var exchange_status: Label
var exchange_button: Button
var exchange_candidates: VBoxContainer
var selection_buttons: Dictionary = {}
var tick: float = 0.0

func _ready() -> void:
	mobile_ui = OS.has_feature("android") or OS.get_cmdline_user_args().has("--portrait")
	T.touch = mobile_ui
	if mobile_ui:
		get_window().min_size = Vector2i(270, 480)
		get_window().content_scale_size = Vector2i(540, 960)
	state = ClubState.new()
	var override_path = OS.get_environment("PLATE_CLUB_SAVE_PATH")
	if not override_path.is_empty():
		state.configure(override_path)
	add_child(state)
	state.load_game()
	T.choose(str(state.data.settings.theme))
	theme = T.make_theme()
	online = ClubLeaderboard.new()
	add_child(online)
	sound = ClubSound.new()
	add_child(sound)
	sound.enabled = bool(state.data.get("settings", {}).get("sound", true))
	_build_shell()
	state.changed.connect(_refresh_header)
	_refresh_header()
	show_page("generator")
	if state.recovered_save:
		_toast("Сохранение восстановлено из резервной копии.")
	get_tree().auto_accept_quit = false
	get_tree().quit_on_go_back = false

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		if state != null:
			state.save_game()
		get_tree().quit()
	elif what == NOTIFICATION_APPLICATION_PAUSED and state != null:
		state.save_game()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if is_instance_valid(modal_root):
			_close_modal()
		elif current_page != "generator":
			show_page("generator")
		else:
			state.save_game()
			get_tree().quit()

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if is_instance_valid(modal_root):
				_close_modal()
			elif current_page != "generator":
				show_page("generator")
		elif event.keycode == KEY_SPACE and current_page == "generator" and not is_instance_valid(modal_root):
			_generate()
		elif event.keycode == KEY_F11:
			var is_full = DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if is_full else DisplayServer.WINDOW_MODE_FULLSCREEN)

func _process(delta: float) -> void:
	tick += delta
	if tick >= 0.5:
		tick = 0.0
		if is_instance_valid(job_button):
			var remaining = state.job_remaining()
			job_button.text = "Заказ клуба  ·  %d c" % remaining if remaining > 0 else "Заказ клуба  +150"
			job_button.disabled = remaining > 0
		if is_instance_valid(daily_button):
			daily_button.text = "Подарок получен" if not state.daily_available() else "Подарок дня  +1 200"
			daily_button.disabled = not state.daily_available()

func _build_shell() -> void:
	if mobile_ui:
		_build_mobile_shell()
		return
	var background = ColorRect.new()
	background.color = T.shade(T.BG)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)
	var shell = HBoxContainer.new()
	shell.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shell.add_theme_constant_override("separation", 0)
	add_child(shell)
	var sidebar = T.panel(Color("10181c"), 22, Color.TRANSPARENT)
	sidebar.custom_minimum_size.x = 234
	sidebar.add_theme_stylebox_override("panel", T.box(Color("10181c"), 0, Color.TRANSPARENT, 22))
	shell.add_child(sidebar)
	var side = VBoxContainer.new()
	side.add_theme_constant_override("separation", 12)
	sidebar.add_child(side)
	var logo_row = HBoxContainer.new()
	logo_row.add_theme_constant_override("separation", 11)
	side.add_child(logo_row)
	var icon = TextureRect.new()
	icon.texture = preload("res://assets/icon.svg")
	icon.custom_minimum_size = Vector2(46, 46)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo_row.add_child(icon)
	logo_row.add_child(T.label("НОМЕРНОЙ\nКЛУБ", 17, T.TEXT, true))
	var edition = T.label("COLLECTOR’S EDITION  /  01", 10, T.MUTED)
	edition.custom_minimum_size.y = 37
	side.add_child(edition)
	var index = 1
	for page in ["generator", "collection", "contracts", "garage", "vault"]:
		var key: String = page
		var button = T.button("%02d    %s" % [index, PAGE_NAMES[page]], func(): show_page(key), false, 58)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.add_theme_font_size_override("font_size", 15)
		side.add_child(button)
		nav_buttons[page] = button
		index += 1
	side.add_child(T.button("☰    Все разделы", _open_menu, false, 52))
	side.add_child(T.spacer())
	var gift = T.panel(Color("18241e"), 14, Color("314731"))
	side.add_child(gift)
	var gift_content = VBoxContainer.new()
	gift_content.add_theme_constant_override("separation", 8)
	gift.add_child(gift_content)
	gift_content.add_child(T.label("КЛУБ ЗАБОТИТСЯ", 11, T.LIME, true))
	gift_content.add_child(T.paragraph("Новая коллекция\nкаждый день.", 14, T.TEXT))
	daily_button = T.button("Подарок дня  +1 200", _daily, false, 47)
	daily_button.add_theme_font_size_override("font_size", 12)
	gift_content.add_child(daily_button)
	job_button = T.button("Заказ клуба  +150", _job, false, 47)
	job_button.add_theme_font_size_override("font_size", 13)
	side.add_child(job_button)
	var footer = HBoxContainer.new()
	footer.add_theme_constant_override("separation", 8)
	side.add_child(footer)
	audio_button = T.button("Звук: вкл", _toggle_sound, false, 42)
	audio_button.add_theme_font_size_override("font_size", 12)
	audio_button.size_flags_horizontal = SIZE_EXPAND_FILL
	footer.add_child(audio_button)
	var help_button = T.button("?", _help, false, 42)
	help_button.custom_minimum_size.x = 42
	footer.add_child(help_button)
	save_status = T.label("●  ОФЛАЙН  ·  АВТОСОХРАНЕНИЕ", 10, T.MUTED)
	side.add_child(save_status)
	var main_margin = MarginContainer.new()
	main_margin.size_flags_horizontal = SIZE_EXPAND_FILL
	for edge in ["left", "right"]:
		main_margin.add_theme_constant_override("margin_" + edge, 32)
	main_margin.add_theme_constant_override("margin_top", 24)
	main_margin.add_theme_constant_override("margin_bottom", 20)
	shell.add_child(main_margin)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 20)
	main_margin.add_child(content)
	var top = HBoxContainer.new()
	top.custom_minimum_size.y = 43
	content.add_child(top)
	breadcrumb = T.label("КЛУБ  /  ГЕНЕРАТОР", 12, T.MUTED, true)
	top.add_child(breadcrumb)
	top.add_child(T.spacer())
	rank_label = T.label("УРОВЕНЬ 01", 12, T.MUTED, true)
	top.add_child(rank_label)
	var coins = T.panel(Color("202923"), 12, Color("394a31"))
	top.add_child(coins)
	coin_label = T.label("◈  2 500", 17, T.LIME, true)
	coins.add_child(coin_label)
	dollar_label = T.label("$ 0", 17, T.GOLD, true)
	top.add_child(dollar_label)
	var separator = HSeparator.new()
	separator.add_theme_stylebox_override("separator", T.box(T.LINE, 0, Color.TRANSPARENT, 0))
	content.add_child(separator)
	var scroll = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = SIZE_EXPAND_FILL
	content.add_child(scroll)
	page_host = VBoxContainer.new()
	page_host.size_flags_horizontal = SIZE_EXPAND_FILL
	page_host.add_theme_constant_override("separation", 23)
	scroll.add_child(page_host)
	modal_layer = CanvasLayer.new()
	modal_layer.layer = 10
	add_child(modal_layer)
	toast_layer = CanvasLayer.new()
	toast_layer.layer = 20
	add_child(toast_layer)

func _refresh_header() -> void:
	if coin_label == null:
		return
	coin_label.text = "◈  " + _number(int(state.data.get("coins", 0)))
	rank_label.text = "УРОВЕНЬ %02d  ·  %s" % [_level(), _rank_name()]
	if mobile_ui:
		rank_label.text = "УР. %02d" % _level()
	if is_instance_valid(audio_button):
		audio_button.text = "Звук: вкл" if sound.enabled else "Звук: выкл"
	if is_instance_valid(dollar_label):
		dollar_label.text = "$  " + _number(int(state.data.dollars))
	if not state.last_save_error.is_empty():
		save_status.text = "!  НЕ УДАЛОСЬ СОХРАНИТЬ"
		save_status.add_theme_color_override("font_color", T.RED)
		save_status.tooltip_text = state.last_save_error
	else:
		save_status.text = "●  ОФЛАЙН  ·  АВТОСОХРАНЕНИЕ"
		save_status.add_theme_color_override("font_color", T.MUTED)
		save_status.tooltip_text = "Прогресс сохранён на этом устройстве"

func show_page(page: String) -> void:
	if busy:
		return
	_close_modal()
	current_page = page
	for child in page_host.get_children():
		page_host.remove_child(child)
		child.queue_free()
	for key in nav_buttons:
		var button: Button = nav_buttons[key]
		button.add_theme_stylebox_override("normal", T.box(Color("263526") if key == page else Color.TRANSPARENT, 11, Color("3c5331") if key == page else Color.TRANSPARENT, 14))
		button.add_theme_color_override("font_color", T.shade(T.LIME if key == page else T.MUTED))
	breadcrumb.text = "КЛУБ  /  " + str(PAGE_NAMES[page]).to_upper()
	match page:
		"generator": _page_generator()
		"collection": _page_collection()
		"contracts": _page_contracts()
		"garage": _page_garage()
		"progress": _page_progress()
		"vault": _page_vault()
		"quests": _page_quests()
		"themes": _page_themes()
		"leaderboard": _page_leaderboard()
	page_host.modulate.a = 0.0
	create_tween().tween_property(page_host, "modulate:a", 1.0, 0.16)
	var scroll = page_host.get_parent() as ScrollContainer
	scroll.scroll_vertical = 0
	_adapt_controls(page_host)

func _heading(title: String, subtitle: String, badge: String = "") -> void:
	var row: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	page_host.add_child(row)
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	column.size_flags_horizontal = SIZE_EXPAND_FILL
	row.add_child(column)
	var heading = T.paragraph(title, 29, T.TEXT) if mobile_ui else T.label(title, 35, T.TEXT, true)
	column.add_child(heading)
	column.add_child(T.paragraph(subtitle, 16))
	if not badge.is_empty():
		var tag = T.tag(badge)
		tag.size_flags_vertical = SIZE_SHRINK_CENTER
		row.add_child(tag)

func _page_generator() -> void:
	_heading("Твой следующий номер." if mobile_ui else "Охота за красивыми номерами.", "Выпускай номера. Коллекционируй истории." if mobile_ui else "От первого выпуска — до автомобиля мечты. Твоя коллекция начинается здесь.", "8 СТРАН")
	var country_row: Container = GridContainer.new() if mobile_ui else HBoxContainer.new()
	if country_row is GridContainer:
		country_row.columns = 1
	country_row.add_theme_constant_override("separation", 8)
	page_host.add_child(country_row)
	if mobile_ui:
		var picker = OptionButton.new()
		picker.custom_minimum_size.y = 68
		picker.size_flags_horizontal = SIZE_EXPAND_FILL
		var index = 0
		for country in GameCatalog.COUNTRIES:
			picker.add_item(str(country.id).to_upper() + "  /  " + str(country.name))
			if str(country.id) == selected_country:
				picker.select(index)
			index += 1
		country_row.add_child(picker)
		picker.item_selected.connect(func(value):
			selected_country = str(GameCatalog.COUNTRIES[value].id)
			show_page("generator"))
	else:
		for country in GameCatalog.COUNTRIES:
			var cid: String = country.id
			var button = T.button(cid.to_upper() + "  " + ("Британия" if cid == "gb" else str(country.name)), func():
				selected_country = cid
				show_page("generator"), false, 47)
			button.size_flags_horizontal = SIZE_EXPAND_FILL
			button.add_theme_font_size_override("font_size", 12)
			if cid == selected_country:
				button.add_theme_stylebox_override("normal", T.box(Color("273725"), 10, T.LIME, 10))
				button.add_theme_color_override("font_color", T.LIME)
			country_row.add_child(button)
	var columns: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	columns.add_theme_constant_override("separation", 20)
	page_host.add_child(columns)
	var generator = T.panel(T.PANEL, 0)
	generator.size_flags_horizontal = SIZE_EXPAND_FILL
	columns.add_child(generator)
	var generator_content = VBoxContainer.new()
	generator_content.add_theme_constant_override("separation", 0)
	generator.add_child(generator_content)
	var stage = Control.new()
	stage.custom_minimum_size.y = 236 if mobile_ui else 302
	generator_content.add_child(stage)
	var studio = StudioView.new()
	studio.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stage.add_child(studio)
	var stage_top = HBoxContainer.new()
	stage_top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	stage_top.offset_left = 24
	stage_top.offset_right = -24
	stage_top.offset_top = 20
	stage.add_child(stage_top)
	stage_top.add_child(T.tag("ВЫПУСК  /  " + str(GameCatalog.country(selected_country).name).to_upper()))
	var last = state.data.get("last_plate", {})
	if last.is_empty():
		last = {"country": "RU", "text": "А 777 АА", "region": "77", "rarity": 4}
	featured_plate = PlateView.new()
	featured_plate.plate = last
	featured_plate.anchor_left = 0.09
	featured_plate.anchor_right = 0.91
	featured_plate.anchor_top = 0.24
	featured_plate.anchor_bottom = 0.70
	stage.add_child(featured_plate)
	var note = T.label("Последний выпущенный номер" if not state.data.get("last_plate", {}).is_empty() else "Твой следующий трофей?", 13, T.MUTED)
	note.anchor_left = 0.0
	note.anchor_right = 1.0
	note.anchor_top = 0.77
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stage.add_child(note)
	var actions = MarginContainer.new()
	for edge in ["left", "right", "bottom"]:
		actions.add_theme_constant_override("margin_" + edge, 22)
	generator_content.add_child(actions)
	var action_column = VBoxContainer.new()
	actions.add_child(action_column)
	generate_button = T.button("Выпустить номер     ·     100 ◈", _generate, true, 62)
	generate_button.add_theme_font_size_override("font_size", 18)
	action_column.add_child(generate_button)
	var hint = T.paragraph("Сохранение после каждого выпуска" if mobile_ui else "Пробел — выпуск · Каждый номер сохраняется автоматически", 12, T.MUTED)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	action_column.add_child(hint)
	var right = T.panel(Color("171f20"), 23)
	right.custom_minimum_size.x = 0 if mobile_ui else 290
	columns.add_child(right)
	var info = VBoxContainer.new()
	info.add_theme_constant_override("separation", 10)
	right.add_child(info)
	info.add_child(T.label("ПЯТЬ СТЕПЕНЕЙ РЕДКОСТИ", 11, T.LIME, true))
	info.add_child(T.label("Не просто\nкомбинация.", 27, T.TEXT, true))
	info.add_child(T.paragraph("Повторы и красивые серии повышают ценность. Обменивай находки на автомобили.", 14))
	var odds = [64, 25, 9, 1.8, 0.2]
	for i in 5:
		var row = HBoxContainer.new()
		info.add_child(row)
		row.add_child(T.label("●  " + str(GameCatalog.rarity(i).name), 13, _rarity_color(i)))
		row.add_child(T.spacer())
		row.add_child(T.label(str(odds[i]) + "%", 13, T.MUTED))
	info.add_child(T.spacer())
	var goto_contract = T.button("Номера → автомобили  ↗", func(): show_page("contracts"), false, 48)
	goto_contract.add_theme_font_size_override("font_size", 14)
	info.add_child(goto_contract)
	var recent_top = HBoxContainer.new()
	page_host.add_child(recent_top)
	recent_top.add_child(T.label("Последние находки", 21, T.TEXT, true))
	recent_top.add_child(T.spacer())
	var all_btn = T.button("Вся коллекция  →", func(): show_page("collection"), false, 40)
	all_btn.add_theme_font_size_override("font_size", 13)
	recent_top.add_child(all_btn)
	var recent: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	recent.add_theme_constant_override("separation", 14)
	page_host.add_child(recent)
	var plates: Array = state.data.plates.filter(func(plate): return not plate.get("in_vault", false))
	var count = mini(3, plates.size())
	for i in count:
		var plate: Dictionary = plates[plates.size() - 1 - i]
		var card = _plate_card(plate, true)
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		recent.add_child(card)
	if count == 0:
		recent.add_child(T.paragraph("Здесь появятся твои номера. Начни с первого выпуска.", 16))

func _generate() -> void:
	if busy or is_instance_valid(modal_root):
		return
	var result: Dictionary = state.generate_plate(selected_country)
	if not result.get("ok", false):
		_toast(result.get("error", "Не удалось выпустить номер"), true)
		return
	busy = true
	sound.play("roll")
	generate_button.disabled = true
	generate_button.text = "Подбираем комбинацию…"
	for i in 8:
		if not is_instance_valid(featured_plate):
			break
		featured_plate.plate = {"country": selected_country, "text": "%03d" % randi_range(1, 999), "region": "77", "rarity": 0}
		await get_tree().create_timer(0.055 + float(i) * 0.009).timeout
	busy = false
	show_page("generator")
	var plate: Dictionary = result.plate
	sound.play("reward" if int(plate.rarity) >= 2 else "coin")
	_toast("Новый номер  ·  " + str(plate.text) + "  ·  " + str(GameCatalog.rarity(int(plate.rarity)).name))
	if int(plate.rarity) >= 3:
		_show_lore(plate)
	elif is_instance_valid(featured_plate):
		var reasons = PlateLore.reasons(plate)
		_toast(str(reasons[0].title) + " · " + str(reasons[1].title))

func _plate_card(plate: Dictionary, small: bool = false, selectable: bool = false) -> PanelContainer:
	var rarity: int = int(plate.rarity)
	var card = T.panel(T.PANEL, 15, Color(_rarity_color(rarity), 0.25))
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	card.add_child(column)
	var row = HBoxContainer.new()
	column.add_child(row)
	row.add_child(T.label(str(plate.country).to_upper() + "  /  " + str(GameCatalog.country(str(plate.country)).name), 11, T.MUTED))
	row.add_child(T.spacer())
	if bool(plate.get("favorite", false)):
		row.add_child(T.label("★", 15, T.GOLD))
	if not str(plate.get("equipped_to", "")).is_empty():
		row.add_child(T.label("НА АВТО", 10, T.LIME))
	var view = PlateView.new()
	view.plate = plate
	view.compact = true
	view.custom_minimum_size.y = 64 if small else 84
	column.add_child(view)
	var bottom = HBoxContainer.new()
	column.add_child(bottom)
	bottom.add_child(T.label("● " + str(GameCatalog.rarity(rarity).name), 12, _rarity_color(rarity)))
	bottom.add_child(T.spacer())
	var open = T.button("Открыть  ↗", func(): _open_plate_details(plate), false, 37)
	open.add_theme_font_size_override("font_size", 12)
	bottom.add_child(open)
	if selectable:
		var pick = CheckBox.new()
		var uid: String = str(plate.uid)
		pick.set_meta("sale_uid", uid)
		pick.disabled = bool(plate.get("favorite", false)) or bool(plate.get("in_vault", false)) or not str(plate.get("equipped_to", "")).is_empty()
		pick.text = "Защищён от продажи" if pick.disabled else "Выбрать · %s ◈" % _number(int(GameCatalog.rarity(rarity).sell_value))
		pick.button_pressed = not pick.disabled and sale_selection.has(uid)
		pick.custom_minimum_size.y = 48
		pick.toggled.connect(func(enabled: bool):
			if enabled and not sale_selection.has(uid):
				sale_selection.append(uid)
			elif not enabled:
				sale_selection.erase(uid)
			_refresh_sale_controls())
		column.add_child(pick)
	return card

func _page_collection() -> void:
	if mobile_ui:
		_page_collection_mobile()
		return
	_heading("Каждый номер — история.", "Сохраняй любимые. Продавай лишние. Обменивай редкие на автомобили.", "%d / %d МЕСТ" % [state.collection_count(), int(state.data.collection_capacity)])
	page_host.add_child(T.button("+25 мест за %s ◈" % _number(state.collection_upgrade_cost()), func(): _perform(state.expand_collection(), "Коллекция расширена", "collection")))
	var filters: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	page_host.add_child(filters)
	var search = LineEdit.new()
	search.placeholder_text = "Найти номер…"
	search.text = collection_query
	search.custom_minimum_size = Vector2(180, 50)
	search.size_flags_horizontal = SIZE_EXPAND_FILL
	filters.add_child(search)
	search.text_changed.connect(func(value):
		collection_query = value
		_fill_collection())
	var country_options = OptionButton.new()
	country_options.custom_minimum_size.y = 50
	country_options.add_item("Все страны")
	var option_index = 1
	for country in GameCatalog.COUNTRIES:
		country_options.add_item(str(country.name))
		if str(country.id) == collection_country:
			country_options.select(option_index)
		option_index += 1
	filters.add_child(country_options)
	country_options.item_selected.connect(func(index):
		collection_country = "all" if index == 0 else str(GameCatalog.COUNTRIES[index - 1].id)
		_fill_collection())
	var rarity_options = OptionButton.new()
	rarity_options.custom_minimum_size.y = 50
	rarity_options.add_item("Любая редкость")
	for rarity in GameCatalog.RARITIES:
		rarity_options.add_item(str(rarity.name))
	rarity_options.select(collection_rarity + 1)
	filters.add_child(rarity_options)
	rarity_options.item_selected.connect(func(index):
		collection_rarity = index - 1
		_fill_collection())
	var favorites = T.button("★ Избранное", func():
		collection_favorites = not collection_favorites
		show_page("collection"), collection_favorites, 50)
	filters.add_child(favorites)
	var info: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	page_host.add_child(info)
	collection_counter = T.paragraph("", 13, T.MUTED)
	collection_counter.size_flags_horizontal = SIZE_EXPAND_FILL
	info.add_child(collection_counter)
	info.add_child(T.spacer())
	var sort = OptionButton.new()
	sort.add_item("Сначала новые")
	sort.add_item("Сначала редкие")
	sort.add_item("Сначала простые")
	sort.select(collection_sort)
	sort.custom_minimum_size.y = 40
	info.add_child(sort)
	sort.item_selected.connect(func(index):
		collection_sort = index
		_fill_collection())
	_collection_sale_controls()
	collection_grid = GridContainer.new()
	collection_grid.columns = 1 if mobile_ui else 3
	collection_grid.size_flags_horizontal = SIZE_EXPAND_FILL
	collection_grid.add_theme_constant_override("h_separation", 16)
	collection_grid.add_theme_constant_override("v_separation", 16)
	page_host.add_child(collection_grid)
	_fill_collection()

func _fill_collection() -> void:
	if not is_instance_valid(collection_grid):
		return
	for child in collection_grid.get_children():
		collection_grid.remove_child(child)
		child.queue_free()
	var filtered: Array = []
	for p in state.data.plates:
		if p.get("in_vault", false):
			continue
		if collection_country != "all" and str(p.country) != collection_country:
			continue
		if collection_rarity >= 0 and int(p.rarity) != collection_rarity:
			continue
		if collection_favorites and not bool(p.get("favorite", false)):
			continue
		if not collection_query.is_empty() and not (str(p.text) + str(p.get("region", ""))).to_lower().contains(collection_query.to_lower()):
			continue
		filtered.append(p)
	filtered.reverse()
	if collection_sort == 1:
		filtered.sort_custom(func(a, b): return int(a.rarity) > int(b.rarity))
	elif collection_sort == 2:
		filtered.sort_custom(func(a, b): return int(a.rarity) < int(b.rarity))
	collection_counter.text = "Показано: %d · Избранные и установленные номера защищены от продажи и обмена" % filtered.size()
	sale_visible_ids.clear()
	for plate in filtered:
		if not plate.favorite and str(plate.equipped_to).is_empty():
			sale_visible_ids.append(str(plate.uid))
		var card = _plate_card(plate, false, true)
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		collection_grid.add_child(card)
	if filtered.is_empty():
		var empty = T.paragraph("Здесь пока тихо.\nВыпусти новые номера или измени фильтры.", 20)
		empty.custom_minimum_size.y = 150
		collection_grid.add_child(empty)
	_refresh_sale_controls()
	if mobile_ui:
		_adapt_controls(collection_grid)

func _collection_sale_controls() -> void:
	var panel = T.panel()
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	panel.add_child(column)
	page_host.add_child(panel)
	sale_summary = T.paragraph("", 17 if mobile_ui else 14)
	column.add_child(sale_summary)
	var selection_row = HBoxContainer.new()
	column.add_child(selection_row)
	sale_select_visible_button = T.button("Выделить" if mobile_ui else "Выделить видимые", _select_visible_for_sale)
	sale_select_visible_button.tooltip_text = "Выбрать все доступные номера по текущим фильтрам"
	sale_select_visible_button.size_flags_horizontal = SIZE_EXPAND_FILL
	selection_row.add_child(sale_select_visible_button)
	sale_clear_button = T.button("Снять" if mobile_ui else "Снять выбор", func():
		sale_selection.clear()
		_fill_collection())
	sale_clear_button.size_flags_horizontal = SIZE_EXPAND_FILL
	selection_row.add_child(sale_clear_button)
	var actions: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	column.add_child(actions)
	sell_selected_button = T.button("Продать выбранные", func(): _confirm_bulk_sale(sale_selection), true)
	sell_selected_button.size_flags_horizontal = SIZE_EXPAND_FILL
	actions.add_child(sell_selected_button)
	sell_all_button = T.button("Продать все", _confirm_sell_all)
	sell_all_button.size_flags_horizontal = SIZE_EXPAND_FILL
	actions.add_child(sell_all_button)
	column.add_child(T.paragraph("«Продать все» продаёт все доступные номера коллекции, включая скрытые фильтром. Избранные, установленные и номера в сейфе сохраняются.", 16 if mobile_ui else 12))

func _refresh_sale_controls() -> void:
	var available: Dictionary = {}
	for plate in state.sellable_plates():
		available[str(plate.uid)] = true
	for i in range(sale_selection.size() - 1, -1, -1):
		if not available.has(str(sale_selection[i])):
			sale_selection.remove_at(i)
	if not is_instance_valid(sale_summary):
		return
	var preview: Dictionary = state.sale_preview(sale_selection)
	var hidden: int = 0
	for uid in sale_selection:
		if not sale_visible_ids.has(uid):
			hidden += 1
	sale_summary.text = "Выбрано: %d · Продажа: %s ◈" % [sale_selection.size(), _number(int(preview.get("value", 0)))]
	if hidden > 0:
		sale_summary.text += " · Скрыто фильтром: %d" % hidden
	sell_selected_button.disabled = sale_selection.is_empty()
	sell_all_button.disabled = available.is_empty()
	sale_clear_button.disabled = sale_selection.is_empty()
	sale_select_visible_button.disabled = sale_visible_ids.is_empty()

func _select_visible_for_sale() -> void:
	for uid in sale_visible_ids:
		if not sale_selection.has(uid):
			sale_selection.append(uid)
	_fill_collection()

func _confirm_sell_all() -> void:
	var uids: Array = []
	for plate in state.sellable_plates():
		uids.append(str(plate.uid))
	_confirm_bulk_sale(uids, true)

func _confirm_bulk_sale(uids: Array, all_plates: bool = false) -> void:
	var captured: Array = uids.duplicate()
	var preview: Dictionary = state.sale_preview(captured)
	if not preview.ok:
		_toast(str(preview.error), true)
		return
	var column = _modal("Продать все доступные номера?" if all_plates else "Продать выбранные номера?", "Продажа необратима. Проверь количество и сумму.", 650)
	column.add_child(T.label("%s · +%s ◈" % [_plate_amount(int(preview.count)), _number(int(preview.value))], 25, T.LIME, true))
	if all_plates:
		column.add_child(T.paragraph("Фильтры не ограничивают эту продажу. Защищённых номеров останется: %d (включая сейф)." % (state.data.plates.size() - int(preview.count)), 17))
	if int(preview.rare_count) > 0:
		column.add_child(T.paragraph("ВНИМАНИЕ: среди них эпических и легендарных номеров — %d. Отмени продажу и добавь нужные в избранное, чтобы сохранить их." % int(preview.rare_count), 17, T.GOLD))
	var listed: PackedStringArray = []
	for i in mini(12, preview.plates.size()):
		var plate: Dictionary = preview.plates[i]
		listed.append("%s %s · %s" % [plate.text, plate.get("region", ""), GameCatalog.rarity(int(plate.rarity)).name])
	column.add_child(T.paragraph("\n".join(listed), 16))
	if int(preview.count) > 12:
		column.add_child(T.paragraph("И ещё %d. Полная сумма показана выше." % (int(preview.count) - 12), 16))
	var confirm = T.button("Продать · +%s ◈" % _number(int(preview.value)), func(): _execute_bulk_sale(captured), true)
	confirm.set_meta("bulk_sale_confirm", true)
	column.add_child(confirm)
	column.add_child(T.button("Отмена", _close_modal))
	_adapt_controls(column)

func _execute_bulk_sale(uids: Array) -> void:
	var result: Dictionary = state.sell_plates(uids)
	if result.ok:
		_close_modal()
		show_page("collection")
		sound.play("coin")
		_toast("Продано: %d · +%s ◈" % [int(result.count), _number(int(result.value))])
	else:
		_close_modal()
		show_page("collection")
		_toast(str(result.error), true)

func _open_plate_details(plate: Dictionary, discovery: bool = false) -> void:
	var column = _modal("Редкая находка!" if discovery else "Карточка номера", str(GameCatalog.country(str(plate.country)).name) + "  /  " + str(GameCatalog.rarity(int(plate.rarity)).name), 600)
	var view = PlateView.new()
	view.plate = plate
	view.custom_minimum_size.y = 145
	column.add_child(view)
	for reason in PlateLore.reasons(plate):
		column.add_child(T.label(str(reason.title), 15, T.LIME, true))
		column.add_child(T.paragraph(str(reason.text), 14))
	column.add_child(T.paragraph("Красивые комбинации можно обменять на сундуки с автомобилями. Добавь номер в избранное, чтобы защитить его от продажи и обмена.", 15))
	var uid: String = str(plate.uid)
	var favorite = T.button("★ Убрать из избранного" if bool(plate.get("favorite", false)) else "☆ Сохранить в избранном", func():
		var result: Dictionary = state.toggle_favorite(uid)
		if result.get("ok", false):
			_close_modal()
			show_page(current_page)
			_toast("Избранное обновлено")
		else:
			_toast(result.get("error", "Не удалось обновить номер"), true))
	column.add_child(favorite)
	var equipped: bool = not str(plate.get("equipped_to", "")).is_empty()
	if equipped:
		column.add_child(T.tag("УСТАНОВЛЕН НА " + str(GameCatalog.car(str(plate.equipped_to)).get("name", "АВТОМОБИЛЬ"))))
	else:
		var equip_button = T.button("Установить на автомобиль  →", func(): _choose_car_for_plate(plate))
		equip_button.disabled = bool(plate.get("in_vault", false))
		column.add_child(equip_button)
	var in_vault: bool = bool(plate.get("in_vault", false))
	column.add_child(T.button("Вернуть из сейфа" if in_vault else "▣ Положить в сейф", func(): _perform(state.return_from_vault(uid) if in_vault else state.move_to_vault(uid), "Номер перемещён", "vault" if in_vault else "collection")))
	var sell_value = int(GameCatalog.rarity(int(plate.rarity)).sell_value)
	var sell = T.button("Продать за " + _number(sell_value) + " ◈", func(): _confirm_sell(plate))
	sell.disabled = equipped or in_vault or bool(plate.get("favorite", false))
	column.add_child(sell)

func _confirm_sell(plate: Dictionary) -> void:
	var column = _modal("Продать этот номер?", "Номер исчезнет из коллекции. Его нельзя будет восстановить.", 560)
	var plate_view = PlateView.new()
	plate_view.plate = plate
	plate_view.custom_minimum_size.y = 100
	column.add_child(plate_view)
	column.add_child(T.button("Продать за " + _number(int(GameCatalog.rarity(int(plate.rarity)).sell_value)) + " ◈", func():
		var result: Dictionary = state.sell_plate(str(plate.uid))
		if result.get("ok", false):
			_close_modal()
			show_page(current_page)
			sound.play("coin")
			_toast("Номер продан. Монеты зачислены.")
		else:
			_toast(result.get("error", "Не удалось продать номер"), true), true))
	column.add_child(T.button("Оставить в коллекции", func(): _open_plate_details(plate)))

func _choose_car_for_plate(plate: Dictionary) -> void:
	var column = _modal("Выбери автомобиль", "Один номер — один автомобиль. Предыдущий номер вернётся в коллекцию.", 680)
	if state.data.cars.is_empty():
		column.add_child(T.paragraph("В гараже пока нет машин. Открой первый сундук в разделе «Контракты».", 17))
		column.add_child(T.button("Перейти к контрактам", func(): show_page("contracts"), true))
		return
	for owned in state.data.cars:
		var car_id: String = str(owned.id)
		var car = GameCatalog.car(car_id)
		column.add_child(T.button(str(car.name) + ("  ·  номер установлен" if not str(owned.get("plate_uid", "")).is_empty() else "  →"), func():
			var result: Dictionary = state.equip_plate(car_id, str(plate.uid))
			if result.get("ok", false):
				show_page("garage")
				_toast("Номер установлен на " + str(car.name))
			else:
				_toast(result.get("error", "Не удалось установить номер"), true)))

func _page_contracts() -> void:
	_heading("Редкие номера. Новые ключи.", "Отдавай номера по контракту и получай автомобиль выбранной коллекции.", "БЕЗ РЕАЛЬНЫХ ПОКУПОК")
	var tier_row = HBoxContainer.new()
	page_host.add_child(tier_row)
	for tier in GameCatalog.CRATE_TIERS:
		var tid: String = str(tier.id)
		var button = T.button(str(tier.name), func():
			selected_tier = tid
			show_page("contracts"), tid == selected_tier, 52)
		button.size_flags_horizontal = SIZE_EXPAND_FILL
		tier_row.add_child(button)
	var tier = GameCatalog.tier(selected_tier)
	var rule_panel = T.panel(Color("18231e"), 17, Color("334831"))
	page_host.add_child(rule_panel)
	var rule_row: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	rule_panel.add_child(rule_row)
	var rule_text = VBoxContainer.new()
	rule_text.size_flags_horizontal = SIZE_EXPAND_FILL
	rule_row.add_child(rule_text)
	var fee_text = "  +  %s ◈" % _number(int(tier.fee)) if int(tier.fee) > 0 else ""
	rule_text.add_child(T.paragraph(_plate_amount(int(tier.count)) + ": %s и выше" % str(GameCatalog.rarity(int(tier.min_rarity)).name) + fee_text, 17, T.TEXT))
	rule_text.add_child(T.paragraph("Номера выбираешь ты. Избранные и установленные на машины не участвуют.", 13))
	var pity_remaining = 12 - int(state.data.get("pity", 0))
	rule_row.add_child(T.tag("ДО ГАРАНТИИ ЛЕГЕНДЫ: %d" % pity_remaining, T.GOLD))
	var grid = GridContainer.new()
	grid.columns = 1 if mobile_ui else 3
	grid.add_theme_constant_override("h_separation", 18)
	grid.add_theme_constant_override("v_separation", 18)
	page_host.add_child(grid)
	for region in GameCatalog.REGIONS:
		var rid: String = str(region.id)
		var accent = _region_color(rid)
		var card = T.panel(T.PANEL, 20, Color(accent, 0.23))
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		grid.add_child(card)
		var column = VBoxContainer.new()
		column.add_theme_constant_override("separation", 9)
		card.add_child(column)
		var top = HBoxContainer.new()
		column.add_child(top)
		top.add_child(T.tag(rid.to_upper() + " / 06", accent))
		top.add_child(T.spacer())
		top.add_child(T.label(str(tier.name).to_upper(), 10, T.MUTED))
		var crate = CrateView.new()
		crate.region_id = rid
		crate.tier_id = selected_tier
		crate.accent = accent
		crate.custom_minimum_size.y = 120
		column.add_child(crate)
		column.add_child(T.label(str(region.name), 21, T.TEXT, true))
		column.add_child(T.paragraph(str(region.subtitle), 12))
		column.add_child(T.button("Выбрать номера  →", func(): _open_exchange(rid, selected_tier), false, 46))
	var odds_parts: Array[String] = []
	for i in 5:
		if int(tier.odds[i]) > 0:
			odds_parts.append(str(GameCatalog.rarity(i).name) + " " + str(tier.odds[i]) + "%")
	page_host.add_child(T.paragraph("Шансы этого контракта: " + "  ·  ".join(odds_parts) + ". Повторная машина приносит компенсацию монетами. При гарантии шанс легендарной — 100%.", 12))

func _open_exchange(region_id: String, tier_id: String) -> void:
	selected_region = region_id
	selected_tier = tier_id
	selected_plate_ids = []
	selection_buttons = {}
	var tier = GameCatalog.tier(tier_id)
	var column = _modal("Контракт: " + str(GameCatalog.region(region_id).name), "Выбери " + _plate_amount(int(tier.count)) + " уровня «%s» или выше. Выбранные номера будут потрачены." % str(GameCatalog.rarity(int(tier.min_rarity)).name), 780)
	var info = HBoxContainer.new()
	column.add_child(info)
	exchange_status = T.label("", 15, T.LIME, true)
	info.add_child(exchange_status)
	info.add_child(T.spacer())
	info.add_child(T.button("Выбрать самые простые", _auto_select_plates, false, 42))
	exchange_candidates = VBoxContainer.new()
	exchange_candidates.add_theme_constant_override("separation", 10)
	column.add_child(exchange_candidates)
	var eligible: Array = state.eligible_plates(tier_id)
	eligible.sort_custom(func(a, b): return int(a.rarity) < int(b.rarity))
	for plate in eligible:
		var uid: String = str(plate.uid)
		var row: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
		exchange_candidates.add_child(row)
		var view = PlateView.new()
		view.plate = plate
		view.compact = true
		view.custom_minimum_size = Vector2(210, 66)
		row.add_child(view)
		row.add_child(T.label(str(GameCatalog.rarity(int(plate.rarity)).name), 13, _rarity_color(int(plate.rarity))))
		row.add_child(T.spacer())
		var choose = T.button("Выбрать", func(): _toggle_exchange_plate(uid), false, 45)
		choose.custom_minimum_size.x = 128
		row.add_child(choose)
		selection_buttons[uid] = choose
	if eligible.size() < int(tier.count):
		column.add_child(T.paragraph("Не хватает подходящих номеров. Выпускай новые в генераторе или проверь избранное и установленные номера.", 16, T.GOLD))
	exchange_button = T.button("", _confirm_exchange, true, 58)
	column.add_child(exchange_button)
	var odds_parts: Array[String] = []
	for i in 5:
		if int(tier.odds[i]) > 0:
			odds_parts.append(str(GameCatalog.rarity(i).name) + " " + str(tier.odds[i]) + "%")
	column.add_child(T.paragraph("Вероятности: " + " · ".join(odds_parts) + ".\nДо гарантированной легенды: %d. Обмен окончательный; машина сразу сохраняется." % (12 - int(state.data.get("pity", 0))), 12))
	_update_exchange_selection()

func _toggle_exchange_plate(uid: String) -> void:
	if selected_plate_ids.has(uid):
		selected_plate_ids.erase(uid)
	elif selected_plate_ids.size() < int(GameCatalog.tier(selected_tier).count):
		selected_plate_ids.append(uid)
	else:
		_toast("Сначала убери один номер из выбранных", true)
	_update_exchange_selection()

func _auto_select_plates() -> void:
	var eligible: Array = state.eligible_plates(selected_tier)
	eligible.sort_custom(func(a, b): return int(a.rarity) < int(b.rarity))
	selected_plate_ids.clear()
	for i in mini(int(GameCatalog.tier(selected_tier).count), eligible.size()):
		selected_plate_ids.append(str(eligible[i].uid))
	_update_exchange_selection()

func _update_exchange_selection() -> void:
	var tier = GameCatalog.tier(selected_tier)
	for uid in selection_buttons:
		var button: Button = selection_buttons[uid]
		button.text = "✓ Выбран" if selected_plate_ids.has(uid) else "Выбрать"
		button.add_theme_color_override("font_color", T.LIME if selected_plate_ids.has(uid) else T.TEXT)
		button.add_theme_stylebox_override("normal", T.box(Color("273725") if selected_plate_ids.has(uid) else T.PANEL_LIGHT, 10, T.LIME if selected_plate_ids.has(uid) else T.LINE, 12))
	exchange_status.text = "Выбрано %d из %d" % [selected_plate_ids.size(), int(tier.count)]
	var fee_text = " + %s ◈" % _number(int(tier.fee)) if int(tier.fee) > 0 else ""
	exchange_button.text = "Обменять " + _plate_amount(int(tier.count)) + fee_text + "  →  открыть сундук"
	exchange_button.disabled = selected_plate_ids.size() != int(tier.count) or int(state.data.coins) < int(tier.fee)
	if int(state.data.coins) < int(tier.fee):
		exchange_status.text += "  ·  Не хватает монет"

func _confirm_exchange() -> void:
	if busy:
		return
	var result: Dictionary = state.exchange(selected_region, selected_tier, selected_plate_ids)
	if not result.get("ok", false):
		_toast(result.get("error", "Не удалось выполнить контракт"), true)
		return
	busy = true
	var column = _modal("Ключи уже в пути…", "Контракт выполнен. Автомобиль сохранён в гараже.", 670)
	var crate = CrateView.new()
	crate.region_id = selected_region
	crate.tier_id = selected_tier
	crate.accent = _region_color(selected_region)
	crate.custom_minimum_size.y = 260
	column.add_child(crate)
	sound.play("roll")
	var tween = create_tween()
	tween.tween_property(crate, "modulate", Color(1.6, 1.8, 1.2), 0.35)
	tween.tween_property(crate, "modulate", Color.WHITE, 0.18)
	tween.tween_property(crate, "modulate", Color(2.0, 2.0, 1.5), 0.25)
	# Closing the reveal frees the crate. A timer still completes, so navigation
	# never stays locked when a player presses Back during the animation.
	await get_tree().create_timer(0.85).timeout
	busy = false
	if not is_instance_valid(modal_root):
		show_page("garage")
		return
	sound.play("reward")
	_open_reward(result)

func _open_reward(result: Dictionary) -> void:
	var car: Dictionary = result.car
	if car.has("id") and not car.has("name"):
		car = GameCatalog.car(str(car.id))
	var duplicate = bool(result.get("duplicate", false))
	var column = _modal("Снова в твоём клубе" if duplicate else "Твой новый автомобиль.", str(GameCatalog.region(str(car.region)).name) + "  /  " + str(GameCatalog.rarity(int(car.rarity)).name), 760)
	column.add_child(T.tag(str(GameCatalog.rarity(int(car.rarity)).name).to_upper(), _rarity_color(int(car.rarity))))
	var stage = Control.new()
	stage.custom_minimum_size.y = 260
	column.add_child(stage)
	var studio = StudioView.new()
	studio.accent = _rarity_color(int(car.rarity))
	studio.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stage.add_child(studio)
	var car_view = CarView.new()
	car_view.car = car
	car_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stage.add_child(car_view)
	column.add_child(T.label(str(car.name), 31, T.TEXT, true))
	column.add_child(T.paragraph(str(car.description), 16))
	if duplicate:
		column.add_child(T.tag("ПОВТОР  ·  КОМПЕНСАЦИЯ +%s ◈" % _number(int(result.get("compensation", 0))), T.GOLD))
	else:
		column.add_child(T.paragraph("Ключи у тебя. Выбери красивый номер и закончи образ.", 15))
	column.add_child(T.button("В мой гараж  →", func(): show_page("garage"), true, 58))
	column.add_child(T.button("Ещё один контракт", func(): show_page("contracts")))

func _page_garage() -> void:
	_heading("Твой личный автоклуб.", "От городской классики до редких суперкаров. Шесть коллекций со своим характером.", "%d / %d МОДЕЛЕЙ" % [state.data.cars.size(), GameCatalog.CARS.size()])
	var regions: Container = GridContainer.new() if mobile_ui else HBoxContainer.new()
	if regions is GridContainer:
		regions.columns = 1
	regions.add_theme_constant_override("separation", 8)
	page_host.add_child(regions)
	if mobile_ui:
		var picker = OptionButton.new()
		picker.size_flags_horizontal = SIZE_EXPAND_FILL
		picker.add_item("Все автомобильные коллекции")
		var index = 1
		for region in GameCatalog.REGIONS:
			picker.add_item(str(region.name))
			if str(region.id) == garage_region:
				picker.select(index)
			index += 1
		regions.add_child(picker)
		picker.item_selected.connect(func(value):
			garage_region = "all" if value == 0 else str(GameCatalog.REGIONS[value - 1].id)
			show_page("garage"))
	else:
		var all = T.button("Все", func():
			garage_region = "all"
			show_page("garage"), garage_region == "all", 46)
		regions.add_child(all)
		for region in GameCatalog.REGIONS:
			var rid: String = str(region.id)
			var button = T.button(str(region.name), func():
				garage_region = rid
				show_page("garage"), garage_region == rid, 46)
			button.add_theme_font_size_override("font_size", 13)
			button.size_flags_horizontal = SIZE_EXPAND_FILL
			regions.add_child(button)
	var owned_row: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	page_host.add_child(owned_row)
	var garage_hint = T.paragraph("Реальные названия · стилизованные иллюстрации. Нажми на автомобиль, чтобы рассмотреть его и установить номер.", 13)
	garage_hint.size_flags_horizontal = SIZE_EXPAND_FILL
	owned_row.add_child(garage_hint)
	owned_row.add_child(T.button("✓ Только мои" if garage_owned else "Показать только мои", func():
		garage_owned = not garage_owned
		show_page("garage"), garage_owned, 42))
	var grid = GridContainer.new()
	grid.columns = 1 if mobile_ui else 3
	grid.add_theme_constant_override("h_separation", 18)
	grid.add_theme_constant_override("v_separation", 18)
	page_host.add_child(grid)
	var count = 0
	for car in GameCatalog.CARS:
		if garage_region != "all" and str(car.region) != garage_region:
			continue
		var owned = _owned_car(str(car.id))
		if garage_owned and owned.is_empty():
			continue
		count += 1
		var card = T.panel(T.PANEL, 16, Color(_rarity_color(int(car.rarity)), 0.28) if not owned.is_empty() else T.LINE)
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		grid.add_child(card)
		var column = VBoxContainer.new()
		column.add_theme_constant_override("separation", 9)
		card.add_child(column)
		var top = HBoxContainer.new()
		column.add_child(top)
		top.add_child(T.label(str(GameCatalog.rarity(int(car.rarity)).name).to_upper(), 10, _rarity_color(int(car.rarity))))
		top.add_child(T.spacer())
		top.add_child(T.label("В ГАРАЖЕ" if not owned.is_empty() else "НЕ ОТКРЫТ", 10, T.LIME if not owned.is_empty() else T.MUTED))
		var art = CarView.new()
		art.car = car
		art.showcase = false
		art.kit_id = str(owned.get("equipped_kit", ""))
		art.custom_minimum_size.y = 176 if mobile_ui else 128
		if owned.is_empty():
			art.modulate = Color(0.68, 0.70, 0.73, 0.75)
		column.add_child(art)
		column.add_child(T.label(str(car.name), 19, T.TEXT, true))
		column.add_child(T.label("%s  ·  %d л. с.  ·  %d" % [str(GameCatalog.region(str(car.region)).name), int(car.power), int(car.year)], 12, T.MUTED))
		if not owned.is_empty() and not str(owned.get("plate_uid", "")).is_empty():
			var p = _find_plate(str(owned.plate_uid))
			column.add_child(T.label("▰  " + str(p.get("text", "")), 14, T.LIME))
		var car_id: String = str(car.id)
		column.add_child(T.button("В гараж  ↗" if not owned.is_empty() else "Рассмотреть  ↗", func(): _open_car(car_id), false, 43))
	if count == 0:
		page_host.add_child(T.paragraph("Первые ключи ждут тебя в контрактах. Три стартовых необычных номера уже в коллекции!", 20))
		page_host.add_child(T.button("Открыть первый сундук", func(): show_page("contracts"), true))

func _open_car(car_id: String) -> void:
	var car = GameCatalog.car(car_id)
	var owned = _owned_car(car_id)
	var column = _modal(str(car.name), str(GameCatalog.region(str(car.region)).name) + "  /  " + str(GameCatalog.rarity(int(car.rarity)).name), 760)
	var view = CarView.new()
	view.car = car
	view.kit_id = str(owned.get("equipped_kit", ""))
	view.custom_minimum_size.y = 220 if mobile_ui else 260
	column.add_child(view)
	var specs = HBoxContainer.new()
	column.add_child(specs)
	for item in [[str(car.power) + " л. с.", "МОЩНОСТЬ"], [str(car.year), "ГОД"], [str(GameCatalog.rarity(int(car.rarity)).name), "РЕДКОСТЬ"]]:
		var spec = VBoxContainer.new()
		spec.size_flags_horizontal = SIZE_EXPAND_FILL
		specs.add_child(spec)
		spec.add_child(T.label(item[1], 10, T.MUTED))
		spec.add_child(T.label(item[0], 20, T.TEXT, true))
	column.add_child(T.paragraph(str(car.description), 16))
	if owned.is_empty():
		column.add_child(T.paragraph("Эта модель может выпасть из сундука коллекции «%s»." % str(GameCatalog.region(str(car.region)).name), 15))
		column.add_child(T.button("К контрактам  →", func(): show_page("contracts"), true))
	else:
		column.add_child(T.tag("В КОЛЛЕКЦИИ  ·  ПОЛУЧЕН %d РАЗ" % int(owned.get("count", 1))))
		var plate_uid = str(owned.get("plate_uid", ""))
		if not plate_uid.is_empty():
			var p = PlateView.new()
			p.plate = _find_plate(plate_uid)
			p.custom_minimum_size.y = 82
			column.add_child(p)
			column.add_child(T.button("Снять номер", func():
				state.unequip_plate(car_id)
				_open_car(car_id)
				_toast("Номер вернулся в коллекцию")))
		column.add_child(T.button("Выбрать номер для автомобиля", func(): _choose_plate_for_car(car_id), true))
		if int(car.rarity) >= 3:
			column.add_child(T.button("Обвесы и мастерская  →", func(): _open_kits(car_id)))

func _choose_plate_for_car(car_id: String) -> void:
	var column = _modal("Номер для " + str(GameCatalog.car(car_id).name), "Избранные номера тоже можно установить. Уже установленные на другие машины недоступны.", 710)
	var count = 0
	for plate in state.data.plates:
		if not str(plate.get("equipped_to", "")).is_empty() or plate.get("in_vault", false):
			continue
		count += 1
		var row: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
		column.add_child(row)
		var view = PlateView.new()
		view.plate = plate
		view.custom_minimum_size = Vector2(240, 66)
		row.add_child(view)
		row.add_child(T.spacer())
		var uid: String = str(plate.uid)
		row.add_child(T.button("Установить", func():
			var result: Dictionary = state.equip_plate(car_id, uid)
			if result.get("ok", false):
				show_page("garage")
				_open_car(car_id)
				_toast("Номер установлен")
			else:
				_toast(result.get("error", "Не удалось установить номер"), true)))
	if count == 0:
		column.add_child(T.paragraph("Свободных номеров нет. Выпусти новый в генераторе.", 18))

func _page_progress() -> void:
	_heading("Коллекционер — это характер.", "Новые страны, редкие серии, любимые автомобили. Здесь виден твой путь.", "УРОВЕНЬ %02d" % _level())
	var summary: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	page_host.add_child(summary)
	var stats: Dictionary = state.data.stats
	for metric in [[_number(int(stats.get("generated", 0))), "ВЫПУЩЕНО НОМЕРОВ"], [str(state.data.plates.size()), "НОМЕРОВ В КОЛЛЕКЦИИ"], [str(state.data.cars.size()) + "/36", "МОДЕЛЕЙ В ГАРАЖЕ"], [_number(int(stats.get("exchanged", 0))), "ВЫПОЛНЕНО КОНТРАКТОВ"]]:
		var card = T.panel()
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		summary.add_child(card)
		var column = VBoxContainer.new()
		card.add_child(column)
		column.add_child(T.label(metric[0], 34, T.LIME, true))
		column.add_child(T.label(metric[1], 10, T.MUTED))
	var xp_card = T.panel(Color("18221f"))
	page_host.add_child(xp_card)
	var xp_column = VBoxContainer.new()
	xp_card.add_child(xp_column)
	xp_column.add_child(T.label(_rank_name() + "  /  Уровень " + str(_level()), 24, T.TEXT, true))
	var xp = int(state.data.get("xp", 0))
	var progress = ProgressBar.new()
	progress.max_value = 250
	progress.value = xp % 250
	progress.show_percentage = false
	progress.custom_minimum_size.y = 9
	xp_column.add_child(progress)
	xp_column.add_child(T.paragraph("%d / 250 опыта до следующего уровня · Опыт за выпуски и контракты" % (xp % 250), 13, T.MUTED))
	var countries: Array = state.data.get("discoveries", {}).get("countries", [])
	var has_legend: bool = bool(state.data.get("discoveries", {}).get("legendary_plate", false))
	var achievements = [
		["Первый тираж", "Выпусти свой первый номер", int(stats.get("generated", 0)), 1],
		["На хороших оборотах", "Выпусти 50 номеров", int(stats.get("generated", 0)), 50],
		["Без границ", "Открой номера всех восьми стран", countries.size(), 8],
		["Свои ключи", "Выполни первый контракт", int(stats.get("exchanged", 0)), 1],
		["Место под легенду", "Получи легендарный номер", 1 if has_legend else 0, 1],
		["Полный гараж", "Собери все 36 моделей автомобилей", state.data.cars.size(), 36]
	]
	var grid = GridContainer.new()
	grid.columns = 1 if mobile_ui else 2
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 16)
	page_host.add_child(grid)
	for achievement in achievements:
		var done: bool = int(achievement[2]) >= int(achievement[3])
		var card = T.panel(T.PANEL, 20, Color("4a6338") if done else T.LINE)
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		grid.add_child(card)
		var column = VBoxContainer.new()
		column.add_theme_constant_override("separation", 7)
		card.add_child(column)
		column.add_child(T.label(("✓  " if done else "○  ") + str(achievement[0]), 20, T.LIME if done else T.TEXT, true))
		column.add_child(T.paragraph(str(achievement[1]), 14))
		column.add_child(T.label("Выполнено" if done else "%d / %d" % [int(achievement[2]), int(achievement[3])], 12, T.LIME if done else T.MUTED))

func _modal(title: String, subtitle: String, width: int = 680) -> VBoxContainer:
	_close_modal()
	if mobile_ui:
		width = int(get_viewport_rect().size.x) - 32
	modal_root = Control.new()
	modal_root.theme = theme
	modal_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal_layer.add_child(modal_root)
	var shade = ColorRect.new()
	shade.color = Color(0.015, 0.025, 0.03, 0.90)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal_root.add_child(shade)
	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	modal_root.add_child(center)
	var panel = T.panel(Color("152027"), 26, Color("43534b"))
	panel.custom_minimum_size.x = width
	center.add_child(panel)
	var outer = VBoxContainer.new()
	outer.add_theme_constant_override("separation", 18)
	panel.add_child(outer)
	var title_row = HBoxContainer.new()
	outer.add_child(title_row)
	var heading = T.paragraph(title, 25, T.TEXT) if mobile_ui else T.label(title, 25, T.TEXT, true)
	heading.size_flags_horizontal = SIZE_EXPAND_FILL
	title_row.add_child(heading)
	var close = T.button("✕", _close_modal, false, 42)
	close.custom_minimum_size.x = 44
	title_row.add_child(close)
	var desc = T.paragraph(subtitle, 14)
	desc.custom_minimum_size.x = width - 52
	outer.add_child(desc)
	var scroll = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(width - 52, minf(560, get_viewport_rect().size.y - 250))
	outer.add_child(scroll)
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 15)
	column.size_flags_horizontal = SIZE_EXPAND_FILL
	scroll.add_child(column)
	_adapt_controls_later.bind(weakref(column)).call_deferred()
	panel.modulate.a = 0.0
	create_tween().tween_property(panel, "modulate:a", 1.0, 0.12)
	return column

func _close_modal() -> void:
	lore_token += 1
	if is_instance_valid(modal_root):
		modal_layer.remove_child(modal_root)
		modal_root.queue_free()
	modal_root = null

func _toast(message: String, is_error: bool = false) -> void:
	if is_instance_valid(toast_control):
		toast_control.queue_free()
	if toast_tween != null and toast_tween.is_valid():
		toast_tween.kill()
	toast_control = T.panel(Color("302322") if is_error else Color("243225"), 17, T.RED if is_error else Color("628342"))
	toast_control.theme = theme
	toast_control.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_control.anchor_left = 0.5
	toast_control.anchor_right = 0.5
	toast_control.anchor_top = 1.0
	toast_control.anchor_bottom = 1.0
	toast_control.offset_left = -(get_viewport_rect().size.x - 32) / 2 if mobile_ui else -310
	toast_control.offset_right = (get_viewport_rect().size.x - 32) / 2 if mobile_ui else 310
	toast_control.offset_top = -125 if mobile_ui else -91
	toast_control.offset_bottom = -27
	toast_layer.add_child(toast_control)
	var label = T.paragraph(message, 15, T.TEXT)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_control.add_child(label)
	toast_tween = create_tween()
	toast_tween.tween_interval(3.2)
	toast_tween.tween_property(toast_control, "modulate:a", 0.0, 0.3)
	toast_tween.tween_callback(func():
		if is_instance_valid(toast_control):
			toast_control.queue_free())

func _daily() -> void:
	var result: Dictionary = state.collect_daily()
	if result.get("ok", false):
		sound.play("coin")
		_toast("Подарок клуба: +1 200 монет. Возвращайся завтра!")
	else:
		_toast(result.get("error", "Подарок уже получен"), true)

func _job() -> void:
	var result: Dictionary = state.club_job()
	if result.get("ok", false):
		sound.play("coin")
		_toast("Заказ клуба выполнен. +150 монет на новые номера.")
	else:
		_toast(result.get("error", "Следующий заказ ещё не готов"), true)

func _toggle_sound() -> void:
	sound.enabled = not sound.enabled
	state.data.settings.sound = sound.enabled
	state.save_game()
	_refresh_header()
	sound.play("click")

func _help() -> void:
	var column = _modal("Добро пожаловать в клуб.", "Свои номера. Свои автомобили. Своя история.", 710)
	for item in [["01 / Выпускай", "Выбери страну и выпусти номер за 100 монет. У каждой находки одна из пяти редкостей. Шансы указаны рядом с генератором."], ["02 / Собирай", "Добавляй любимое в избранное. Лишние номера можно продавать. Избранные и установленные номера защищены."], ["03 / Обменивай", "Стартовые номера уже у тебя. Сундуки требуют редких номеров и монет. Выбери коллекцию в контрактах, укажи нужные номера и получи случайную машину. Номера расходуются безвозвратно."], ["04 / Оформляй", "Открой свой автомобиль в гараже и установи на него номер. Названия моделей реальные; иллюстрации стилизованы для игры."], ["05 / Возвращайся", "Подарок дня даёт 1 200 монет. Заказ клуба — 150 монет каждые 10 секунд. Покупок за реальные деньги и рекламы нет."]]:
		column.add_child(T.label(item[0], 20, T.LIME, true))
		column.add_child(T.paragraph(item[1], 15))
	column.add_child(T.paragraph("Управление: мышь или касание. Пробел — выпустить номер; Esc / кнопка «Назад» — закрыть окно; F11 — полный экран. Игра сохраняется после каждого действия, работает без интернета. Японские и европейские номера — стилизованные коллекционные форматы.", 14))
	column.add_child(T.paragraph("НОМЕРНОЙ КЛУБ  ·  Версия 2.0.0\nСделано на Godot 4.6.3. Авторские механики и оформление.\nGodot Engine — MIT; Open Sans — Apache 2.0; DejaVu — свободная лицензия. Полные лицензии включены в папку docs и assets/fonts.", 12))
	column.add_child(T.button("Выпустить первый номер", func(): show_page("generator"), true))

func _owned_car(car_id: String) -> Dictionary:
	for car in state.data.cars:
		if str(car.id) == car_id:
			return car
	return {}

func _find_plate(uid: String) -> Dictionary:
	for plate in state.data.plates:
		if str(plate.uid) == uid:
			return plate
	return {}

func _rarity_color(rarity: int) -> Color:
	return Color(str(GameCatalog.rarity(rarity).color))

func _region_color(region: String) -> Color:
	return {"jp": Color("ff8d83"), "cn": Color("f1c768"), "ru": Color("92b9f2"), "eu": Color("ae9cf2"), "us": Color("7fd6b6"), "kr": Color("8acde1")}.get(region, T.LIME)

func _number(value: int) -> String:
	var source = str(value)
	var output = ""
	for i in source.length():
		if i > 0 and (source.length() - i) % 3 == 0:
			output += " "
		output += source[i]
	return output

func _level() -> int:
	return 1 + int(state.data.get("xp", 0)) / 250

func _rank_name() -> String:
	var names = ["ЭНТУЗИАСТ", "ЦЕНИТЕЛЬ", "КОЛЛЕКЦИОНЕР", "ЭКСПЕРТ", "ЛЕГЕНДА КЛУБА"]
	return names[mini(4, (_level() - 1) / 4)]

func _build_mobile_shell() -> void:
	var background = ColorRect.new()
	background.color = T.shade(T.BG)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)
	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 18)
	add_child(margin)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 16)
	margin.add_child(content)
	var header = HBoxContainer.new()
	content.add_child(header)
	var menu_button = T.button("☰", _open_menu)
	menu_button.custom_minimum_size.x = 70
	menu_button.add_theme_font_size_override("font_size", 31)
	header.add_child(menu_button)
	header.add_child(T.label("НОМЕРНОЙ\nКЛУБ", 22, T.TEXT, true))
	header.add_child(T.spacer())
	rank_label = T.label("УРОВЕНЬ 01", 17, T.MUTED)
	header.add_child(rank_label)
	var wallet = HBoxContainer.new()
	content.add_child(wallet)
	var coins = T.panel(T.PANEL, 14)
	coins.size_flags_horizontal = SIZE_EXPAND_FILL
	wallet.add_child(coins)
	coin_label = T.label("◈  2 500", 22, T.LIME, true)
	coins.add_child(coin_label)
	var dollars = T.panel(T.PANEL, 14)
	dollars.size_flags_horizontal = SIZE_EXPAND_FILL
	wallet.add_child(dollars)
	dollar_label = T.label("$  0", 22, T.GOLD, true)
	dollars.add_child(dollar_label)
	breadcrumb = T.label("КЛУБ / ГЕНЕРАТОР", 17, T.MUTED)
	content.add_child(breadcrumb)
	var scroll = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = SIZE_EXPAND_FILL
	content.add_child(scroll)
	page_host = VBoxContainer.new()
	page_host.size_flags_horizontal = SIZE_EXPAND_FILL
	page_host.add_theme_constant_override("separation", 20)
	scroll.add_child(page_host)
	save_status = T.label("● СОХРАНЕНО НА УСТРОЙСТВЕ", 12, T.MUTED)
	content.add_child(save_status)
	modal_layer = CanvasLayer.new()
	modal_layer.layer = 10
	add_child(modal_layer)
	toast_layer = CanvasLayer.new()
	toast_layer.layer = 20
	add_child(toast_layer)

func _open_menu() -> void:
	var column = _modal("☰  Номерной клуб", "Коллекция, гараж и всё, что делает их твоими.", 560)
	for page in PAGE_NAMES:
		var key: String = page
		column.add_child(T.button(str(PAGE_NAMES[page]) + "  →", func(): show_page(key), key == current_page))
	column.add_child(T.button("Подарок дня +1 200 ◈", _daily))
	column.add_child(T.button("Заказ клуба +150 ◈", _job))
	column.add_child(T.button("Звук: вкл" if sound.enabled else "Звук: выкл", func():
		_toggle_sound()
		_open_menu()))
	column.add_child(T.button("Как играть и лицензии", _help))

func _perform(result: Dictionary, message: String, page: String = "") -> void:
	if result.get("ok", false):
		_close_modal()
		show_page(current_page if page.is_empty() else page)
		sound.play("coin")
		_toast(message)
	else:
		_toast(str(result.get("error", "Действие не выполнено")), true)

func _page_vault() -> void:
	_heading("Твоё личное хранилище.", "Номера в сейфе исчезают из коллекции и защищены от продажи и обмена.", "%d / %d МЕСТ" % [state.vault_count(), int(state.data.vault_capacity)])
	page_host.add_child(T.button("+8 мест в сейфе за %d $" % state.vault_upgrade_cost(), func(): _perform(state.expand_vault(), "Сейф расширен", "vault")))
	var grid = GridContainer.new()
	grid.columns = 1 if mobile_ui else 3
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 16)
	page_host.add_child(grid)
	for plate in state.data.plates:
		if plate.get("in_vault", false):
			var card = _plate_card(plate)
			card.size_flags_horizontal = SIZE_EXPAND_FILL
			grid.add_child(card)
	if grid.get_child_count() == 0:
		page_host.add_child(T.paragraph("Открой карточку любимого номера в коллекции и нажми «Положить в сейф». Здесь он не будет случайно потрачен.", 19))
		page_host.add_child(T.button("К коллекции  →", func(): show_page("collection"), true))

func _page_quests() -> void:
	_heading("Дела клуба. Твои награды.", "Монеты за обычные задачи. Редкие доллары — за серьёзные коллекционные цели.", "$ — ИГРОВАЯ ВАЛЮТА")
	var daily_row: BoxContainer = VBoxContainer.new() if mobile_ui else HBoxContainer.new()
	page_host.add_child(daily_row)
	daily_button = T.button("Подарок дня +1 200", _daily)
	daily_button.size_flags_horizontal = SIZE_EXPAND_FILL
	daily_row.add_child(daily_button)
	job_button = T.button("Заказ клуба +150", _job)
	job_button.size_flags_horizontal = SIZE_EXPAND_FILL
	daily_row.add_child(job_button)
	var grid = GridContainer.new()
	grid.columns = 1 if mobile_ui else 2
	grid.add_theme_constant_override("h_separation", 18)
	grid.add_theme_constant_override("v_separation", 18)
	page_host.add_child(grid)
	for quest in state.quests():
		var card = T.panel(T.PANEL, 20)
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		grid.add_child(card)
		var column = VBoxContainer.new()
		card.add_child(column)
		column.add_child(T.label(str(quest.name), 22, T.TEXT, true))
		column.add_child(T.paragraph(str(quest.description), 16))
		var bar = ProgressBar.new()
		bar.max_value = int(quest.target)
		bar.value = int(quest.progress)
		bar.custom_minimum_size.y = 12
		bar.show_percentage = false
		column.add_child(bar)
		column.add_child(T.label("%d / %d  ·  %s ◈%s" % [int(quest.progress), int(quest.target), _number(int(quest.coins)), " + %d $" % int(quest.dollars) if int(quest.dollars) > 0 else ""], 15, T.GOLD if int(quest.dollars) > 0 else T.LIME))
		var id: String = str(quest.id)
		var button = T.button("Получено" if quest.claimed else "Забрать награду", func(): _perform(state.claim_quest(id), "Награда задания получена", "quests"), not quest.claimed and int(quest.progress) >= int(quest.target))
		button.disabled = bool(quest.claimed) or int(quest.progress) < int(quest.target)
		column.add_child(button)

func _page_themes() -> void:
	_heading("У клуба есть свой цвет.", "Четыре оформления. Выбранная тема сохраняется на устройстве.")
	var grid = GridContainer.new()
	grid.columns = 1 if mobile_ui else 2
	grid.add_theme_constant_override("h_separation", 20)
	grid.add_theme_constant_override("v_separation", 20)
	page_host.add_child(grid)
	for id in T.PALETTES:
		var theme_id: String = str(id)
		var palette: Dictionary = T.PALETTES[id]
		var card = T.panel(T.PANEL, 23)
		card.size_flags_horizontal = SIZE_EXPAND_FILL
		grid.add_child(card)
		var column = VBoxContainer.new()
		card.add_child(column)
		var swatch = ColorRect.new()
		swatch.color = Color(str(palette.bg))
		swatch.custom_minimum_size.y = 95
		column.add_child(swatch)
		var bar = ColorRect.new()
		bar.color = Color(str(palette.accent))
		bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
		bar.offset_top = -16
		swatch.add_child(bar)
		column.add_child(T.label(str(palette.name), 25, T.TEXT, true))
		column.add_child(T.button("✓ Выбрана" if theme_id == str(state.data.settings.theme) else "Применить тему", func(): _choose_theme(theme_id), theme_id == str(state.data.settings.theme)))

func _choose_theme(id: String) -> void:
	state.data.settings.theme = id
	state.save_game()
	T.choose(id)
	_close_modal()
	if toast_tween != null and toast_tween.is_valid():
		toast_tween.kill()
	for child in get_children():
		if child != state and child != sound and child != online:
			remove_child(child)
			child.queue_free()
	nav_buttons.clear()
	audio_button = null
	job_button = null
	daily_button = null
	toast_control = null
	theme = T.make_theme()
	_build_shell()
	_refresh_header()
	show_page("themes")

func _open_kits(car_id: String) -> void:
	var car = GameCatalog.car(car_id)
	var owned = _owned_car(car_id)
	var column = _modal("Мастерская", str(car.name) + " · Обвесы покупаются навсегда для этой машины.", 740)
	var view = CarView.new()
	view.car = car
	view.kit_id = str(owned.get("equipped_kit", ""))
	view.custom_minimum_size.y = 220
	column.add_child(view)
	column.add_child(T.button("Заводской кузов", func():
		var result = state.equip_kit(car_id, "")
		if result.get("ok", false):
			_open_kits(car_id)))
	for kit in ClubState.KITS:
		column.add_child(T.label(str(kit.name), 22, T.TEXT, true))
		column.add_child(T.paragraph(str(kit.description), 16))
		var kit_id: String = str(kit.id)
		var purchased: bool = owned.get("kits", []).has(kit_id)
		column.add_child(T.button("Установить" if purchased else "%s ◈ + %d $ · Купить" % [_number(int(kit.coins)), int(kit.dollars)], func():
			var result: Dictionary = state.equip_kit(car_id, kit_id) if purchased else state.buy_kit(car_id, kit_id)
			if result.get("ok", false):
				sound.play("reward")
				_open_kits(car_id)
				_toast("Обвес установлен")
			else:
				_toast(str(result.get("error", "Недостаточно средств")), true), purchased))

func _show_lore(plate: Dictionary) -> void:
	var column = _modal("Разбираем редкую находку.", "Буквы → цифры → регион. Каждый элемент имеет своё значение.", 710)
	lore_view = PlateView.new()
	lore_view.plate = plate
	lore_view.custom_minimum_size.y = 160
	column.add_child(lore_view)
	lore_caption = T.paragraph("Начинаем с буквенной серии…", 19, T.TEXT)
	column.add_child(lore_caption)
	column.add_child(T.tag(str(GameCatalog.rarity(int(plate.rarity)).name).to_upper(), _rarity_color(int(plate.rarity))))
	column.add_child(T.button("К карточке номера", func(): _open_plate_details(plate)))
	var token = lore_token
	for reason in PlateLore.reasons(plate):
		if token != lore_token or not is_instance_valid(lore_view):
			return
		lore_view.highlight = str(reason.part)
		lore_caption.text = str(reason.title) + "\n\n" + str(reason.text)
		sound.play("click" if reason.part == "letters" else "coin")
		await get_tree().create_timer(2.0).timeout
	if token == lore_token and is_instance_valid(lore_view):
		lore_view.highlight = ""
		sound.play("reward")

func _page_leaderboard() -> void:
	_heading("Общая таблица лидеров.", "Настоящие профили с одного сервера. Обновление отправляет твой лучший результат.", "%s ОЧКОВ" % _number(state.score()))
	var config = T.panel()
	page_host.add_child(config)
	var column = VBoxContainer.new()
	config.add_child(column)
	column.add_child(T.paragraph("Укажи HTTPS-адрес сервера клуба, чтобы видеть общие результаты. Инструкция по размещению сервера находится в ZIP исходников." if str(state.data.settings.online_url).is_empty() else "Адрес сервера сохранён. Обнови таблицу, чтобы отправить результат и загрузить общие рекорды.", 15))
	var name_input = LineEdit.new()
	name_input.placeholder_text = "Имя игрока"
	name_input.text = str(state.data.settings.player_name)
	name_input.custom_minimum_size.y = 64 if mobile_ui else 50
	column.add_child(name_input)
	var url_input = LineEdit.new()
	url_input.placeholder_text = "https://адрес-твоего-сервера"
	url_input.text = str(state.data.settings.online_url)
	url_input.custom_minimum_size.y = 64 if mobile_ui else 50
	column.add_child(url_input)
	var status = T.paragraph("Ожидает подключения. Вымышленные участники не добавляются.", 17)
	var table = VBoxContainer.new()
	var button = T.button("Сохранить и обновить таблицу", func():
		if online.active:
			return
		var changed_url: bool = str(state.data.settings.online_url).trim_suffix("/") != url_input.text.strip_edges().trim_suffix("/")
		state.data.settings.online_url = url_input.text.strip_edges().trim_suffix("/")
		state.data.settings.player_name = name_input.text.strip_edges()
		if changed_url:
			state.data.settings.player_id = ""
			state.data.settings.player_token = ""
		state.save_game()
		status.text = "Подключение и синхронизация…"
		var result: Dictionary = await online.sync(state)
		if not is_instance_valid(status):
			return
		if not result.get("ok", false):
			status.text = str(result.get("error", "Сервер недоступен"))
			return
		status.text = "Обновлено. %d игроков на сервере." % result.get("players", []).size()
		for child in table.get_children():
			child.queue_free()
		for player in result.get("players", []):
			var row = T.panel(T.PANEL, 16)
			table.add_child(row)
			row.add_child(T.paragraph("%02d   %s    ·    %s очков" % [int(player.rank), str(player.name), _number(int(player.score))], 18, T.LIME if str(player.id) == str(state.data.settings.player_id) else T.TEXT)), true)
	column.add_child(button)
	page_host.add_child(status)
	page_host.add_child(table)

func _adapt_controls_later(reference: WeakRef) -> void:
	var node = reference.get_ref()
	if is_instance_valid(node):
		_adapt_controls(node)

func _adapt_controls(node: Node) -> void:
	if not mobile_ui or not is_instance_valid(node):
		return
	if node is BaseButton or node is LineEdit:
		node.custom_minimum_size.y = maxf(68, node.custom_minimum_size.y)
		node.add_theme_font_size_override("font_size", 20)
	for child in node.get_children():
		_adapt_controls(child)

func _page_collection_mobile() -> void:
	_heading("Твоя коллекция.", "Любимые номера, поиск и красивые серии.", "%d / %d МЕСТ" % [state.collection_count(), int(state.data.collection_capacity)])
	page_host.add_child(T.button("+25 мест · %s ◈" % _number(state.collection_upgrade_cost()), func(): _perform(state.expand_collection(), "Коллекция расширена", "collection")))
	var search = LineEdit.new()
	search.placeholder_text = "Найти номер…"
	search.text = collection_query
	search.size_flags_horizontal = SIZE_EXPAND_FILL
	page_host.add_child(search)
	search.text_changed.connect(func(value):
		collection_query = value
		_fill_collection())
	page_host.add_child(T.button("Фильтры и сортировка  ☰", _collection_filters))
	collection_counter = T.paragraph("", 17)
	page_host.add_child(collection_counter)
	_collection_sale_controls()
	collection_grid = GridContainer.new()
	collection_grid.columns = 1
	collection_grid.add_theme_constant_override("v_separation", 16)
	collection_grid.size_flags_horizontal = SIZE_EXPAND_FILL
	page_host.add_child(collection_grid)
	_fill_collection()

func _collection_filters() -> void:
	var column = _modal("Фильтры коллекции", "Выбери страну, редкость и порядок.")
	var country = OptionButton.new()
	country.add_item("Все страны")
	var index = 1
	for item in GameCatalog.COUNTRIES:
		country.add_item(str(item.name))
		if str(item.id) == collection_country:
			country.select(index)
		index += 1
	column.add_child(country)
	country.item_selected.connect(func(value): collection_country = "all" if value == 0 else str(GameCatalog.COUNTRIES[value - 1].id))
	var rarity = OptionButton.new()
	rarity.add_item("Любая редкость")
	for item in GameCatalog.RARITIES:
		rarity.add_item(str(item.name))
	rarity.select(collection_rarity + 1)
	column.add_child(rarity)
	rarity.item_selected.connect(func(value): collection_rarity = value - 1)
	var sort = OptionButton.new()
	for text in ["Сначала новые", "Сначала редкие", "Сначала простые"]:
		sort.add_item(text)
	sort.select(collection_sort)
	column.add_child(sort)
	sort.item_selected.connect(func(value): collection_sort = value)
	var favorites = CheckButton.new()
	favorites.text = "Только избранные"
	favorites.button_pressed = collection_favorites
	column.add_child(favorites)
	favorites.toggled.connect(func(value): collection_favorites = value)
	column.add_child(T.button("Применить", func(): show_page("collection"), true))

func _plate_amount(count: int) -> String:
	return str(count) + (" номер" if count == 1 else (" номера" if count in [2,3,4] else " номеров"))
