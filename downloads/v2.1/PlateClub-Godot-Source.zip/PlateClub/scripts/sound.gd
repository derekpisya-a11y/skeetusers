class_name ClubSound
extends Node

var enabled: bool = true
var tones: Dictionary = {}

func _ready() -> void:
	tones["click"] = _tone([440.0], 0.045, 0.10)
	tones["roll"] = _tone([220.0, 330.0, 440.0, 660.0], 0.10, 0.12)
	tones["reward"] = _tone([392.0, 493.88, 587.33, 783.99], 0.16, 0.17)
	tones["coin"] = _tone([880.0, 1174.66], 0.09, 0.11)

func play(kind: String = "click") -> void:
	if not enabled or not tones.has(kind):
		return
	var player = AudioStreamPlayer.new()
	player.stream = tones[kind]
	add_child(player)
	player.finished.connect(player.queue_free)
	player.play()

func _tone(frequencies: Array, duration: float, amplitude: float) -> AudioStreamWAV:
	var bytes = PackedByteArray()
	var rate: int = 22050
	var count = int(rate * duration)
	bytes.resize(count * frequencies.size() * 2)
	for n in frequencies.size():
		for i in count:
			var t = float(i) / float(rate)
			var envelope = sin(PI * float(i) / float(count)) * exp(-t * 12.0)
			var value = sin(TAU * float(frequencies[n]) * t) * envelope * amplitude
			bytes.encode_s16((n * count + i) * 2, int(value * 32767.0))
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = bytes
	return stream
