#!/usr/bin/env python3
"""Make a portable Godot source archive, excluding caches, saves and signing keys."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ROOT_FILES = ("project.godot", "export_presets.cfg", "README.md", "PREVIEW.md", "THIRD_PARTY_NOTICES.md", ".gitignore")
SOURCE_DIRS = ("assets", "scenes", "scripts", "tests", "tools", "docs", "server")


def main() -> None:
    files = [ROOT / name for name in ROOT_FILES]
    for folder in SOURCE_DIRS:
        files.extend(path for path in (ROOT / folder).rglob("*")
                     if path.is_file() and "__pycache__" not in path.parts
                     and path.name != ".env" and not (folder == "server" and "data" in path.relative_to(ROOT / folder).parts)
                     and path.suffix not in (".pyc", ".tmp", ".keystore", ".jks", ".sqlite", ".sqlite3", ".db", ".pem", ".key"))
    target = ROOT / "dist/PlateClub-Godot-Source.zip"
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            if path.is_file():
                archive.write(path, str(Path("PlateClub") / path.relative_to(ROOT)))
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert "PlateClub/project.godot" in archive.namelist()
        assert not any(part in name.split("/") for name in archive.namelist()
                       for part in (".git", ".godot", ".local", "__pycache__", "dist"))
    with target.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    # Preserve native build checksums when adding the source archive.
    sums_path = target.parent / "SHA256SUMS.txt"
    lines = sums_path.read_text().splitlines() if sums_path.exists() else []
    lines = [line for line in lines if not line.endswith("  " + target.name)]
    lines.append(f"{digest}  {target.name}")
    sums_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    manifest_path = target.parent / "source-manifest.json"
    manifest_path.write_text(json.dumps({"file": target.name, "bytes": target.stat().st_size,
                                         "sha256": digest, "files": len(files)}, indent=2) + "\n")
    print(f"Ready: {target.name}, {target.stat().st_size:,} bytes, {len(files)} files")


if __name__ == "__main__":
    main()
