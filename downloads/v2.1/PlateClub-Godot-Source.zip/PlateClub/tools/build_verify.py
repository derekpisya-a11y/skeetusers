#!/usr/bin/env python3
"""Inspect native export artifacts without claiming execution on target devices."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def checked(command: list[str]) -> str:
    return subprocess.check_output(command, text=True, stderr=subprocess.STDOUT)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--android-sdk", type=Path, required=True)
    parser.add_argument("--build-tools", default="36.0.0")
    args = parser.parse_args()
    sdk_tools = args.android_sdk / "build-tools" / args.build_tools
    android = ROOT / "dist/android/PlateClub-debug.apk"
    windows = ROOT / "dist/windows/PlateClub.exe"
    suffix = ".exe" if os.name == "nt" else ""
    signer_suffix = ".bat" if suffix else ""
    signer = sdk_tools / ("apksigner" + signer_suffix)
    aapt = sdk_tools / ("aapt" + suffix)
    zipalign = sdk_tools / ("zipalign" + suffix)
    report: dict = {"target_device_runtime_tested": False, "checks": {}}

    manifest = json.loads((ROOT / "dist/build-manifest.json").read_text())
    for item in manifest["artifacts"]:
        artifact = ROOT / "dist" / item["file"]
        with artifact.open("rb") as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == item["sha256"], artifact
        assert artifact.stat().st_size == item["bytes"], artifact
    report["checks"]["manifest_sha256"] = True

    with windows.open("rb") as stream:
        assert stream.read(2) == b"MZ"
        stream.seek(0x3C)
        pe_offset = struct.unpack("<I", stream.read(4))[0]
        stream.seek(pe_offset)
        assert stream.read(4) == b"PE\0\0"
        assert struct.unpack("<H", stream.read(2))[0] == 0x8664  # AMD64
        stream.seek(-12, 2)
        pck_bytes, magic = struct.unpack("<Q4s", stream.read(12))
        assert magic == b"GDPC" and 0 < pck_bytes < windows.stat().st_size
    report["windows"] = {"architecture": "x86_64", "embedded_pck_bytes": pck_bytes}

    signature = checked([str(signer), "verify", "--verbose", str(android)])
    assert "Verified using v2 scheme (APK Signature Scheme v2): true" in signature
    checked([str(zipalign), "-c", "-P", "16", "4", str(android)])
    badging = checked([str(aapt), "dump", "badging", str(android)])
    permissions_text = checked([str(aapt), "dump", "permissions", str(android)])
    manifest_xml = checked([str(aapt), "dump", "xmltree", str(android), "AndroidManifest.xml"])
    assert re.search(r"screenOrientation.*(?:0x1\b|=1\b)", manifest_xml), "Android must be portrait"
    authorities = re.findall(r'A: android:authorities[^\n]*="([^"]+)"', manifest_xml)
    assert authorities == ["com.skeetusers.plateclub.fileprovider",
                           "com.skeetusers.plateclub.initprovider"], authorities
    permissions = re.findall(r"uses-permission[^:]*: name='([^']+)'", permissions_text)
    assert permissions == ["android.permission.INTERNET"], permissions
    package = re.search(r"package: name='([^']+)'", badging).group(1)
    version_code = int(re.search(r"versionCode='(\d+)'", badging).group(1))
    version_name = re.search(r"versionName='([^']+)'", badging).group(1)
    expected_version = re.search(r'config/version="([^"]+)"', (ROOT / "project.godot").read_text()).group(1)
    expected_code = int(re.search(r"version/code=(\d+)", (ROOT / "export_presets.cfg").read_text()).group(1))
    assert (version_code, version_name) == (expected_code, expected_version)
    minimum = int(re.search(r"^sdkVersion:'(\d+)'", badging, re.M).group(1))
    target = int(re.search(r"^targetSdkVersion:'(\d+)'", badging, re.M).group(1))
    assert package == "com.skeetusers.plateclub"
    assert (minimum, target) == (24, 36)
    required_notices = ["assets/THIRD_PARTY_NOTICES.md", "assets/docs/GODOT-LICENSE.txt",
                        "assets/docs/GODOT-THIRD-PARTY.txt",
                        "assets/assets/fonts/OPEN-SANS-APACHE-LICENSE.txt",
                        "assets/assets/fonts/PlateJapanese-LICENSE.txt",
                        "assets/assets/fonts/PlateCondensed-LICENSE.txt"]
    with zipfile.ZipFile(android) as archive:
        paths = archive.namelist()
        native_abis = sorted({p.split("/")[1] for p in paths if p.startswith("lib/")})
        assert native_abis == ["arm64-v8a", "armeabi-v7a"]
        for path in paths:
            assert not any(part in Path(path).parts for part in (".git", ".local", "tests", "tools")), path
        for notice in required_notices:
            assert notice in paths, notice
    with zipfile.ZipFile(ROOT / "dist/PlateClub-Windows-x64.zip") as archive:
        paths = archive.namelist()
        for required in ("PlateClub.exe", "README.md", "THIRD_PARTY_NOTICES.md",
                         "docs/EXPORT_RU.md", "docs/QA_RU.md", "docs/GODOT-LICENSE.txt",
                         "docs/GODOT-THIRD-PARTY.txt"):
            assert required in paths, required
    report["android"] = {"package": package, "minimum_sdk": minimum, "target_sdk": target,
                         "version_code": version_code, "version_name": version_name,
                         "native_abis": native_abis, "permissions": permissions, "orientation": "portrait",
                         "signature_v2_verified": True, "zip_alignment_16kb": True,
                         "provider_authorities_unique": True,
                         "required_license_notices": True, "developer_files_excluded": True}
    report["checks"]["windows_zip_contents"] = True
    output = ROOT / "dist/verification.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
