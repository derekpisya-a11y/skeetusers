#!/usr/bin/env python3
"""Fix duplicate provider authorities in Godot's non-Gradle Android export.

Godot 4.6.3 rewrites both provider authorities to <package>.fileprovider.
Android requires them to be distinct. This edits only the second provider's
string-pool entry, then aligns and signs the APK with the existing debug key.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile


def run(command: list[str], env: dict[str, str]) -> str:
    return subprocess.check_output(command, env=env, text=True, stderr=subprocess.STDOUT)


def fix(apk: Path, sdk: Path, keystore: Path, env: dict[str, str]) -> None:
    build_tools = sdk / "build-tools"
    candidates = sorted((p for p in build_tools.iterdir() if p.is_dir()), reverse=True)
    suffix = ".exe" if os.name == "nt" else ""
    signer_suffix = ".bat" if os.name == "nt" else ""
    tools = next((p for p in candidates if all((p / name).is_file() for name in
                  ("aapt" + suffix, "zipalign" + suffix, "apksigner" + signer_suffix))), None)
    if tools is None:
        raise RuntimeError("Android SDK Build-Tools with aapt, zipalign and apksigner are required")
    aapt = str(tools / ("aapt" + suffix))
    zipalign = str(tools / ("zipalign" + suffix))
    apksigner = str(tools / ("apksigner" + signer_suffix))

    badging = run([aapt, "dump", "badging", str(apk)], env)
    package = re.search(r"package: name='([^']+)'", badging)
    if package is None:
        raise RuntimeError("Could not read APK package name")
    old = (package[1] + ".fileprovider").encode("utf-16le")
    new = (package[1] + ".initprovider").encode("utf-16le")
    if len(old) != len(new):
        raise RuntimeError("Replacement authority must have the same UTF-16 length")

    with tempfile.TemporaryDirectory(prefix="plateclub-android-", dir=apk.parent) as tmp:
        work = Path(tmp)
        unsigned = work / "unsigned.apk"
        aligned = work / "aligned.apk"
        signed = work / "signed.apk"
        with zipfile.ZipFile(apk) as source, zipfile.ZipFile(unsigned, "w") as target:
            for info in source.infolist():
                data = source.read(info.filename)
                if info.filename == "AndroidManifest.xml":
                    # Both UTF-16 strings are separate pool entries. The first
                    # entry belongs to InitializationProvider in this export.
                    if data.count(old) != 2:
                        raise RuntimeError("Unexpected provider authority string pool; refusing to patch")
                    data = data.replace(old, new, 1)
                target.writestr(info, data)
        manifest = run([aapt, "dump", "xmltree", str(unsigned), "AndroidManifest.xml"], env)
        authorities = re.findall(r'A: android:authorities[^\n]*="([^"]+)"', manifest)
        if authorities != [package[1] + ".fileprovider", package[1] + ".initprovider"]:
            raise RuntimeError(f"Unexpected provider authorities: {authorities}")
        run([zipalign, "-P", "16", "-f", "4", str(unsigned), str(aligned)], env)
        sign_env = env.copy()
        sign_env["PLATECLUB_DEBUG_KEY_PASSWORD"] = "android"
        run([apksigner, "sign", "--ks", str(keystore), "--ks-key-alias", "androiddebugkey",
             "--ks-pass", "env:PLATECLUB_DEBUG_KEY_PASSWORD",
             "--key-pass", "env:PLATECLUB_DEBUG_KEY_PASSWORD", "--out", str(signed), str(aligned)], sign_env)
        verification = run([apksigner, "verify", "--verbose", str(signed)], env)
        if "Verified using v2 scheme (APK Signature Scheme v2): true" not in verification:
            raise RuntimeError("Patched APK lacks a valid v2 signature")
        run([zipalign, "-c", "-P", "16", "4", str(signed)], env)
        signed.replace(apk)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("--android-sdk", type=Path, required=True)
    parser.add_argument("--keystore", type=Path, required=True)
    args = parser.parse_args()
    fix(args.apk.resolve(), args.android_sdk.resolve(), args.keystore.resolve(), os.environ.copy())
    print("Fixed provider authorities and verified APK signature")
