#!/usr/bin/env python3
"""Package the no-VPS Cloudflare leaderboard and standalone Russian guide."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"


def main() -> None:
    DIST.mkdir(parents=True, exist_ok=True)
    guide = (ROOT / "docs/LEADERBOARD_FREE_RU.md").read_text(encoding="utf-8")
    (DIST / "LEADERBOARD_FREE_RU.md").write_text(guide, encoding="utf-8")
    (DIST / "LEADERBOARD_FREE_RU.txt").write_text(guide, encoding="utf-8-sig")
    target = DIST / "PlateClub-Free-Leaderboard.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in ("worker.js", "schema.sql"):
            archive.write(ROOT / "server/cloudflare" / name, name)
        for name in ("LEADERBOARD_FREE_RU.md", "LEADERBOARD_FREE_RU.txt"):
            archive.write(DIST / name, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {
            "worker.js", "schema.sql", "LEADERBOARD_FREE_RU.md", "LEADERBOARD_FREE_RU.txt"}
    print(f"Ready: {target.name}, {target.stat().st_size:,} bytes")
    for name in (target.name, "LEADERBOARD_FREE_RU.md", "LEADERBOARD_FREE_RU.txt"):
        path = DIST / name
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        print(f"{digest}  {name}")


if __name__ == "__main__":
    main()
