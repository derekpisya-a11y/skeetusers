#!/usr/bin/env python3
"""Wrap the tested APK and Russian guide in a downloadable ZIP."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
target = ROOT / "dist/PlateClub-Android.zip"
guide = """Номерной клуб 2.1 — Android

1. Распакуйте этот архив.
2. Откройте PlateClub-debug.apk на телефоне.
3. Разрешите установку этому файловому менеджеру, если Android попросит.

Требуется Android 7.0+ / arm64. Интерфейс вертикальный.
APK подписан тем же тестовым ключом, что версия 1.0, и может обновлять её.
Не удаляйте приложение перед обновлением, если хотите сохранить прогресс.

Основная игра работает офлайн. Общая таблица требует размещённого HTTPS-сервера;
инструкция LEADERBOARD_RU.md находится рядом. Вымышленных игроков нет.
Исторические связи спецсерий пока не проверены; подробности PLATE_REFERENCE_RU.md.
"""
with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
    archive.write(ROOT / "dist/android/PlateClub-debug.apk", "PlateClub-debug.apk")
    archive.writestr("ОТКРОЙ-МЕНЯ.txt", guide)
    for name in ("LEADERBOARD_RU.md", "LEADERBOARD_SETUP_RU.md", "PLATE_REFERENCE_RU.md"):
        archive.write(ROOT / "docs" / name, name)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
with target.open("rb") as file:
    digest = hashlib.file_digest(file, "sha256").hexdigest()
sums = ROOT / "dist/SHA256SUMS.txt"
lines = [line for line in sums.read_text().splitlines() if not line.endswith("  " + target.name)]
lines.append(digest + "  " + target.name)
sums.write_text("\n".join(lines) + "\n")
print(f"Ready: {target.name}, {target.stat().st_size:,} bytes")
