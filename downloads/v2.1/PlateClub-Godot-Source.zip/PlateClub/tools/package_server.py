#!/usr/bin/env python3
"""Package just the leaderboard service and a separate Russian setup guide."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
FILES = ("leaderboard.py", "Dockerfile", "compose.yaml", "Caddyfile")


def main() -> None:
    DIST.mkdir(parents=True, exist_ok=True)
    guide = (ROOT / "docs/LEADERBOARD_SETUP_RU.md").read_text(encoding="utf-8")
    # Plain text remains readable in Notepad and mobile text viewers.
    (DIST / "LEADERBOARD_SETUP_RU.md").write_text(guide, encoding="utf-8")
    (DIST / "LEADERBOARD_SETUP_RU.txt").write_text(guide, encoding="utf-8-sig")
    target = DIST / "PlateClub-Leaderboard-Server.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            archive.write(ROOT / "server" / name, "server/" + name)
        for name in ("LEADERBOARD_SETUP_RU.md", "LEADERBOARD_SETUP_RU.txt"):
            archive.write(DIST / name, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {"server/" + name for name in FILES} | {
            "LEADERBOARD_SETUP_RU.md", "LEADERBOARD_SETUP_RU.txt"}
    sums = DIST / "SHA256SUMS.txt"
    lines = sums.read_text().splitlines() if sums.exists() else []
    for name in (target.name, "LEADERBOARD_SETUP_RU.md", "LEADERBOARD_SETUP_RU.txt"):
        path = DIST / name
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        lines = [line for line in lines if not line.endswith("  " + name)]
        lines.append(digest + "  " + name)
        print(f"Ready: {name}, {path.stat().st_size:,} bytes")
    sums.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
