#!/usr/bin/env python3
"""Export native builds using Godot 4.6.3 and already installed official SDKs.

No third-party Python packages required. Run `python tools/build.py --help`.
Keys and SDK paths are kept out of export_presets.cfg.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def run(args: list[str], env: dict[str, str]) -> None:
    subprocess.run(args, cwd=ROOT, env=env, check=True)


def configure_android(godot: str, env: dict[str, str], sdk: Path | None, java: Path | None) -> None:
    """Update the generated editor resource without loading an extra editor scene.

    The normal import above creates this versioned resource first. Only the
    supplied SDK fields and device-monitor shutdown flag are changed.
    """
    executable_dir = Path(godot).resolve().parent
    if (executable_dir / "_sc_").exists() or (executable_dir / "._sc_").exists():
        config_dir = executable_dir / "editor_data"
    elif os.name == "nt":
        config_dir = Path(env["APPDATA"]) / "Godot"
    elif sys.platform == "darwin":
        config_dir = Path.home() / "Library/Application Support/Godot"
    else:
        config_dir = Path(env.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "godot"
    path = config_dir / "editor_settings-4.6.tres"
    content = path.read_text(encoding="utf-8")
    changes: dict[str, str | bool] = {"export/android/shutdown_adb_on_exit": False}
    if sdk:
        changes["export/android/android_sdk_path"] = str(sdk)
    if java:
        changes["export/android/java_sdk_path"] = str(java)
    for key, value in changes.items():
        replacement = f"{key} = {json.dumps(value, ensure_ascii=False)}"
        pattern = re.compile(r"^" + re.escape(key) + r"\s*=.*$", re.MULTILINE)
        if pattern.search(content):
            content = pattern.sub(lambda _: replacement, content)
        else:
            marker = "[resource]\n"
            if marker not in content:
                raise ValueError(f"Unexpected Godot editor settings format: {path}")
            content = content.replace(marker, marker + replacement + "\n", 1)
    # Preserve existing settings and file permissions; no credentials are logged.
    temp = path.with_suffix(".tres.plateclub.tmp")
    temp.write_text(content, encoding="utf-8")
    temp.chmod(path.stat().st_mode & 0o777)
    temp.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", choices=("windows", "android", "all"))
    parser.add_argument("--godot", default=os.environ.get("GODOT", "godot"))
    parser.add_argument("--android-sdk", default=os.environ.get("ANDROID_HOME", ""))
    parser.add_argument("--java-sdk", default=os.environ.get("JAVA_HOME", ""))
    parser.add_argument("--local-state", action="store_true",
                        help="Linux: keep Godot settings/templates/cache under .local/")
    args = parser.parse_args()
    godot = shutil.which(args.godot)
    if not godot:
        parser.error("Godot executable not found. Pass --godot /path/to/Godot.")
    env = os.environ.copy()
    if args.local_state:
        if not sys.platform.startswith("linux"):
            parser.error("--local-state is intended for Linux cloud builds.")
        for variable, folder in (("XDG_DATA_HOME", "data"),
                                 ("XDG_CONFIG_HOME", "config"),
                                 ("XDG_CACHE_HOME", "cache")):
            env[variable] = str(ROOT / ".local" / folder)
            Path(env[variable]).mkdir(parents=True, exist_ok=True)
    version = subprocess.check_output([godot, "--version"], env=env, text=True).strip()
    if not version.startswith("4.6.3.stable"):
        parser.error(f"Use Godot 4.6.3 stable and matching export templates; found {version}")
    base = [godot, "--headless", "--path", str(ROOT)]
    print(f"Building with {version}", flush=True)
    run(base + ["--editor", "--import"], env)

    outputs: list[Path] = []
    if args.target in ("windows", "all"):
        output = ROOT / "dist/windows/PlateClub.exe"
        output.parent.mkdir(parents=True, exist_ok=True)
        run(base + ["--export-release", "Windows Desktop", str(output)], env)
        outputs.append(output)
        # Keep the executable and redistributable notices together.
        bundle = ROOT / "dist/PlateClub-Windows-x64.zip"
        with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.write(output, output.name)
            for name in ("README.md", "PREVIEW.md", "LICENSE", "THIRD_PARTY_NOTICES.md"):
                path = ROOT / name
                if path.is_file():
                    archive.write(path, name)
            for path in (ROOT / "assets").rglob("*LICENSE*"):
                if path.is_file():
                    archive.write(path, str(path.relative_to(ROOT)))
            for name in ("EXPORT_RU.md", "QA_RU.md", "LEADERBOARD_RU.md", "LEADERBOARD_SETUP_RU.md", "PLATE_REFERENCE_RU.md", "GODOT-LICENSE.txt", "GODOT-THIRD-PARTY.txt"):
                path = ROOT / "docs" / name
                if path.is_file():
                    archive.write(path, str(path.relative_to(ROOT)))
            for path in (ROOT / "docs/screenshots").glob("*.png"):
                archive.write(path, str(path.relative_to(ROOT)))
        outputs.append(bundle)

    if args.target in ("android", "all"):
        sdk = Path(args.android_sdk).expanduser().resolve() if args.android_sdk else None
        java = Path(args.java_sdk).expanduser().resolve() if args.java_sdk else None
        suffix = ".exe" if os.name == "nt" else ""
        if sdk and not (sdk / "platform-tools" / ("adb" + suffix)).is_file():
            parser.error("--android-sdk must contain platform-tools/adb.")
        if java and not (java / "bin" / ("keytool" + suffix)).is_file():
            parser.error("--java-sdk must contain bin/keytool.")
        if java:
            env["JAVA_HOME"] = str(java)
            env["PATH"] = str(java / "bin") + os.pathsep + env.get("PATH", "")
        if sdk or java:
            configure_android(godot, env, sdk, java)
        # This conventional key is for local testing only, never store publication keys here.
        keytool = str(java / "bin" / ("keytool" + suffix)) if java else shutil.which("keytool")
        keystore = ROOT / ".local/keys/debug.keystore"
        if not keystore.exists():
            if not keytool:
                parser.error("keytool unavailable; install OpenJDK 17+ or pass --java-sdk.")
            keystore.parent.mkdir(parents=True, exist_ok=True)
            run([keytool, "-genkeypair", "-keystore", str(keystore),
                 "-storepass", "android", "-keypass", "android", "-alias", "androiddebugkey",
                 "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
                 "-dname", "CN=Android Debug,O=Android,C=US", "-noprompt"], env)
            if os.name != "nt":
                keystore.chmod(0o600)
        env["GODOT_ANDROID_KEYSTORE_DEBUG_PATH"] = str(keystore)
        env["GODOT_ANDROID_KEYSTORE_DEBUG_USER"] = "androiddebugkey"
        env["GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD"] = "android"
        output = ROOT / "dist/android/PlateClub-debug.apk"
        output.parent.mkdir(parents=True, exist_ok=True)
        run(base + ["--export-debug", "Android", str(output)], env)
        if sdk:
            signers = sorted((sdk / "build-tools").glob("*/apksigner*"), reverse=True)
            signers = [p for p in signers if p.is_file() and p.suffix != ".jar"]
            if signers:
                run([str(signers[0]), "verify", "--verbose", str(output)], env)
        outputs.append(output)

    lines = []
    manifest = {"godot": version, "artifacts": []}
    for output in outputs:
        with output.open("rb") as handle:
            digest = hashlib.file_digest(handle, "sha256").hexdigest()
        lines.append(f"{digest}  {output.relative_to(ROOT / 'dist')}")
        manifest["artifacts"].append({"file": str(output.relative_to(ROOT / "dist")),
                                      "bytes": output.stat().st_size, "sha256": digest})
        print(f"Ready: {output.relative_to(ROOT)} ({output.stat().st_size / 1048576:.1f} MiB)")
    (ROOT / "dist/SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (ROOT / "dist/build-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.returncode) from exc
