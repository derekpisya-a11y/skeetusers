extends SceneTree
## Capture the real native renderer. Do not pass --headless: it has no framebuffer.
## Run with -- --pages=generator,collection,contracts,garage,progress --size=1440x900.

var game: Control
var output_dir := "res://.local/screenshots"
var pages: PackedStringArray = ["generator", "collection", "contracts", "garage", "progress"]
var window_size := Vector2i(1440, 900)

func _initialize() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--pages="):
			pages = arg.trim_prefix("--pages=").split(",", false)
		elif arg.begins_with("--out="):
			output_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--size="):
			var parts := arg.trim_prefix("--size=").split("x")
			if parts.size() == 2:
				window_size = Vector2i(int(parts[0]), int(parts[1]))
	var scratch := ProjectSettings.globalize_path("res://.local/qa")
	DirAccess.make_dir_recursive_absolute(scratch)
	# Every capture owns a fresh save. The player's normal user:// save is untouched.
	OS.set_environment("PLATE_CLUB_SAVE_PATH", scratch.path_join("visual-%s-%s.json" % [OS.get_process_id(), Time.get_ticks_usec()]))
	_run.call_deferred()

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Visual capture needs a native display or Xvfb; --headless has no rendered image.")
		quit(2)
		return
	root.size = window_size
	var scene := load("res://scenes/main.tscn") as PackedScene
	if scene == null:
		quit(2)
		return
	game = scene.instantiate()
	root.add_child(game)
	await _settle()
	var target := ProjectSettings.globalize_path(output_dir)
	var error := DirAccess.make_dir_recursive_absolute(target)
	if error != OK:
		push_error("Cannot create screenshot directory: %s" % error)
		quit(2)
		return
	for page: String in pages:
		game.call("show_page", page)
		await _settle()
		await RenderingServer.frame_post_draw
		var screenshot := root.get_texture().get_image()
		if screenshot == null or screenshot.is_empty():
			push_error("Renderer returned an empty image for %s" % page)
			quit(1)
			return
		var filename := "%s-%sx%s.png" % [page, window_size.x, window_size.y]
		error = screenshot.save_png(target.path_join(filename))
		if error != OK:
			push_error("Screenshot save failed for %s: %s" % [page, error])
			quit(1)
			return
		print("SCREENSHOT ", target.path_join(filename))
	print("Visual capture complete: %s native frames" % pages.size())
	quit(0)

func _settle() -> void:
	for index: int in range(8):
		await process_frame
	await create_timer(0.45).timeout
