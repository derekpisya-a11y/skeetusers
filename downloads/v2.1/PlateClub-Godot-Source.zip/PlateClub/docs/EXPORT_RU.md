# Запуск и сборка «Номерного клуба»

Игра сделана на **Godot 4.6.3 Standard**, язык GDScript. Это самостоятельное приложение для Windows и Android. Браузер, сервер, платные плагины и .NET не нужны. Официальный редактор: <https://godotengine.org/download/archive/4.6.3-stable/>.

## Готовые файлы

- `dist/PlateClub-Windows-x64.zip` — архив Windows. Распакуйте целиком и запустите `PlateClub.exe`. Ресурсы игры встроены в EXE.
- `dist/android/PlateClub-debug.apk` — APK для Android 7.0+ с процессором arm64. Перенесите файл на телефон, откройте его и разрешите установку этому файловому менеджеру, если Android попросит.
- `dist/SHA256SUMS.txt` — контрольные суммы собранных файлов.

APK подписан локальным тестовым ключом. Он предназначен для установки на свой телефон и проверки игры. Для Google Play потребуется отдельная release-подпись и AAB. Android-приложение запрашивает только доступ к интернету для общей таблицы лидеров. Основная игра работает офлайн. Микрофон и доступ к общим файлам не требуются.

Android-версия работает вертикально; Windows сохраняет широкий интерфейс. Формат сохранения v1 автоматически обновляется до v2.

Игра сохраняет прогресс в приватной папке приложения. Удаление приложения удаляет и локальное сохранение. Windows-версия сохраняет данные в `%APPDATA%\Godot\app_userdata\Номерной клуб\`.

## Как импортировать проект в Godot на Windows

1. Скачайте **Godot 4.6.3 Standard** для Windows x86_64 и распакуйте редактор.
2. Распакуйте именно `PlateClub-Godot-Source.zip` по ссылке сборки. Архив ветки `plate-club-downloads` содержит готовые пакеты и не является исходным проектом. Нужна вся папка проекта: `assets`, `scripts`, `scenes` и остальные файлы рядом с `project.godot`.
3. Откройте Godot → **Import / Импортировать** → выберите `project.godot` → **Import & Edit / Импортировать и редактировать**.
4. Дождитесь импорта шрифтов и изображений. Нажмите **F5** или кнопку запуска проекта. В открытой главной сцене `scenes/main.tscn` также можно нажать **F6**.

Копировать скрипты по одному или создавать новый пустой проект не нужно. Экспортировать можно прямо из редактора.

## Повторная сборка Windows

1. В Godot откройте **Editor → Manage Export Templates** и установите шаблоны **4.6.3.stable**. Версия должна совпадать с редактором.
2. Откройте **Project → Export**, выберите готовый профиль **Windows Desktop**.
3. Нажмите **Export Project**, отключите **Export With Debug**, укажите `PlateClub.exe`.

В профиле выбраны x86_64 и встраивание PCK в EXE, поэтому отдельного файла `.pck` нет. Рядом с распространяемой игрой сохраните уведомления о лицензиях из проекта. Сборка не подписана коммерческим Windows-сертификатом.

Через командную строку:

```powershell
& "C:\Godot\Godot_v4.6.3-stable_win64.exe" --headless --path . --editor --import
& "C:\Godot\Godot_v4.6.3-stable_win64.exe" --headless --path . --export-release "Windows Desktop" dist/windows/PlateClub.exe
```

Перед ручным экспортом создайте папку назначения. Вариант с Python ниже делает это автоматически.

## Повторная сборка Android APK

1. Установите OpenJDK 17 или более новый совместимый JDK. В облачной сборке используется установленная Java 21.
2. Установите Android SDK через Android Studio → SDK Manager или официальные command-line tools. Для обычного APK с готовым шаблоном нужны **Android SDK Platform-Tools** и **Android SDK Build-Tools 36.0.0**. Для дальнейшей работы с Gradle установите также **Android SDK Platform 36** и зависимости из документации Godot.
3. В Godot → **Editor Settings → Export → Android** укажите **Java SDK Path** (корень JDK) и **Android SDK Path** (папку с `platform-tools` и `build-tools`). Это настройки редактора на вашем компьютере; пути из облачной машины переносить не нужно.
4. Установите export templates **4.6.3.stable**.
5. В **Project → Export → Android** нажмите **Export Project** и оставьте **Export With Debug** включённым. Godot создаст или использует свой отладочный ключ. Выберите имя с расширением `.apk`.

Профиль использует официальный предварительно собранный Android-шаблон, поэтому Gradle, NDK и CMake для этой тестовой APK не запускаются. В Godot **4.6.3** шаблон требует Android API 24 и целится в API 36. Настройки `Min SDK` и `Target SDK` оставлены пустыми: при экспорте без Gradle используются значения шаблона.

По умолчанию экспортируется `arm64-v8a`. Для старых 32-битных устройств можно дополнительно включить `armeabi-v7a`, а для Android-эмулятора на ПК — `x86_64`; это увеличит APK. Для установки через USB, при настроенном Android Debug Bridge и разрешённой отладке на телефоне:

```text
adb install -r dist/android/PlateClub-debug.apk
```

Профиль Android не отмечен как Runnable, чтобы редактор не запускал монитор устройств при каждой проверке проекта. Экспорт APK работает; для кнопки запуска на подключённом телефоне можно включить Runnable в профиле.

## Скрипт автоматической сборки

Требуется Python 3.11+, установленный Godot 4.6.3 и соответствующие экспортные шаблоны. Скрипт не скачивает непроверенные SDK и не устанавливает пакеты в систему.

```powershell
python tools/build.py windows --godot "C:\Godot\Godot_v4.6.3-stable_win64.exe"
python tools/build.py android --godot "C:\Godot\Godot_v4.6.3-stable_win64.exe" --android-sdk "C:\Users\YOUR_NAME\AppData\Local\Android\Sdk" --java-sdk "C:\Program Files\Eclipse Adoptium\jdk-17"
```

Замените пути на свои. Вместо `windows` или `android` можно указать `all`. Если Godot доступен в `PATH`, параметр `--godot` не нужен. Уже настроенные в редакторе пути SDK можно использовать без соответствующих аргументов. Аргументы `--android-sdk` и `--java-sdk`, если они переданы, обновляют только эти настройки редактора.

Скрипт автоматически импортирует ресурсы, создаёт папки `dist`, собирает выбранные платформы и вычисляет SHA-256. Для Android он создаёт тестовый ключ `.local/keys/debug.keystore`, который не входит в Git и сборку. Тестовый пароль `android` — стандартная условность Android; не используйте такой ключ для публикации. Если SDK указан явно, скрипт также проверяет подпись APK через `apksigner`.

После сборки обеих платформ можно дополнительно проверить структуру EXE, встроенный PCK, подпись и выравнивание APK, разрешения Android, архитектуру и наличие лицензий:

```bash
python tools/build_verify.py --android-sdk /path/to/Android/Sdk
```

Результат записывается в `dist/verification.json`; хеши и размеры — в `dist/build-manifest.json`. Эти проверки анализируют готовые пакеты. Проверка запуска на реальном Windows-ПК и Android-телефоне выполняется отдельно.

Команда для подготовленной облачной среды:

```bash
python tools/build.py all --local-state \
  --android-sdk /workspace/.tooling/android-sdk \
  --java-sdk /usr/lib/jvm/java-21-openjdk-amd64
```

`--local-state` на Linux хранит настройки, шаблоны и кеш Godot внутри игнорируемой папки `.local`. Уберите этот флаг при использовании шаблонов, установленных обычным редактором в стандартную пользовательскую папку.

## Для будущей публикации в Google Play

Готовая тестовая APK уже позволяет играть. Для публикации нужно отдельно выбрать окончательный идентификатор приложения, повысить `version/code`, настроить Gradle/AAB и создать постоянный release-keystore. Идентификатор текущей сборки — `com.skeetusers.plateclub`.

Закрытый release-ключ и пароли хранятся вне Git и передаются редактору через **Export → Android → Keystore** либо переменные `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`, `GODOT_ANDROID_KEYSTORE_RELEASE_USER`, `GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD`. Не заменяйте им тестовый ключ в репозитории и сохраняйте резервную копию у себя. Для AAB потребуется полноценная Android/Gradle-среда; ориентируйтесь на документацию вашей версии Godot и актуальные требования Google Play.

Официальные инструкции: [экспорт Android](https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_android.html), [экспорт Windows](https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_windows.html), [лицензия Godot](https://godotengine.org/license/).

## Сервер общей таблицы

Публичный сервер ещё не размещён. Инструкция и Docker Compose включены в исходный ZIP: [LEADERBOARD_RU.md](LEADERBOARD_RU.md). Для игры без таблицы сервер не нужен. Секреты сервера и клиентские сохранения не публикуйте.
