#!/usr/bin/env python3
"""Plate Club shared leaderboard: Python stdlib, SQLite and bearer profiles.
Deploy behind HTTPS. Local development can bind to 127.0.0.1.
"""
from __future__ import annotations

import argparse
from collections import defaultdict, deque
import hashlib
import hmac
import ipaddress
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import sqlite3
import threading
import time

DB = Path("data/leaderboard.sqlite3")
LIMITS: dict = defaultdict(deque)
LIMIT_LOCK = threading.Lock()
TRUST_PROXY = False


def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB, timeout=10)
    connection.row_factory = sqlite3.Row
    return connection


def initialize() -> None:
    DB.parent.mkdir(parents=True, exist_ok=True)
    with connect() as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("CREATE TABLE IF NOT EXISTS players (id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, name TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0, updated INTEGER NOT NULL)")


def valid_name(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("Имя должно быть текстом.")
    name = value.strip()
    if not 2 <= len(name) <= 24 or not all(c.isalnum() or c in " _-" for c in name):
        raise ValueError("Имя: 2–24 символа, буквы, цифры, пробел, дефис или подчёркивание.")
    return name


class Handler(BaseHTTPRequestHandler):
    server_version = "PlateClub/2.0"

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(15)

    def log_message(self, *_args: object) -> None:
        pass  # Never log bodies or authentication tokens.

    def send(self, code: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def limited(self, registration: bool = False) -> bool:
        # Forwarded IP headers are intentionally not trusted.
        client = self.client_address[0]
        if TRUST_PROXY and ipaddress.ip_address(client).is_private:
            forwarded = self.headers.get("X-Forwarded-For", "").split(",")[0].strip()
            try:
                client = str(ipaddress.ip_address(forwarded))
            except ValueError:
                pass
        key = (client, registration)
        seconds, maximum = (3600, 30) if registration else (60, 180)
        now = time.monotonic()
        with LIMIT_LOCK:
            queue = LIMITS[key]
            while queue and queue[0] < now - seconds:
                queue.popleft()
            if len(queue) >= maximum:
                self.send(429, {"error":"Слишком много запросов. Попробуйте позже."})
                return True
            queue.append(now)
        return False

    def do_GET(self) -> None:
        if self.limited():
            return
        if self.path == "/health":
            self.send(200, {"ok":True, "version":"2.0.0"})
        elif self.path == "/v1/leaderboard":
            with connect() as connection:
                rows = connection.execute("SELECT id, name, score, updated FROM players ORDER BY score DESC, updated ASC, id ASC LIMIT 100").fetchall()
            self.send(200, {"ok":True, "players":[dict(row) | {"rank":i + 1} for i, row in enumerate(rows)]})
        else:
            self.send(404, {"error":"Маршрут не найден."})

    def do_POST(self) -> None:
        if self.limited(self.path == "/v1/register"):
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 1 <= length <= 8192:
                self.send(413, {"error":"Неподходящий размер запроса."})
                return
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError("Ожидается объект JSON.")
            if self.path == "/v1/register":
                name = valid_name(data.get("name"))
                player_id, token = secrets.token_hex(16), secrets.token_urlsafe(32)
                with connect() as connection:
                    connection.execute("INSERT INTO players (id, token_hash, name, updated) VALUES (?,?,?,?)", (player_id, hashlib.sha256(token.encode()).hexdigest(), name, int(time.time())))
                self.send(201, {"ok":True, "id":player_id, "token":token})
            elif self.path == "/v1/score":
                with connect() as connection:
                    player = connection.execute("SELECT * FROM players WHERE id=?", (str(data.get("id", "")),)).fetchone()
                    token = self.headers.get("Authorization", "").removeprefix("Bearer ")
                    if player is None or not hmac.compare_digest(player["token_hash"], hashlib.sha256(token.encode()).hexdigest()):
                        self.send(401, {"error":"Профиль не авторизован."})
                        return
                    name = valid_name(data.get("name"))
                    stats = data.get("stats")
                    if not isinstance(stats, dict):
                        raise ValueError("Не передана статистика.")
                    caps = {"generated":2000000, "exchanged":100000, "cars":36, "legendary_generated":2000000}
                    for key, cap in caps.items():
                        value = stats.get(key)
                        if type(value) is not int or not 0 <= value <= cap:
                            raise ValueError("Некорректная статистика.")
                    if stats["legendary_generated"] > stats["generated"]:
                        raise ValueError("Некорректное число легендарных номеров.")
                    score = stats["generated"] * 5 + stats["exchanged"] * 250 + stats["cars"] * 500 + stats["legendary_generated"] * 1000
                    connection.execute("UPDATE players SET name=?, score=MAX(score,?), updated=? WHERE id=?", (name, score, int(time.time()), player["id"]))
                self.send(200, {"ok":True, "score":max(score, player["score"])})
            else:
                self.send(404, {"error":"Маршрут не найден."})
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
            self.send(400, {"error":"Некорректный запрос или имя игрока."})
        except sqlite3.Error:
            self.send(503, {"error":"База временно недоступна."})


def main() -> None:
    global DB, TRUST_PROXY
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--database", type=Path, default=DB)
    parser.add_argument("--trust-proxy", action="store_true", help="Only behind a private reverse proxy that replaces Forwarded headers")
    args = parser.parse_args()
    DB = args.database
    TRUST_PROXY = args.trust_proxy
    initialize()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.daemon_threads = True
    print(f"Plate Club leaderboard listening on {args.host}:{args.port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
