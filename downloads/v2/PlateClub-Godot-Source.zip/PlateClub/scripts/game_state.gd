class_name ClubState
extends Node
## All economy mutations live here; the interface never owns collection data.

signal changed

const KITS = [
	{"id":"aero", "name":"Aero Street", "coins":50000, "dollars":10, "description":"Широкие пороги, сплиттер и компактное антикрыло."},
	{"id":"track", "name":"Track Carbon", "coins":120000, "dollars":25, "description":"Карбоновые расширители, диффузор и гоночное антикрыло."},
	{"id":"elite", "name":"Signature Gold", "coins":300000, "dollars":50, "description":"Широкий кузов, золотые акценты и эксклюзивная аэродинамика."},
]
const QUESTS = [
	{"id":"roll5", "name":"Первый тираж", "description":"Выпустить 5 номеров", "metric":"generated", "target":5, "coins":1500, "dollars":0},
	{"id":"roll25", "name":"Свой почерк", "description":"Выпустить 25 номеров", "metric":"generated", "target":25, "coins":4000, "dollars":0},
	{"id":"trade1", "name":"Первый серьёзный контракт", "description":"Открыть 1 автомобильный сундук", "metric":"exchanged", "target":1, "coins":7500, "dollars":0},
	{"id":"sell15", "name":"Торговая жилка", "description":"Продать 15 номеров", "metric":"sold", "target":15, "coins":3000, "dollars":0},
	{"id":"roll100", "name":"Сотня историй", "description":"Выпустить 100 номеров", "metric":"generated", "target":100, "coins":10000, "dollars":3},
	{"id":"epic10", "name":"Клуб редких серий", "description":"Выпустить 10 эпических или легендарных номеров", "metric":"epic_generated", "target":10, "coins":15000, "dollars":5},
	{"id":"legend3", "name":"Коллекционер легенд", "description":"Выпустить 3 легендарных номера", "metric":"legendary_generated", "target":3, "coins":25000, "dollars":8},
	{"id":"countries8", "name":"Весь мир в коллекции", "description":"Открыть номера всех 8 стран", "metric":"countries", "target":8, "coins":5000, "dollars":3},
	{"id":"trade20", "name":"Контракты высшей лиги", "description":"Выполнить 20 автомобильных контрактов", "metric":"exchanged", "target":20, "coins":30000, "dollars":10},
	{"id":"cars12", "name":"Большой гараж", "description":"Собрать 12 разных моделей автомобилей", "metric":"cars", "target":12, "coins":20000, "dollars":7},
	{"id":"cars36", "name":"Полная экспозиция", "description":"Собрать все 36 моделей автомобилей", "metric":"cars", "target":36, "coins":100000, "dollars":40},
	{"id":"daily10", "name":"Сегодняшний тираж", "description":"Выпустить 10 номеров сегодня (UTC)", "metric":"daily_generated", "target":10, "coins":1200, "dollars":0, "daily":true},
	{"id":"daily_trade", "name":"Контракт дня", "description":"Выполнить 1 контракт сегодня (UTC)", "metric":"daily_exchanged", "target":1, "coins":2000, "dollars":0, "daily":true},
	{"id":"daily_hard_roll", "name":"Марафон коллекционера", "description":"Выпустить 100 номеров сегодня (UTC)", "metric":"daily_generated", "target":100, "coins":3000, "dollars":1, "daily":true},
	{"id":"daily_hard_trade", "name":"Три серьёзных сделки", "description":"Выполнить 3 контракта сегодня (UTC)", "metric":"daily_exchanged", "target":3, "coins":5000, "dollars":2, "daily":true},
]

const Catalog = preload("res://scripts/catalog.gd")
const GENERATE_COST: int = 100
const JOB_REWARD: int = 150
const JOB_COOLDOWN: int = 10
const DAILY_REWARD: int = 1200
const PITY_LIMIT: int = 12
const SAVE_VERSION: int = 2
const MAX_PLATES: int = 2000
const PLATE_ODDS: Array[int] = [6400, 2500, 900, 180, 20]

var data: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var save_path: String = "user://collection.json"
var last_save_error: String = ""
var recovered_save: bool = false

func _init() -> void:
	rng.randomize()

func configure(path: String = "user://collection.json") -> void:
	save_path = path

func load_game() -> void:
	recovered_save = false
	var loaded: Dictionary = _read_save(save_path)
	if loaded.is_empty() and FileAccess.file_exists(save_path):
		# Keep the broken file for recovery; never overwrite it with a new profile.
		var recovery_path: String = save_path + ".corrupt-" + str(int(Time.get_unix_time_from_system())) + "-" + str(Time.get_ticks_usec())
		var preserve_error: Error = DirAccess.rename_absolute(_absolute(save_path), _absolute(recovery_path))
		if preserve_error != OK:
			last_save_error = "Не удалось сохранить повреждённый файл отдельно."
			data = _new_profile()
			changed.emit()
			return
		loaded = _read_save(save_path + ".bak")
		recovered_save = true
	elif loaded.is_empty():
		loaded = _read_save(save_path + ".bak")
		recovered_save = not loaded.is_empty()
	data = _normalize(loaded) if not loaded.is_empty() else _new_profile()
	save_game()
	changed.emit()

func save_game() -> bool:
	last_save_error = ""
	if data.is_empty():
		return false
	var base: String = _absolute(save_path).get_base_dir()
	if not DirAccess.dir_exists_absolute(base):
		if DirAccess.make_dir_recursive_absolute(base) != OK:
			last_save_error = "Не удалось создать папку сохранения."
			return false
	var temporary: String = save_path + ".tmp"
	var file: FileAccess = FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		last_save_error = "Не удалось открыть файл сохранения."
		return false
	data["version"] = SAVE_VERSION
	file.store_string(JSON.stringify(data, "\t"))
	file.flush()
	var write_error: Error = file.get_error()
	file.close()
	if write_error != OK or _read_save(temporary).is_empty():
		last_save_error = "Запись сохранения не завершена."
		return false
	if FileAccess.file_exists(save_path):
		if _read_save(save_path).is_empty():
			last_save_error = "Файл повреждён: перезапустите игру для восстановления."
			return false
		if DirAccess.copy_absolute(_absolute(save_path), _absolute(save_path + ".bak")) != OK:
			last_save_error = "Не удалось обновить резервную копию."
			return false
	if DirAccess.rename_absolute(_absolute(temporary), _absolute(save_path)) != OK:
		last_save_error = "Не удалось завершить сохранение."
		return false
	return true

func generate_plate(country_id: String) -> Dictionary:
	if Catalog.country(country_id).is_empty():
		return _error("Выберите страну номера.")
	if data.coins < GENERATE_COST:
		return _error("Недостаточно монет. Выполните заказ клуба или продайте номер.")
	if collection_count() >= int(data.collection_capacity):
		return _error("Коллекция заполнена: продайте или обменяйте несколько номеров.")
	var plate: Dictionary = _make_plate(country_id, _roll(PLATE_ODDS))
	var discovery: bool = true
	for owned: Dictionary in data.plates:
		if owned.country == plate.country and owned.text == plate.text and owned.region == plate.region:
			discovery = false
			break
	data.coins -= GENERATE_COST
	data.xp += 5 + int(plate.rarity) * 3
	data.plates.append(plate)
	data.stats.generated += 1
	_daily_stats()
	data.stats.daily_generated += 1
	if int(plate.rarity) >= 3:
		data.stats.epic_generated += 1
	if int(plate.rarity) == 4:
		data.stats.legendary_generated += 1
	data.last_plate = plate.duplicate(true)
	if not data.discoveries.countries.has(country_id):
		data.discoveries.countries.append(country_id)
	if int(plate.rarity) == 4:
		data.discoveries.legendary_plate = true
	_commit()
	return {"ok":true, "plate":plate.duplicate(true), "new_discovery":discovery}

func sell_plate(uid: String) -> Dictionary:
	var index: int = _plate_index(uid)
	if index < 0:
		return _error("Номер уже отсутствует в коллекции.")
	var plate: Dictionary = data.plates[index]
	if plate.get("in_vault", false):
		return _error("Сначала верните номер из сейфа в коллекцию.")
	if plate.favorite:
		return _error("Сначала уберите номер из избранного.")
	if not str(plate.equipped_to).is_empty():
		return _error("Сначала снимите номер с автомобиля.")
	var value: int = int(Catalog.rarity(int(plate.rarity)).sell_value)
	data.plates.remove_at(index)
	data.coins += value
	data.stats.sold += 1
	_commit()
	return {"ok":true, "value":value, "coins":value}

func toggle_favorite(uid: String) -> Dictionary:
	var index: int = _plate_index(uid)
	if index < 0:
		return _error("Номер не найден.")
	data.plates[index].favorite = not bool(data.plates[index].favorite)
	_commit()
	return {"ok":true, "favorite":data.plates[index].favorite}

func eligible_plates(tier_id: String) -> Array:
	var tier_data: Dictionary = Catalog.tier(tier_id)
	var result: Array = []
	if tier_data.is_empty():
		return result
	for plate: Dictionary in data.plates:
		if int(plate.rarity) >= int(tier_data.min_rarity) and not plate.favorite and str(plate.equipped_to).is_empty() and not plate.get("in_vault", false):
			result.append(plate.duplicate(true))
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a.rarity) < int(b.rarity))
	return result

func exchange(region_id: String, tier_id: String, uids: Array) -> Dictionary:
	var tier_data: Dictionary = Catalog.tier(tier_id)
	if Catalog.region(region_id).is_empty() or tier_data.is_empty():
		return _error("Выберите коллекцию и тип сундука.")
	if uids.size() != int(tier_data.count):
		return _error("Для обмена нужно номеров: %d." % int(tier_data.count))
	if data.coins < int(tier_data.fee):
		return _error("Недостаточно монет для обмена.")
	# Validate the entire transaction before changing even one collection item.
	var selected: Dictionary = {}
	for raw_uid: Variant in uids:
		var uid: String = str(raw_uid)
		if selected.has(uid):
			return _error("Каждый номер можно выбрать только один раз.")
		var index: int = _plate_index(uid)
		if index < 0:
			return _error("Один из выбранных номеров больше недоступен.")
		var plate: Dictionary = data.plates[index]
		if int(plate.rarity) < int(tier_data.min_rarity):
			return _error("Редкость одного из номеров слишком низкая.")
		if plate.favorite or plate.get("in_vault", false) or not str(plate.equipped_to).is_empty():
			return _error("Избранные и установленные номера защищены от обмена.")
		selected[uid] = true
	var pity_triggered: bool = int(data.pity) >= PITY_LIMIT - 1
	var reward_rarity: int = 4 if pity_triggered else _roll(tier_data.odds)
	var pool: Array[Dictionary] = []
	for vehicle: Dictionary in Catalog.CARS:
		if vehicle.region == region_id and int(vehicle.rarity) == reward_rarity:
			pool.append(vehicle)
	if pool.is_empty():
		return _error("В этой коллекции пока нет подходящих автомобилей.")
	var reward: Dictionary = pool[rng.randi_range(0, pool.size() - 1)].duplicate(true)
	var car_index: int = _car_index(str(reward.id))
	var duplicate: bool = car_index >= 0
	var compensation: int = [180, 300, 550, 1100, 2500][reward_rarity] if duplicate else 0
	var kept: Array = []
	for plate: Dictionary in data.plates:
		if not selected.has(plate.uid):
			kept.append(plate)
	data.plates = kept
	if duplicate:
		data.cars[car_index].count += 1
	else:
		data.cars.append({"id":reward.id, "count":1, "plate_uid":"", "kits":[], "equipped_kit":""})
	data.coins += compensation - int(tier_data.fee)
	data.xp += 50 + reward_rarity * 25
	data.stats.exchanged += 1
	_daily_stats()
	data.stats.daily_exchanged += 1
	data.pity = 0 if reward_rarity == 4 else int(data.pity) + 1
	var result: Dictionary = {"ok":true, "car":reward, "duplicate":duplicate, "compensation":compensation, "pity":pity_triggered}
	data.last_reward = result.duplicate(true)
	_commit()
	return result

func equip_plate(car_id: String, plate_uid: String) -> Dictionary:
	var car_index: int = _car_index(car_id)
	var plate_index: int = _plate_index(plate_uid)
	if car_index < 0 or plate_index < 0:
		return _error("Автомобиль или номер не найден.")
	if data.plates[plate_index].get("in_vault", false):
		return _error("Сначала верните номер из сейфа.")
	# Moving a plate between owned cars is intentional and keeps both links valid.
	var previous_car: int = _car_index(str(data.plates[plate_index].equipped_to))
	if previous_car >= 0:
		data.cars[previous_car].plate_uid = ""
	var previous_plate: int = _plate_index(str(data.cars[car_index].plate_uid))
	if previous_plate >= 0:
		data.plates[previous_plate].equipped_to = ""
	data.cars[car_index].plate_uid = plate_uid
	data.plates[plate_index].equipped_to = car_id
	_commit()
	return {"ok":true}

func unequip_plate(car_id: String) -> Dictionary:
	var car_index: int = _car_index(car_id)
	if car_index < 0:
		return _error("Автомобиль не найден.")
	var plate_index: int = _plate_index(str(data.cars[car_index].plate_uid))
	if plate_index >= 0:
		data.plates[plate_index].equipped_to = ""
	data.cars[car_index].plate_uid = ""
	_commit()
	return {"ok":true}

func daily_available() -> bool:
	return str(data.get("daily_day", "")) != Time.get_date_string_from_system(true)

func collect_daily() -> Dictionary:
	if not daily_available():
		return _error("Награда уже получена. Возвращайтесь завтра!")
	data.daily_day = Time.get_date_string_from_system(true)
	data.coins += DAILY_REWARD
	data.xp += 25
	_commit()
	return {"ok":true, "coins":DAILY_REWARD, "reward":DAILY_REWARD}

func job_remaining() -> int:
	return maxi(0, int(data.get("job_at", 0)) + JOB_COOLDOWN - int(Time.get_unix_time_from_system()))

func club_job() -> Dictionary:
	if job_remaining() > 0:
		return _error("Следующий заказ через %d сек." % job_remaining())
	data.job_at = int(Time.get_unix_time_from_system())
	data.coins += JOB_REWARD
	data.xp += 8
	_commit()
	return {"ok":true, "coins":JOB_REWARD, "reward":JOB_REWARD}

func _commit() -> void:
	save_game()
	changed.emit()

func _new_profile() -> Dictionary:
	return {
		"version":SAVE_VERSION, "coins":2500, "xp":0,
		"plates":[_make_plate("ru", 1), _make_plate("jp", 1), _make_plate("de", 1)],
		"cars":[{"id":"jp_mizu", "count":1, "plate_uid":"", "kits":[], "equipped_kit":""}],
		"stats":{"generated":0, "exchanged":0, "sold":0, "epic_generated":0, "legendary_generated":0, "daily_generated":0, "daily_exchanged":0, "day":""},
		"dollars":0, "collection_capacity":50, "vault_capacity":8, "claimed_quests":[],
		"discoveries":{"countries":["ru", "jp", "de"], "legendary_plate":false},
		"settings":{"sound":true, "theme":"classic", "online_url":"", "player_name":"Коллекционер", "player_id":"", "player_token":""}, "last_plate":{}, "last_reward":{},
		"daily_day":"", "job_at":0, "pity":0,
	}

func _make_plate(country_id: String, rarity_index: int) -> Dictionary:
	var length: int = 3 if country_id in ["ru", "kz"] else 4
	var number: String = _number(length, rarity_index)
	var letters: String = _distinct_letters("ABEKMHOPCTYX", 3)
	if rarity_index >= 3 and rng.randf() < 0.6:
		letters = letters[0].repeat(3)
	var text: String = ""
	var region: String = ""
	match country_id:
		"ru":
			text = letters[0] + number + letters.substr(1, 2)
			region = _pick(PlateLore.REGIONS.keys())
			if rarity_index == 4:
				var special: Dictionary = PlateLore.SERIES[rng.randi_range(0, PlateLore.SERIES.size() - 1)]
				letters = special.letters
				region = _pick(special.regions)
				text = letters[0] + number + letters.substr(1, 2)
			else:
				while not PlateLore.series({"country":"ru", "text":text, "serial":number, "region":region}).is_empty():
					letters = _distinct_letters("ABEKMHOPCTYX", 3)
					text = letters[0] + number + letters.substr(1, 2)
		"by":
			text = number + " " + letters.substr(0, 2) + "-" + str(rng.randi_range(1, 7))
			region = "BY"
		"ua":
			region = _pick(["AA", "KA", "BC", "AE", "AX", "BH", "AI", "BI"])
			text = region + " " + number + " " + letters.substr(0, 2)
		"kz":
			text = number + " " + _letters("ABCDEFGHJKLMNPRSTUVWXYZ", 3)
			if rarity_index >= 3:
				text = number + " " + letters
			region = _pick(["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"])
		"jp":
			region = _pick(["横浜", "品川", "大阪", "神戸", "京都", "札幌"]) + " " + _pick(["300", "330", "500"])
			text = _pick(["あ", "さ", "す", "せ", "そ", "た", "て", "と"]) + " " + number.substr(0, 2) + "-" + number.substr(2, 2)
		"de":
			region = _pick(["B", "M", "HH", "K", "F", "S", "D", "BN"])
			text = region + " " + _letters("ABCDEFGHJKLMNPRSTUVWXYZ", 2) + " " + number
		"fr":
			text = _letters("ABCDEFGHJKLMNPRSTVWXYZ", 2) + "-" + _number(3, rarity_index) + "-" + _letters("ABCDEFGHJKLMNPRSTVWXYZ", 2)
			region = _pick(["75", "13", "69", "33", "59", "06", "31", "44"])
		"gb":
			var prefix: String = _letters("ABCDEFGHJKLMNPRSTUVWXY", 2)
			var suffix: String = _letters("ABCDEFGHJKLMNPRSTUVWXYZ", 3)
			var age: String = _pick(["21", "22", "23", "24", "25", "26", "71", "72", "73", "74", "75", "76"])
			if rarity_index == 1:
				prefix = prefix[0].repeat(2)
			elif rarity_index == 2:
				suffix = suffix[0] + suffix[1] + suffix[0]
			elif rarity_index >= 3:
				suffix = suffix[0].repeat(3)
				if rarity_index == 4:
					prefix = suffix.substr(0, 2)
					age = "22"
			text = prefix + age + " " + suffix
			region = "UK"
	return {"uid":str(Time.get_ticks_usec()) + "-" + str(rng.randi()), "country":country_id,
		"text":text, "region":region, "serial":number, "rarity":rarity_index,
		"favorite":false, "equipped_to":"", "in_vault":false}

func _number(length: int, rarity_index: int) -> String:
	var digit: String = str(rng.randi_range(1, 9))
	var other: String = str((int(digit) + rng.randi_range(1, 8)) % 10)
	match rarity_index:
		4:
			return digit.repeat(length) if rng.randf() < 0.8 else "1".pad_zeros(length)
		3:
			return _pick([digit.repeat(3), "123", "321", "007"]) if length == 3 else _pick([digit.repeat(4), "1234", "4321", "0007"])
		2:
			return digit + other + digit if length == 3 else digit + other + other + digit
		1:
			return digit + digit + other if length == 3 else digit + digit + other + str((int(other) + 1) % 10)
		_:
			# Common plates have distinct digits; higher tiers express visible patterns.
			var unused: String = "123456789"
			var output: String = ""
			for i: int in range(length):
				var position: int = rng.randi_range(0, unused.length() - 1)
				output += unused[position]
				unused = unused.erase(position, 1)
			if output in ["123", "321", "1234", "4321"]:
				return "258" if length == 3 else "2586"
			return output

func _letters(alphabet: String, count: int) -> String:
	var result: String = ""
	for i: int in range(count):
		result += alphabet[rng.randi_range(0, alphabet.length() - 1)]
	return result

func _distinct_letters(alphabet: String, count: int) -> String:
	var result = ""
	var remaining = alphabet
	for i in count:
		var index = rng.randi_range(0, remaining.length() - 1)
		result += remaining[index]
		remaining = remaining.erase(index, 1)
	return result

func _pick(values: Array) -> String:
	return str(values[rng.randi_range(0, values.size() - 1)])

func _roll(weights: Array) -> int:
	var total: int = 0
	for weight in weights:
		total += int(weight)
	var roll: int = rng.randi_range(1, total)
	var cumulative: int = 0
	for i: int in range(weights.size()):
		cumulative += int(weights[i])
		if roll <= cumulative:
			return i
	return weights.size() - 1

func _plate_index(uid: String) -> int:
	for i: int in range(data.plates.size()):
		if str(data.plates[i].uid) == uid:
			return i
	return -1

func _car_index(id: String) -> int:
	for i: int in range(data.cars.size()):
		if str(data.cars[i].id) == id:
			return i
	return -1

func _read_save(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 8 * 1024 * 1024:
		return {}
	var json: JSON = JSON.new()
	var parse_error: Error = json.parse(file.get_as_text())
	file.close()
	if parse_error != OK or not json.data is Dictionary:
		return {}
	var loaded: Dictionary = json.data
	if not loaded.get("plates") is Array or not loaded.get("cars") is Array or not loaded.has("coins"):
		return {}
	return loaded

func _normalize(loaded: Dictionary) -> Dictionary:
	var result: Dictionary = {
		"version":SAVE_VERSION, "coins":_safe_int(loaded.get("coins"), 0, 2000000000),
		"xp":_safe_int(loaded.get("xp"), 0, 2000000000), "plates":[], "cars":[],
		"stats":{"generated":0, "exchanged":0, "sold":0}, "settings":{"sound":true},
		"discoveries":{"countries":[], "legendary_plate":false},
		"last_plate":{}, "last_reward":{}, "daily_day":str(loaded.get("daily_day", "")),
		"job_at":_safe_int(loaded.get("job_at"), 0, int(Time.get_unix_time_from_system())),
		"pity":_safe_int(loaded.get("pity"), 0, PITY_LIMIT - 1),
	}
	if loaded.get("discoveries") is Dictionary:
		var discoveries: Dictionary = loaded.discoveries
		if discoveries.get("countries") is Array:
			for country_id: Variant in discoveries.countries:
				if country_id is String and not Catalog.country(country_id).is_empty() and not result.discoveries.countries.has(country_id):
					result.discoveries.countries.append(country_id)
		if discoveries.get("legendary_plate") is bool:
			result.discoveries.legendary_plate = discoveries.legendary_plate
	var seen: Dictionary = {}
	for entry: Variant in loaded.plates:
		if not entry is Dictionary or result.plates.size() >= MAX_PLATES + 512:
			continue
		var plate: Dictionary = entry
		var uid: String = str(plate.get("uid", ""))
		var country_id: String = str(plate.get("country", ""))
		if uid.is_empty() or seen.has(uid) or Catalog.country(country_id).is_empty():
			continue
		if not plate.get("text") is String or str(plate.text).is_empty():
			continue
		seen[uid] = true
		result.plates.append({"uid":uid, "country":country_id, "text":str(plate.text).left(40),
			"region":str(plate.get("region", "")).left(30), "serial":str(plate.get("serial", "")).left(10),
			"rarity":_safe_int(plate.get("rarity"), 0, 4), "favorite":bool(plate.get("favorite", false)), "equipped_to":"", "in_vault":bool(plate.get("in_vault", false))})
		# Migrate older profiles and retain unlocks after their source plate is gone.
		if not result.discoveries.countries.has(country_id):
			result.discoveries.countries.append(country_id)
		if _safe_int(plate.get("rarity"), 0, 4) == 4:
			result.discoveries.legendary_plate = true
	seen.clear()
	var equipped: Dictionary = {}
	for entry: Variant in loaded.cars:
		if not entry is Dictionary:
			continue
		var owned: Dictionary = entry
		var id: String = str(owned.get("id", ""))
		if seen.has(id) or Catalog.car(id).is_empty():
			continue
		seen[id] = true
		var plate_uid: String = str(owned.get("plate_uid", ""))
		var resolved_uid: String = ""
		for plate: Dictionary in result.plates:
			if plate.uid == plate_uid and not equipped.has(plate_uid) and not plate.get("in_vault", false):
				plate.equipped_to = id
				resolved_uid = plate_uid
				equipped[plate_uid] = true
				break
		result.cars.append({"id":id, "count":maxi(1, _safe_int(owned.get("count"), 1, 1000000)), "plate_uid":resolved_uid, "kits":[], "equipped_kit":""})
	if loaded.get("stats") is Dictionary:
		for key: String in result.stats:
			result.stats[key] = _safe_int(loaded.stats.get(key), 0, 2000000000)
	if loaded.get("settings") is Dictionary:
		result.settings.sound = bool(loaded.settings.get("sound", true))
	if loaded.get("last_plate") is Dictionary:
		var last: Dictionary = loaded.last_plate
		for plate: Dictionary in result.plates:
			if plate.uid == str(last.get("uid", "")):
				result.last_plate = plate.duplicate(true)
				break
	if loaded.get("last_reward") is Dictionary:
		var reward: Dictionary = loaded.last_reward
		if reward.get("car") is Dictionary:
			var known: Dictionary = Catalog.car(str(reward.car.get("id", "")))
			if not known.is_empty():
				result.last_reward = {"ok":true, "car":known, "duplicate":bool(reward.get("duplicate", false)),
					"compensation":_safe_int(reward.get("compensation"), 0, 2500), "pity":bool(reward.get("pity", false))}
	_upgrade(result, loaded)
	return result

func _safe_int(value: Variant, minimum: int, maximum: int) -> int:
	if value is int or value is float:
		return clampi(int(value), minimum, maximum)
	return minimum

func _absolute(path: String) -> String:
	return ProjectSettings.globalize_path(path)

func _error(message: String) -> Dictionary:
	return {"ok":false, "error":message}

func collection_count() -> int:
	return data.plates.size() - vault_count()

func vault_count() -> int:
	var count = 0
	for plate in data.plates:
		if plate.get("in_vault", false):
			count += 1
	return count

func move_to_vault(uid: String) -> Dictionary:
	var index = _plate_index(uid)
	if index < 0:
		return _error("Номер не найден.")
	if data.plates[index].get("in_vault", false):
		return _error("Номер уже в сейфе.")
	if not str(data.plates[index].equipped_to).is_empty():
		return _error("Сначала снимите номер с автомобиля.")
	if vault_count() >= int(data.vault_capacity):
		return _error("Сейф заполнен. Расширьте его за доллары.")
	data.plates[index].in_vault = true
	_commit()
	return {"ok":true}

func return_from_vault(uid: String) -> Dictionary:
	var index = _plate_index(uid)
	if index < 0 or not data.plates[index].get("in_vault", false):
		return _error("Номер отсутствует в сейфе.")
	if collection_count() >= int(data.collection_capacity):
		return _error("Коллекция заполнена. Освободите или купите места.")
	data.plates[index].in_vault = false
	_commit()
	return {"ok":true}

func collection_upgrade_cost() -> int:
	return 2500 * maxi(1, int(data.collection_capacity) / 25 - 1) * maxi(1, int(data.collection_capacity) / 25 - 1)

func vault_upgrade_cost() -> int:
	return 5 * maxi(1, int(data.vault_capacity) / 8)

func expand_collection() -> Dictionary:
	if int(data.collection_capacity) >= MAX_PLATES:
		return _error("Достигнут максимум коллекции.")
	var cost = collection_upgrade_cost()
	if int(data.coins) < cost:
		return _error("Недостаточно монет для расширения.")
	data.coins -= cost
	data.collection_capacity = mini(MAX_PLATES, int(data.collection_capacity) + 25)
	_commit()
	return {"ok":true}

func expand_vault() -> Dictionary:
	if int(data.vault_capacity) >= 512:
		return _error("Достигнут максимум сейфа.")
	var cost = vault_upgrade_cost()
	if int(data.dollars) < cost:
		return _error("Недостаточно долларов. Выполняйте сложные задания.")
	data.dollars -= cost
	data.vault_capacity += 8
	_commit()
	return {"ok":true}

func buy_kit(car_id: String, kit_id: String) -> Dictionary:
	var index = _car_index(car_id)
	var kit: Dictionary = {}
	for item in KITS:
		if item.id == kit_id:
			kit = item
	if index < 0 or kit.is_empty():
		return _error("Автомобиль или обвес не найден.")
	if int(Catalog.car(car_id).rarity) < 3:
		return _error("Обвесы доступны для эпических и легендарных автомобилей.")
	if data.cars[index].kits.has(kit_id):
		return _error("Этот обвес уже куплен.")
	if int(data.coins) < int(kit.coins) or int(data.dollars) < int(kit.dollars):
		return _error("Не хватает монет или долларов для обвеса.")
	data.coins -= int(kit.coins)
	data.dollars -= int(kit.dollars)
	data.cars[index].kits.append(kit_id)
	data.cars[index].equipped_kit = kit_id
	_commit()
	return {"ok":true}

func equip_kit(car_id: String, kit_id: String) -> Dictionary:
	var index = _car_index(car_id)
	if index < 0:
		return _error("Автомобиль не найден.")
	if not kit_id.is_empty() and not data.cars[index].kits.has(kit_id):
		return _error("Сначала купите этот обвес.")
	data.cars[index].equipped_kit = kit_id
	_commit()
	return {"ok":true}

func quests() -> Array[Dictionary]:
	_daily_stats()
	var result: Array[Dictionary] = []
	for quest in QUESTS:
		var entry: Dictionary = quest.duplicate(true)
		var key: String = str(quest.id) + (":" + str(data.stats.day) if quest.get("daily", false) else "")
		var progress = 0
		match str(quest.metric):
			"countries": progress = data.discoveries.countries.size()
			"cars": progress = data.cars.size()
			_: progress = int(data.stats.get(quest.metric, 0))
		entry.progress = mini(int(quest.target), progress)
		entry.claimed = data.claimed_quests.has(key)
		entry.key = key
		result.append(entry)
	return result

func claim_quest(id: String) -> Dictionary:
	for quest in quests():
		if str(quest.id) != id:
			continue
		if quest.claimed:
			return _error("Награда уже получена.")
		if int(quest.progress) < int(quest.target):
			return _error("Задание ещё не выполнено.")
		data.claimed_quests.append(quest.key)
		data.coins += int(quest.coins)
		data.dollars += int(quest.dollars)
		_commit()
		return {"ok":true, "coins":quest.coins, "dollars":quest.dollars}
	return _error("Задание не найдено.")

func _daily_stats() -> void:
	var day = Time.get_date_string_from_system(true)
	if str(data.stats.get("day", "")) != day:
		data.stats.day = day
		data.stats.daily_generated = 0
		data.stats.daily_exchanged = 0
		var retained: Array = []
		for key in data.claimed_quests:
			if not str(key).contains(":") or str(key).ends_with(":" + day):
				retained.append(key)
		data.claimed_quests = retained

func score() -> int:
	return int(data.stats.generated) * 5 + int(data.stats.exchanged) * 250 + data.cars.size() * 500 + int(data.stats.legendary_generated) * 1000

func _upgrade(result: Dictionary, loaded: Dictionary) -> void:
	result.dollars = _safe_int(loaded.get("dollars"), 0, 1000000)
	var vault = 0
	for plate in result.plates:
		if plate.get("in_vault", false):
			vault += 1
	result.collection_capacity = maxi(result.plates.size() - vault, _safe_int(loaded.get("collection_capacity", 50), 50, MAX_PLATES))
	result.vault_capacity = maxi(vault, _safe_int(loaded.get("vault_capacity", 8), 8, 512))
	result.claimed_quests = []
	if loaded.get("claimed_quests") is Array:
		for key in loaded.claimed_quests:
			if key is String and key.length() < 60 and not result.claimed_quests.has(key):
				result.claimed_quests.append(key)
	for key in ["epic_generated", "legendary_generated", "daily_generated", "daily_exchanged"]:
		result.stats[key] = _safe_int(loaded.get("stats", {}).get(key, 0) if loaded.get("stats") is Dictionary else 0, 0, 2000000000)
	result.stats.day = str(loaded.get("stats", {}).get("day", "")) if loaded.get("stats") is Dictionary else ""
	result.settings.theme = str(loaded.get("settings", {}).get("theme", "classic")) if loaded.get("settings") is Dictionary else "classic"
	if result.settings.theme not in ["classic", "white", "pink", "gray"]:
		result.settings.theme = "classic"
	for key in ["online_url", "player_name", "player_id", "player_token"]:
		result.settings[key] = str(loaded.get("settings", {}).get(key, "")) if loaded.get("settings") is Dictionary else ""
	if str(result.settings.player_name).is_empty():
		result.settings.player_name = "Коллекционер"
	for owned in result.cars:
		for previous in loaded.cars:
			if previous is Dictionary and str(previous.get("id", "")) == str(owned.id):
				if previous.get("kits") is Array:
					for kit in previous.kits:
						if kit in ["aero", "track", "elite"] and not owned.kits.has(kit) and int(Catalog.car(str(owned.id)).rarity) >= 3:
							owned.kits.append(kit)
					if owned.kits.has(str(previous.get("equipped_kit", ""))):
						owned.equipped_kit = str(previous.equipped_kit)
