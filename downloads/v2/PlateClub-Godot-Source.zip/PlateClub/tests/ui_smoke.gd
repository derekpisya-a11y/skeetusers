extends SceneTree
var game: Variant
var failures: Array[String] = []
var checks = 0
var window_size = Vector2i(1440, 900)
var output_dir = "res://.local/screenshots/v2-ui-desktop"

func _initialize() -> void:
	if OS.get_cmdline_user_args().has("--portrait"):
		window_size = Vector2i(720, 1280)
		root.min_size = Vector2i(270, 480)
		output_dir = "res://.local/screenshots/v2-ui-portrait"
	var scratch = ProjectSettings.globalize_path("res://.local/qa")
	DirAccess.make_dir_recursive_absolute(scratch)
	OS.set_environment("PLATE_CLUB_SAVE_PATH", scratch.path_join("ui-v2-%d-%d.json" % [OS.get_process_id(), Time.get_ticks_usec()]))
	_run.call_deferred()

func _run() -> void:
	root.size = window_size
	var scene = load("res://scenes/main.tscn") as PackedScene
	game = scene.instantiate()
	root.add_child(game)
	await settle()
	check(game.state.data.version == 2, "new profile is v2")
	check(game.mobile_ui == OS.get_cmdline_user_args().has("--portrait"), "layout follows mobile mode")
	check(not quit_on_go_back, "Back handled by game")
	for page in ["generator","collection","contracts","garage","vault","quests","themes","leaderboard","progress"]:
		game.show_page(page)
		await settle()
		check(game.current_page == page and game.page_host.get_child_count() > 0, "page opens " + page)
		check(game.page_host.get_global_rect().end.x <= game.get_viewport_rect().size.x + 1, "page fits width " + page)
		await snapshot(page)
	game._open_menu()
	await settle()
	check(is_instance_valid(game.modal_root), "hamburger menu opens")
	await snapshot("menu")
	game.notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	check(not is_instance_valid(game.modal_root), "Back closes menu")
	game.show_page("generator")
	var count = game.state.collection_count()
	var coins = int(game.state.data.coins)
	await game._generate()
	game._close_modal()
	check(game.state.collection_count() == count + 1 and game.state.data.coins == coins - 100, "UI generator transacts once")
	var uid: String = game.state.data.plates[-1].uid
	game._perform(game.state.move_to_vault(uid), "stored", "vault")
	check(game.state.vault_count() == 1 and game.current_page == "vault", "UI stash navigates to vault")
	game.show_page("collection")
	check(game.collection_grid.get_child_count() == game.state.collection_count(), "collection hides vault plates")
	game._perform(game.state.return_from_vault(uid), "returned", "collection")
	check(game.state.vault_count() == 0, "UI returns vault plate")
	game.state.data.coins = 500000
	for i in 5:
		game.state.data.plates.append(game.state._make_plate("ru", 2))
	game.show_page("contracts")
	game._open_exchange("jp", "street")
	game._auto_select_plates()
	await settle()
	check(game.selected_plate_ids.size() == 5, "UI selects five eligible plates")
	check(not game.exchange_button.disabled, "valid contract can confirm")
	await snapshot("exchange")
	var previous = int(game.state.data.stats.exchanged)
	await game._confirm_exchange()
	await settle()
	check(game.state.data.stats.exchanged == previous + 1, "UI exchange completes once")
	await snapshot("reward")
	game._close_modal()
	for i in 5:
		game.state.data.plates.append(game.state._make_plate("de", 2))
	game._open_exchange("eu", "street")
	game._auto_select_plates()
	game._confirm_exchange.call_deferred()
	await create_timer(.1).timeout
	game._close_modal()
	await create_timer(1.0).timeout
	check(not game.busy, "interrupted reveal releases lock")
	game.show_page("garage")
	game.notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	check(game.current_page == "generator", "Back returns to generator")
	game.state.data.cars.append({"id":"eu_aurelia","count":1,"plate_uid":"","kits":[],"equipped_kit":""})
	game.state.data.dollars = 100
	var kit = game.state.buy_kit("eu_aurelia", "track")
	check(kit.ok, "kit purchase available for legendary")
	game._open_kits("eu_aurelia")
	await settle()
	await snapshot("kit-track")
	game._close_modal()
	var rare = game.state._make_plate("ru", 3)
	game.state.data.plates.append(rare)
	game._show_lore(rare)
	await settle()
	check(game.lore_view.highlight == "letters", "rare reveal starts with letters")
	await snapshot("lore-letters")
	await create_timer(2.1).timeout
	check(game.lore_view.highlight == "digits", "rare reveal advances to digits")
	await snapshot("lore-digits")
	game._close_modal()
	for id in ["white","pink","gray","classic"]:
		game._choose_theme(id)
		await settle()
		check(game.state.data.settings.theme == id, "theme persisted " + id)
		game.show_page("generator")
		await settle()
		check(game.page_host.get_global_rect().end.x <= game.get_viewport_rect().size.x + 1, "themed layout fits " + id)
		await snapshot("theme-" + id)
	var server = OS.get_environment("PLATE_CLUB_TEST_SERVER_URL")
	if not server.is_empty():
		game.state.data.settings.online_url = server
		game.state.data.settings.player_name = "UI Test " + str(OS.get_process_id())
		var result = await game.online.sync(game.state)
		check(result.get("ok", false) and result.get("players", []).size() >= 1, "native client synchronizes real shared leaderboard")
		check(not str(game.state.data.settings.player_id).is_empty(), "online profile saved")
	var capacity = int(game.state.data.collection_capacity)
	var dollars = int(game.state.data.dollars)
	game.state.save_game()
	game.queue_free()
	await process_frame
	game = scene.instantiate()
	root.add_child(game)
	await settle()
	check(game.state.data.collection_capacity == capacity and game.state.data.dollars == dollars, "new economy survives restart")
	check(game.state.data.settings.theme == "classic", "selected theme restores")
	print("UI smoke v2: %d checks, %d failures" % [checks, failures.size()])
	quit(0 if failures.is_empty() else 1)

func check(condition: bool, title: String) -> void:
	checks += 1
	if not condition:
		failures.append(title)
		push_error("FAIL " + title)

func settle() -> void:
	for i in 8:
		await process_frame
	await create_timer(.18).timeout

func snapshot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	var target = ProjectSettings.globalize_path(output_dir)
	DirAccess.make_dir_recursive_absolute(target)
	await RenderingServer.frame_post_draw
	var pic = root.get_texture().get_image()
	check(not pic.is_empty(), "native render " + name)
	check(pic.save_png(target.path_join(name + ".png")) == OK, "snapshot " + name)
