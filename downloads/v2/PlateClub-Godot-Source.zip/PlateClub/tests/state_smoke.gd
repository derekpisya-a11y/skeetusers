extends SceneTree
const State = preload("res://scripts/game_state.gd")
var checks = 0
var failures = 0
var game: ClubState
var save_path: String

func _initialize() -> void:
	save_path = "/tmp/plate-club-v2-%d.json" % OS.get_process_id()
	game = State.new()
	game.configure(save_path)
	game.load_game()
	check(game.last_save_error.is_empty(), "fresh profile saves")
	check(game.data.coins == 2500 and game.data.dollars == 0, "starter currencies")
	check(game.collection_count() == 3 and game.data.collection_capacity == 50 and game.data.vault_capacity == 8, "initial collection and vault sizes")
	check(game.eligible_plates("street").is_empty(), "starter uncommon plates cannot buy harder crates")
	check(GameCatalog.car("jp_mizu").name == "Honda Civic EK9" and GameCatalog.car("ru_volna").name == "ВАЗ-2107", "old vehicle ids map to real model names")
	for region in GameCatalog.REGIONS:
		for rarity in 5:
			var found = false
			for car in GameCatalog.CARS:
				found = found or (car.region == region.id and int(car.rarity) == rarity)
			check(found, "regional reward pool %s/%d" % [region.id, rarity])
	for country in GameCatalog.COUNTRIES:
		for rarity in 5:
			var plate = game._make_plate(str(country.id), rarity)
			check(plate.country == country.id and int(plate.rarity) == rarity and not str(plate.text).is_empty(), "generated format %s/%d" % [country.id, rarity])
	var legends = 0
	for i in 100:
		var plate = game._make_plate("ru", 4)
		check(not PlateLore.series(plate).is_empty(), "Russian legend is a catalogued combination")
		legends += 1
	check(legends == 100, "Russian legendary pool covered")
	var sample = {"country":"ru", "text":"A444AA", "serial":"444", "region":"42"}
	var reasons = PlateLore.reasons(sample)
	check(str(reasons[0].title).contains("Три одинаковые буквы") and str(reasons[1].title).contains("Все цифры одинаковые"), "letter and digit repeats explained independently")
	check(str(reasons[2].text).contains("Кемеровская"), "Kemerovo region explanation")
	check(PlateLore.series({"country":"ru", "text":"A444MP", "serial":"444", "region":"42"}).is_empty(), "special attribution is region scoped")
	check(PlateLore.REGIONS.get("267", "").is_empty(), "invalid illustrative region is not invented")
	var before = int(game.data.coins)
	var generated = game.generate_plate("ru")
	check(generated.ok and game.data.coins == before - 100 and game.data.stats.generated == 1, "generation cost and progress")
	var uid: String = generated.plate.uid
	check(game.toggle_favorite(uid).ok and not game.sell_plate(uid).ok, "favorite sale protection")
	check(game.move_to_vault(uid).ok, "favorite can be stored in vault")
	check(game.vault_count() == 1 and game.collection_count() == 3, "vault removes plate from visible collection")
	check(not game.sell_plate(uid).ok and not game.equip_plate("jp_mizu", uid).ok, "vault protects sale and equip")
	check(game.return_from_vault(uid).ok and game.data.plates[game._plate_index(uid)].favorite, "vault return preserves favorite")
	game.toggle_favorite(uid)
	check(game.equip_plate("jp_mizu", uid).ok and not game.move_to_vault(uid).ok, "equipped plate cannot be stashed")
	check(game.unequip_plate("jp_mizu").ok, "unequip")
	before = game.data.coins
	var sale = game.sell_plate(uid)
	check(sale.ok and game.data.coins == before + int(sale.value) and not game.sell_plate(uid).ok, "sale pays once")
	game.data.collection_capacity = game.collection_count()
	var snapshot = JSON.stringify(game.data)
	check(not game.generate_plate("ru").ok and JSON.stringify(game.data) == snapshot, "full collection blocks generation atomically")
	uid = game.data.plates[0].uid
	game.move_to_vault(uid)
	check(game.generate_plate("jp").ok, "stashing frees a collection slot")
	check(not game.return_from_vault(uid).ok, "return to full collection rejected")
	game.data.coins = 1000000
	game.data.collection_capacity = 50
	before = game.data.coins
	check(game.expand_collection().ok and game.data.collection_capacity == 75 and game.data.coins == before - 2500, "paid collection expansion")
	game.data.dollars = 0
	snapshot = JSON.stringify(game.data)
	check(not game.expand_vault().ok and JSON.stringify(game.data) == snapshot, "vault needs dollars")
	game.data.dollars = 50
	check(game.expand_vault().ok and game.data.vault_capacity == 16 and game.data.dollars == 45, "paid vault expansion")
	game.data.plates.clear()
	for i in 5:
		game.data.plates.append(game._make_plate("de", 2))
	var eligible = game.eligible_plates("street")
	var ids: Array = []
	for p in eligible:
		ids.append(p.uid)
	game.data.coins = 0
	snapshot = JSON.stringify(game.data)
	check(not game.exchange("jp", "street", ids).ok and JSON.stringify(game.data) == snapshot, "crate fee enforced atomically")
	game.data.coins = 500000
	check(not game.exchange("jp", "street", [ids[0],ids[0],ids[0],ids[0],ids[0]]).ok, "duplicate IDs rejected")
	game.move_to_vault(str(ids[0]))
	check(not game.exchange("jp", "street", ids).ok and game.eligible_plates("street").size() == 4, "vault excluded from contract")
	game.return_from_vault(str(ids[0]))
	game.toggle_favorite(str(ids[0]))
	check(not game.exchange("jp", "street", ids).ok, "favorite excluded from contract")
	game.toggle_favorite(str(ids[0]))
	game.data.pity = 11
	before = game.data.coins
	var reward = game.exchange("jp", "street", ids)
	check(reward.ok and int(reward.car.rarity) == 4 and reward.car.region == "jp", "pity legendary in chosen region")
	check(game.data.plates.is_empty() and game.data.coins == before - 5000 and game.data.pity == 0, "crate consumes five plates and fee once")
	check(game.data.cars[game._car_index("jp_raiden")].kits.is_empty(), "new rewards have kit metadata")
	for i in 5:
		game.data.plates.append(game._make_plate("ru", 2))
	ids.clear()
	for plate in game.eligible_plates("street"):
		ids.append(plate.uid)
	game.data.pity = 11
	before = game.data.coins
	reward = game.exchange("jp", "street", ids)
	check(reward.ok and reward.duplicate and game.data.coins == before - 5000 + 2500, "duplicate compensation after harder fee")
	game.data.coins = 0
	snapshot = JSON.stringify(game.data)
	check(not game.buy_kit("jp_raiden", "aero").ok and JSON.stringify(game.data) == snapshot, "failed kit purchase changes nothing")
	game.data.coins = 500000
	game.data.dollars = 50
	check(not game.buy_kit("jp_mizu", "aero").ok, "common cars cannot use premium kit")
	check(game.buy_kit("jp_raiden", "aero").ok and game.data.coins == 450000 and game.data.dollars == 40, "kit spends both currencies")
	snapshot = JSON.stringify(game.data)
	check(not game.buy_kit("jp_raiden", "aero").ok and JSON.stringify(game.data) == snapshot, "kit cannot be purchased twice")
	check(game.equip_kit("jp_raiden", "").ok and game.equip_kit("jp_raiden", "aero").ok and not game.equip_kit("jp_raiden", "track").ok, "kit equipment requires ownership")
	game.data.stats.generated = 100
	before = game.data.dollars
	check(game.claim_quest("roll100").ok and game.data.dollars == before + 3, "hard quest grants rare dollars")
	snapshot = JSON.stringify(game.data)
	check(not game.claim_quest("roll100").ok and JSON.stringify(game.data) == snapshot, "quest reward paid once")
	check(not game.claim_quest("cars36").ok, "incomplete quest cannot claim")
	game.data.stats.day = Time.get_date_string_from_system(true)
	game.data.stats.daily_generated = 10
	check(game.claim_quest("daily10").ok and not game.claim_quest("daily10").ok, "daily quest paid once per UTC day")
	game.data.stats.day = "2000-01-01"
	game._daily_stats()
	check(game.data.stats.daily_generated == 0 and not game.claim_quest("daily10").ok, "daily counters reset")
	check(game.collect_daily().ok and not game.collect_daily().ok, "daily gift paid once")
	check(game.club_job().ok and not game.club_job().ok, "free job cooldown")
	game.data.coins = 0
	game.data.job_at = 0
	check(game.club_job().ok and game.generate_plate("fr").ok, "no economic softlock")
	uid = game.data.plates[0].uid
	check(game.move_to_vault(uid).ok, "stash before persistence")
	game.data.settings.theme = "pink"
	check(game.save_game(), "save complete profile")
	var restored = State.new()
	restored.configure(save_path)
	restored.load_game()
	check(restored.data.dollars == game.data.dollars and restored.data.collection_capacity == 75 and restored.data.vault_capacity == 16, "capacities and dollars persist")
	check(restored.vault_count() == 1 and restored.data.settings.theme == "pink", "vault and theme persist")
	check(restored.data.cars[restored._car_index("jp_raiden")].equipped_kit == "aero", "kit persists")
	check(not restored.claim_quest("roll100").ok, "quest claim persists")
	var broken = FileAccess.open(save_path, FileAccess.WRITE)
	broken.store_string("{broken")
	broken.close()
	restored.load_game()
	check(restored.recovered_save and restored.last_save_error.is_empty(), "backup recovery")
	var legacy = game._new_profile()
	legacy.version = 1
	for key in ["dollars","collection_capacity","vault_capacity","claimed_quests"]:
		legacy.erase(key)
	legacy.settings = {"sound":false}
	legacy.cars = [{"id":"jp_raiden","count":2,"plate_uid":""}]
	legacy.plates.clear()
	for i in 80:
		legacy.plates.append(game._make_plate("ru", 2))
	var migrated = game._normalize(legacy)
	check(migrated.plates.size() == 80 and migrated.collection_capacity >= 80 and migrated.cars[0].id == "jp_raiden", "v1 migration preserves excess inventory and garage")
	check(migrated.cars[0].kits.is_empty() and migrated.settings.theme == "classic" and not migrated.settings.sound, "v1 migration adds new defaults")
	for key in DirAccess.get_files_at("/tmp"):
		if key.begins_with(save_path.get_file()):
			DirAccess.remove_absolute("/tmp/" + key)
	restored.free()
	game.free()
	print("State smoke v2: %d checks, %d failures" % [checks, failures])
	quit(0 if failures == 0 else 1)

func check(ok: bool, description: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(description)
